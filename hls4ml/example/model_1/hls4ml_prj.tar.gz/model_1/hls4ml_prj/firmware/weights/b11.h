//Numpy array shape [5]
//Min -0.133029296994
//Max 0.070168465376
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {-0.1330292970, 0.0701684654, 0.0544251837, 0.0109262271, -0.0185693856};
#endif

#endif
