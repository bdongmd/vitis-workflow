#include "dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1464_fu_2281_p0() {
    mul_ln1118_1464_fu_2281_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1464_fu_2281_p2() {
    mul_ln1118_1464_fu_2281_p2 = (!mul_ln1118_1464_fu_2281_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1464_fu_2281_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1465_fu_2831_p0() {
    mul_ln1118_1465_fu_2831_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1465_fu_2831_p2() {
    mul_ln1118_1465_fu_2831_p2 = (!mul_ln1118_1465_fu_2831_p0.read().is_01() || !ap_const_lv25_F2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1465_fu_2831_p0.read()) * sc_biguint<25>(ap_const_lv25_F2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1466_fu_2670_p0() {
    mul_ln1118_1466_fu_2670_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1466_fu_2670_p2() {
    mul_ln1118_1466_fu_2670_p2 = (!mul_ln1118_1466_fu_2670_p0.read().is_01() || !ap_const_lv25_1FFFF12.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1466_fu_2670_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF12);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1467_fu_2427_p0() {
    mul_ln1118_1467_fu_2427_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1467_fu_2427_p2() {
    mul_ln1118_1467_fu_2427_p2 = (!mul_ln1118_1467_fu_2427_p0.read().is_01() || !ap_const_lv25_F3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1467_fu_2427_p0.read()) * sc_biguint<25>(ap_const_lv25_F3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1468_fu_2348_p0() {
    mul_ln1118_1468_fu_2348_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1468_fu_2348_p2() {
    mul_ln1118_1468_fu_2348_p2 = (!mul_ln1118_1468_fu_2348_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1468_fu_2348_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1469_fu_3445_p0() {
    mul_ln1118_1469_fu_3445_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1469_fu_3445_p2() {
    mul_ln1118_1469_fu_3445_p2 = (!mul_ln1118_1469_fu_3445_p0.read().is_01() || !ap_const_lv24_43.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1469_fu_3445_p0.read()) * sc_biguint<24>(ap_const_lv24_43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1470_fu_2398_p0() {
    mul_ln1118_1470_fu_2398_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1470_fu_2398_p2() {
    mul_ln1118_1470_fu_2398_p2 = (!mul_ln1118_1470_fu_2398_p0.read().is_01() || !ap_const_lv24_57.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1470_fu_2398_p0.read()) * sc_biguint<24>(ap_const_lv24_57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1471_fu_2866_p0() {
    mul_ln1118_1471_fu_2866_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1471_fu_2866_p2() {
    mul_ln1118_1471_fu_2866_p2 = (!mul_ln1118_1471_fu_2866_p0.read().is_01() || !ap_const_lv25_1FFFF46.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1471_fu_2866_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1472_fu_2705_p0() {
    mul_ln1118_1472_fu_2705_p0 =  (sc_lv<16>) (sext_ln1118_1034_fu_10334105_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1472_fu_2705_p2() {
    mul_ln1118_1472_fu_2705_p2 = (!mul_ln1118_1472_fu_2705_p0.read().is_01() || !ap_const_lv26_10C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1472_fu_2705_p0.read()) * sc_biguint<26>(ap_const_lv26_10C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1473_fu_1715_p0() {
    mul_ln1118_1473_fu_1715_p0 = sext_ln1118_1037_fu_10334121_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1473_fu_1715_p2() {
    mul_ln1118_1473_fu_1715_p2 = (!mul_ln1118_1473_fu_1715_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1473_fu_1715_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1474_fu_3012_p0() {
    mul_ln1118_1474_fu_3012_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1474_fu_3012_p2() {
    mul_ln1118_1474_fu_3012_p2 = (!mul_ln1118_1474_fu_3012_p0.read().is_01() || !ap_const_lv25_A1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1474_fu_3012_p0.read()) * sc_biguint<25>(ap_const_lv25_A1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1475_fu_2851_p0() {
    mul_ln1118_1475_fu_2851_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1475_fu_2851_p2() {
    mul_ln1118_1475_fu_2851_p2 = (!mul_ln1118_1475_fu_2851_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1475_fu_2851_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1476_fu_3319_p0() {
    mul_ln1118_1476_fu_3319_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1476_fu_3319_p2() {
    mul_ln1118_1476_fu_3319_p2 = (!mul_ln1118_1476_fu_3319_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1476_fu_3319_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1477_fu_3158_p0() {
    mul_ln1118_1477_fu_3158_p0 = sext_ln1118_1036_fu_10334116_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1477_fu_3158_p2() {
    mul_ln1118_1477_fu_3158_p2 = (!mul_ln1118_1477_fu_3158_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1477_fu_3158_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1478_fu_3626_p0() {
    mul_ln1118_1478_fu_3626_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1478_fu_3626_p2() {
    mul_ln1118_1478_fu_3626_p2 = (!mul_ln1118_1478_fu_3626_p0.read().is_01() || !ap_const_lv24_7B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1478_fu_3626_p0.read()) * sc_biguint<24>(ap_const_lv24_7B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1479_fu_3465_p0() {
    mul_ln1118_1479_fu_3465_p0 =  (sc_lv<16>) (sext_ln1118_1032_fu_10334083_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1479_fu_3465_p2() {
    mul_ln1118_1479_fu_3465_p2 = (!mul_ln1118_1479_fu_3465_p0.read().is_01() || !ap_const_lv25_1FFFF62.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1479_fu_3465_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1480_fu_3304_p0() {
    mul_ln1118_1480_fu_3304_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1480_fu_3304_p2() {
    mul_ln1118_1480_fu_3304_p2 = (!mul_ln1118_1480_fu_3304_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1480_fu_3304_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1481_fu_2514_p0() {
    mul_ln1118_1481_fu_2514_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1481_fu_2514_p2() {
    mul_ln1118_1481_fu_2514_p2 = (!mul_ln1118_1481_fu_2514_p0.read().is_01() || !ap_const_lv24_FFFF89.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1481_fu_2514_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF89);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1482_fu_2982_p0() {
    mul_ln1118_1482_fu_2982_p0 =  (sc_lv<16>) (sext_ln1118_1046_fu_10334576_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1482_fu_2982_p2() {
    mul_ln1118_1482_fu_2982_p2 = (!mul_ln1118_1482_fu_2982_p0.read().is_01() || !ap_const_lv25_1FFFF54.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1482_fu_2982_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1483_fu_2529_p0() {
    mul_ln1118_1483_fu_2529_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1483_fu_2529_p2() {
    mul_ln1118_1483_fu_2529_p2 = (!mul_ln1118_1483_fu_2529_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1483_fu_2529_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1484_fu_2174_p0() {
    mul_ln1118_1484_fu_2174_p0 = sext_ln1118_1050_fu_10334608_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1484_fu_2174_p2() {
    mul_ln1118_1484_fu_2174_p2 = (!mul_ln1118_1484_fu_2174_p0.read().is_01() || !ap_const_lv22_1A.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1484_fu_2174_p0.read()) * sc_biguint<22>(ap_const_lv22_1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1485_fu_2602_p0() {
    mul_ln1118_1485_fu_2602_p0 = sext_ln1118_1049_fu_10334603_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1485_fu_2602_p2() {
    mul_ln1118_1485_fu_2602_p2 = (!mul_ln1118_1485_fu_2602_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1485_fu_2602_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1486_fu_2603_p0() {
    mul_ln1118_1486_fu_2603_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1486_fu_2603_p2() {
    mul_ln1118_1486_fu_2603_p2 = (!mul_ln1118_1486_fu_2603_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1486_fu_2603_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1487_fu_2114_p0() {
    mul_ln1118_1487_fu_2114_p0 =  (sc_lv<16>) (sext_ln1118_1046_fu_10334576_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1487_fu_2114_p2() {
    mul_ln1118_1487_fu_2114_p2 = (!mul_ln1118_1487_fu_2114_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1487_fu_2114_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1488_fu_2115_p0() {
    mul_ln1118_1488_fu_2115_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1488_fu_2115_p2() {
    mul_ln1118_1488_fu_2115_p2 = (!mul_ln1118_1488_fu_2115_p0.read().is_01() || !ap_const_lv24_77.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1488_fu_2115_p0.read()) * sc_biguint<24>(ap_const_lv24_77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1489_fu_2116_p0() {
    mul_ln1118_1489_fu_2116_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1489_fu_2116_p2() {
    mul_ln1118_1489_fu_2116_p2 = (!mul_ln1118_1489_fu_2116_p0.read().is_01() || !ap_const_lv24_FFFFA7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1489_fu_2116_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1490_fu_2117_p0() {
    mul_ln1118_1490_fu_2117_p0 =  (sc_lv<16>) (sext_ln1118_1046_fu_10334576_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1490_fu_2117_p2() {
    mul_ln1118_1490_fu_2117_p2 = (!mul_ln1118_1490_fu_2117_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1490_fu_2117_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1491_fu_2608_p0() {
    mul_ln1118_1491_fu_2608_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1491_fu_2608_p2() {
    mul_ln1118_1491_fu_2608_p2 = (!mul_ln1118_1491_fu_2608_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1491_fu_2608_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1492_fu_2119_p0() {
    mul_ln1118_1492_fu_2119_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1492_fu_2119_p2() {
    mul_ln1118_1492_fu_2119_p2 = (!mul_ln1118_1492_fu_2119_p0.read().is_01() || !ap_const_lv24_79.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1492_fu_2119_p0.read()) * sc_biguint<24>(ap_const_lv24_79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1493_fu_3100_p0() {
    mul_ln1118_1493_fu_3100_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1493_fu_3100_p2() {
    mul_ln1118_1493_fu_3100_p2 = (!mul_ln1118_1493_fu_3100_p0.read().is_01() || !ap_const_lv24_66.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1493_fu_3100_p0.read()) * sc_biguint<24>(ap_const_lv24_66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1494_fu_2611_p0() {
    mul_ln1118_1494_fu_2611_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1494_fu_2611_p2() {
    mul_ln1118_1494_fu_2611_p2 = (!mul_ln1118_1494_fu_2611_p0.read().is_01() || !ap_const_lv24_FFFFB2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1494_fu_2611_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1495_fu_2612_p0() {
    mul_ln1118_1495_fu_2612_p0 =  (sc_lv<16>) (sext_ln1118_1047_fu_10334584_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1495_fu_2612_p2() {
    mul_ln1118_1495_fu_2612_p2 = (!mul_ln1118_1495_fu_2612_p0.read().is_01() || !ap_const_lv24_FFFF8D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1495_fu_2612_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1496_fu_2613_p0() {
    mul_ln1118_1496_fu_2613_p0 =  (sc_lv<16>) (sext_ln1118_1046_fu_10334576_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1496_fu_2613_p2() {
    mul_ln1118_1496_fu_2613_p2 = (!mul_ln1118_1496_fu_2613_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1496_fu_2613_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1497_fu_2124_p0() {
    mul_ln1118_1497_fu_2124_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1497_fu_2124_p2() {
    mul_ln1118_1497_fu_2124_p2 = (!mul_ln1118_1497_fu_2124_p0.read().is_01() || !ap_const_lv24_6C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1497_fu_2124_p0.read()) * sc_biguint<24>(ap_const_lv24_6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1498_fu_3105_p0() {
    mul_ln1118_1498_fu_3105_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1498_fu_3105_p2() {
    mul_ln1118_1498_fu_3105_p2 = (!mul_ln1118_1498_fu_3105_p0.read().is_01() || !ap_const_lv25_1FFFF53.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1498_fu_3105_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1499_fu_2126_p0() {
    mul_ln1118_1499_fu_2126_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1499_fu_2126_p2() {
    mul_ln1118_1499_fu_2126_p2 = (!mul_ln1118_1499_fu_2126_p0.read().is_01() || !ap_const_lv25_1FFFF6C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1499_fu_2126_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1500_fu_2127_p0() {
    mul_ln1118_1500_fu_2127_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1500_fu_2127_p2() {
    mul_ln1118_1500_fu_2127_p2 = (!mul_ln1118_1500_fu_2127_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1500_fu_2127_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1501_fu_2128_p0() {
    mul_ln1118_1501_fu_2128_p0 =  (sc_lv<16>) (sext_ln1118_1063_fu_10335171_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1501_fu_2128_p2() {
    mul_ln1118_1501_fu_2128_p2 = (!mul_ln1118_1501_fu_2128_p0.read().is_01() || !ap_const_lv26_127.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1501_fu_2128_p0.read()) * sc_biguint<26>(ap_const_lv26_127);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1502_fu_2619_p0() {
    mul_ln1118_1502_fu_2619_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1502_fu_2619_p2() {
    mul_ln1118_1502_fu_2619_p2 = (!mul_ln1118_1502_fu_2619_p0.read().is_01() || !ap_const_lv24_FFFF8D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1502_fu_2619_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1503_fu_2620_p0() {
    mul_ln1118_1503_fu_2620_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1503_fu_2620_p2() {
    mul_ln1118_1503_fu_2620_p2 = (!mul_ln1118_1503_fu_2620_p0.read().is_01() || !ap_const_lv25_1FFFF2D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1503_fu_2620_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1504_fu_3111_p0() {
    mul_ln1118_1504_fu_3111_p0 = sext_ln1118_1067_fu_10335203_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1504_fu_3111_p2() {
    mul_ln1118_1504_fu_3111_p2 = (!mul_ln1118_1504_fu_3111_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1504_fu_3111_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1505_fu_3112_p0() {
    mul_ln1118_1505_fu_3112_p0 =  (sc_lv<16>) (sext_ln1118_1063_fu_10335171_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1505_fu_3112_p2() {
    mul_ln1118_1505_fu_3112_p2 = (!mul_ln1118_1505_fu_3112_p0.read().is_01() || !ap_const_lv26_3FFFEB1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1505_fu_3112_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1506_fu_2623_p0() {
    mul_ln1118_1506_fu_2623_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1506_fu_2623_p2() {
    mul_ln1118_1506_fu_2623_p2 = (!mul_ln1118_1506_fu_2623_p0.read().is_01() || !ap_const_lv25_1FFFF65.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1506_fu_2623_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1507_fu_2624_p0() {
    mul_ln1118_1507_fu_2624_p0 = sext_ln1118_1069_fu_10335212_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1507_fu_2624_p2() {
    mul_ln1118_1507_fu_2624_p2 = (!mul_ln1118_1507_fu_2624_p0.read().is_01() || !ap_const_lv21_1FFFF5.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1507_fu_2624_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1508_fu_2625_p0() {
    mul_ln1118_1508_fu_2625_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1508_fu_2625_p2() {
    mul_ln1118_1508_fu_2625_p2 = (!mul_ln1118_1508_fu_2625_p0.read().is_01() || !ap_const_lv25_B8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1508_fu_2625_p0.read()) * sc_biguint<25>(ap_const_lv25_B8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1509_fu_2047_p0() {
    mul_ln1118_1509_fu_2047_p0 =  (sc_lv<16>) (sext_ln1118_1064_fu_10335179_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1509_fu_2047_p2() {
    mul_ln1118_1509_fu_2047_p2 = (!mul_ln1118_1509_fu_2047_p0.read().is_01() || !ap_const_lv25_D1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1509_fu_2047_p0.read()) * sc_biguint<25>(ap_const_lv25_D1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1510_fu_3117_p0() {
    mul_ln1118_1510_fu_3117_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1510_fu_3117_p2() {
    mul_ln1118_1510_fu_3117_p2 = (!mul_ln1118_1510_fu_3117_p0.read().is_01() || !ap_const_lv24_FFFF97.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1510_fu_3117_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1511_fu_3118_p0() {
    mul_ln1118_1511_fu_3118_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1511_fu_3118_p2() {
    mul_ln1118_1511_fu_3118_p2 = (!mul_ln1118_1511_fu_3118_p0.read().is_01() || !ap_const_lv24_74.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1511_fu_3118_p0.read()) * sc_biguint<24>(ap_const_lv24_74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1512_fu_1885_p0() {
    mul_ln1118_1512_fu_1885_p0 =  (sc_lv<16>) (sext_ln1118_1066_fu_10335193_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1512_fu_1885_p2() {
    mul_ln1118_1512_fu_1885_p2 = (!mul_ln1118_1512_fu_1885_p0.read().is_01() || !ap_const_lv24_FFFF9C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1512_fu_1885_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1513_fu_2353_p0() {
    mul_ln1118_1513_fu_2353_p0 =  (sc_lv<16>) (sext_ln1118_1063_fu_10335171_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1513_fu_2353_p2() {
    mul_ln1118_1513_fu_2353_p2 = (!mul_ln1118_1513_fu_2353_p0.read().is_01() || !ap_const_lv26_3FFFCFD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1513_fu_2353_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCFD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1514_fu_3450_p0() {
    mul_ln1118_1514_fu_3450_p0 =  (sc_lv<16>) (sext_ln1118_1063_fu_10335171_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1514_fu_3450_p2() {
    mul_ln1118_1514_fu_3450_p2 = (!mul_ln1118_1514_fu_3450_p0.read().is_01() || !ap_const_lv26_17A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1514_fu_3450_p0.read()) * sc_biguint<26>(ap_const_lv26_17A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1515_fu_2031_p0() {
    mul_ln1118_1515_fu_2031_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1515_fu_2031_p2() {
    mul_ln1118_1515_fu_2031_p2 = (!mul_ln1118_1515_fu_2031_p0.read().is_01() || !ap_const_lv23_35.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1515_fu_2031_p0.read()) * sc_biguint<23>(ap_const_lv23_35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1516_fu_3128_p0() {
    mul_ln1118_1516_fu_3128_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1516_fu_3128_p2() {
    mul_ln1118_1516_fu_3128_p2 = (!mul_ln1118_1516_fu_3128_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1516_fu_3128_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1517_fu_3596_p0() {
    mul_ln1118_1517_fu_3596_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1517_fu_3596_p2() {
    mul_ln1118_1517_fu_3596_p2 = (!mul_ln1118_1517_fu_3596_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1517_fu_3596_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1518_fu_2806_p0() {
    mul_ln1118_1518_fu_2806_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1518_fu_2806_p2() {
    mul_ln1118_1518_fu_2806_p2 = (!mul_ln1118_1518_fu_2806_p0.read().is_01() || !ap_const_lv24_4D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1518_fu_2806_p0.read()) * sc_biguint<24>(ap_const_lv24_4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1519_fu_2207_p0() {
    mul_ln1118_1519_fu_2207_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1519_fu_2207_p2() {
    mul_ln1118_1519_fu_2207_p2 = (!mul_ln1118_1519_fu_2207_p0.read().is_01() || !ap_const_lv25_8E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1519_fu_2207_p0.read()) * sc_biguint<25>(ap_const_lv25_8E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1520_fu_3113_p0() {
    mul_ln1118_1520_fu_3113_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1520_fu_3113_p2() {
    mul_ln1118_1520_fu_3113_p2 = (!mul_ln1118_1520_fu_3113_p0.read().is_01() || !ap_const_lv23_7FFFDD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1520_fu_3113_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1521_fu_2323_p0() {
    mul_ln1118_1521_fu_2323_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1521_fu_2323_p2() {
    mul_ln1118_1521_fu_2323_p2 = (!mul_ln1118_1521_fu_2323_p0.read().is_01() || !ap_const_lv24_FFFFAC.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1521_fu_2323_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1522_fu_2791_p0() {
    mul_ln1118_1522_fu_2791_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1522_fu_2791_p2() {
    mul_ln1118_1522_fu_2791_p2 = (!mul_ln1118_1522_fu_2791_p0.read().is_01() || !ap_const_lv25_A6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1522_fu_2791_p0.read()) * sc_biguint<25>(ap_const_lv25_A6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1523_fu_3095_p0() {
    mul_ln1118_1523_fu_3095_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1523_fu_3095_p2() {
    mul_ln1118_1523_fu_3095_p2 = (!mul_ln1118_1523_fu_3095_p0.read().is_01() || !ap_const_lv25_1FFFF0A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1523_fu_3095_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1524_fu_2469_p0() {
    mul_ln1118_1524_fu_2469_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1524_fu_2469_p2() {
    mul_ln1118_1524_fu_2469_p2 = (!mul_ln1118_1524_fu_2469_p0.read().is_01() || !ap_const_lv24_FFFF9E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1524_fu_2469_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1525_fu_2946_p0() {
    mul_ln1118_1525_fu_2946_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1525_fu_2946_p2() {
    mul_ln1118_1525_fu_2946_p2 = (!mul_ln1118_1525_fu_2946_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1525_fu_2946_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1526_fu_3414_p0() {
    mul_ln1118_1526_fu_3414_p0 = sext_ln1118_1081_fu_10335763_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1526_fu_3414_p2() {
    mul_ln1118_1526_fu_3414_p2 = (!mul_ln1118_1526_fu_3414_p0.read().is_01() || !ap_const_lv22_3FFFE6.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1526_fu_3414_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1527_fu_1995_p0() {
    mul_ln1118_1527_fu_1995_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1527_fu_1995_p2() {
    mul_ln1118_1527_fu_1995_p2 = (!mul_ln1118_1527_fu_1995_p0.read().is_01() || !ap_const_lv24_72.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1527_fu_1995_p0.read()) * sc_biguint<24>(ap_const_lv24_72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1528_fu_2463_p0() {
    mul_ln1118_1528_fu_2463_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1528_fu_2463_p2() {
    mul_ln1118_1528_fu_2463_p2 = (!mul_ln1118_1528_fu_2463_p0.read().is_01() || !ap_const_lv23_2A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1528_fu_2463_p0.read()) * sc_biguint<23>(ap_const_lv23_2A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1529_fu_1673_p0() {
    mul_ln1118_1529_fu_1673_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1529_fu_1673_p2() {
    mul_ln1118_1529_fu_1673_p2 = (!mul_ln1118_1529_fu_1673_p0.read().is_01() || !ap_const_lv25_1FFFF57.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1529_fu_1673_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1530_fu_2770_p0() {
    mul_ln1118_1530_fu_2770_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1530_fu_2770_p2() {
    mul_ln1118_1530_fu_2770_p2 = (!mul_ln1118_1530_fu_2770_p0.read().is_01() || !ap_const_lv24_63.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1530_fu_2770_p0.read()) * sc_biguint<24>(ap_const_lv24_63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1531_fu_3238_p0() {
    mul_ln1118_1531_fu_3238_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1531_fu_3238_p2() {
    mul_ln1118_1531_fu_3238_p2 = (!mul_ln1118_1531_fu_3238_p0.read().is_01() || !ap_const_lv25_CC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1531_fu_3238_p0.read()) * sc_biguint<25>(ap_const_lv25_CC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1532_fu_2448_p0() {
    mul_ln1118_1532_fu_2448_p0 =  (sc_lv<16>) (sext_ln1118_1084_fu_10335789_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1532_fu_2448_p2() {
    mul_ln1118_1532_fu_2448_p2 = (!mul_ln1118_1532_fu_2448_p0.read().is_01() || !ap_const_lv23_23.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1532_fu_2448_p0.read()) * sc_biguint<23>(ap_const_lv23_23);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1533_fu_3545_p0() {
    mul_ln1118_1533_fu_3545_p0 =  (sc_lv<16>) (sext_ln1118_1082_fu_10335768_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1533_fu_3545_p2() {
    mul_ln1118_1533_fu_3545_p2 = (!mul_ln1118_1533_fu_3545_p0.read().is_01() || !ap_const_lv25_97.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1533_fu_3545_p0.read()) * sc_biguint<25>(ap_const_lv25_97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1534_fu_2755_p0() {
    mul_ln1118_1534_fu_2755_p0 =  (sc_lv<16>) (sext_ln1118_1083_fu_10335778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1534_fu_2755_p2() {
    mul_ln1118_1534_fu_2755_p2 = (!mul_ln1118_1534_fu_2755_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1534_fu_2755_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1535_fu_1965_p0() {
    mul_ln1118_1535_fu_1965_p0 =  (sc_lv<16>) (sext_ln1118_1099_fu_10336388_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1535_fu_1965_p2() {
    mul_ln1118_1535_fu_1965_p2 = (!mul_ln1118_1535_fu_1965_p0.read().is_01() || !ap_const_lv24_FFFFBD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1535_fu_1965_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1536_fu_1804_p0() {
    mul_ln1118_1536_fu_1804_p0 =  (sc_lv<16>) (sext_ln1118_1097_fu_10336375_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1536_fu_1804_p2() {
    mul_ln1118_1536_fu_1804_p2 = (!mul_ln1118_1536_fu_1804_p0.read().is_01() || !ap_const_lv23_2A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1536_fu_1804_p0.read()) * sc_biguint<23>(ap_const_lv23_2A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1537_fu_2272_p0() {
    mul_ln1118_1537_fu_2272_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1537_fu_2272_p2() {
    mul_ln1118_1537_fu_2272_p2 = (!mul_ln1118_1537_fu_2272_p0.read().is_01() || !ap_const_lv25_B0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1537_fu_2272_p0.read()) * sc_biguint<25>(ap_const_lv25_B0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1538_fu_2111_p0() {
    mul_ln1118_1538_fu_2111_p0 =  (sc_lv<16>) (sext_ln1118_1094_fu_10336351_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1538_fu_2111_p2() {
    mul_ln1118_1538_fu_2111_p2 = (!mul_ln1118_1538_fu_2111_p0.read().is_01() || !ap_const_lv26_10E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1538_fu_2111_p0.read()) * sc_biguint<26>(ap_const_lv26_10E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1539_fu_3351_p0() {
    mul_ln1118_1539_fu_3351_p0 =  (sc_lv<16>) (sext_ln1118_1094_fu_10336351_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1539_fu_3351_p2() {
    mul_ln1118_1539_fu_3351_p2 = (!mul_ln1118_1539_fu_3351_p0.read().is_01() || !ap_const_lv26_3FFFE51.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1539_fu_3351_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1540_fu_2208_p0() {
    mul_ln1118_1540_fu_2208_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1540_fu_2208_p2() {
    mul_ln1118_1540_fu_2208_p2 = (!mul_ln1118_1540_fu_2208_p0.read().is_01() || !ap_const_lv25_1FFFF52.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1540_fu_2208_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1541_fu_1719_p0() {
    mul_ln1118_1541_fu_1719_p0 =  (sc_lv<16>) (sext_ln1118_1097_fu_10336375_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1541_fu_1719_p2() {
    mul_ln1118_1541_fu_1719_p2 = (!mul_ln1118_1541_fu_1719_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1541_fu_1719_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1542_fu_1720_p0() {
    mul_ln1118_1542_fu_1720_p0 =  (sc_lv<16>) (sext_ln1118_1099_fu_10336388_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1542_fu_1720_p2() {
    mul_ln1118_1542_fu_1720_p2 = (!mul_ln1118_1542_fu_1720_p0.read().is_01() || !ap_const_lv24_FFFF9F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1542_fu_1720_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1543_fu_2701_p0() {
    mul_ln1118_1543_fu_2701_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1543_fu_2701_p2() {
    mul_ln1118_1543_fu_2701_p2 = (!mul_ln1118_1543_fu_2701_p0.read().is_01() || !ap_const_lv25_1FFFF62.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1543_fu_2701_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1544_fu_1722_p0() {
    mul_ln1118_1544_fu_1722_p0 =  (sc_lv<16>) (sext_ln1118_1097_fu_10336375_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1544_fu_1722_p2() {
    mul_ln1118_1544_fu_1722_p2 = (!mul_ln1118_1544_fu_1722_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1544_fu_1722_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1545_fu_1723_p0() {
    mul_ln1118_1545_fu_1723_p0 =  (sc_lv<16>) (sext_ln1118_1097_fu_10336375_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1545_fu_1723_p2() {
    mul_ln1118_1545_fu_1723_p2 = (!mul_ln1118_1545_fu_1723_p0.read().is_01() || !ap_const_lv23_29.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1545_fu_1723_p0.read()) * sc_biguint<23>(ap_const_lv23_29);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1546_fu_1724_p0() {
    mul_ln1118_1546_fu_1724_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1546_fu_1724_p2() {
    mul_ln1118_1546_fu_1724_p2 = (!mul_ln1118_1546_fu_1724_p0.read().is_01() || !ap_const_lv25_B3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1546_fu_1724_p0.read()) * sc_biguint<25>(ap_const_lv25_B3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1547_fu_3284_p0() {
    mul_ln1118_1547_fu_3284_p0 =  (sc_lv<16>) (sext_ln1118_1099_fu_10336388_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1547_fu_3284_p2() {
    mul_ln1118_1547_fu_3284_p2 = (!mul_ln1118_1547_fu_3284_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1547_fu_3284_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1548_fu_1726_p0() {
    mul_ln1118_1548_fu_1726_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1548_fu_1726_p2() {
    mul_ln1118_1548_fu_1726_p2 = (!mul_ln1118_1548_fu_1726_p0.read().is_01() || !ap_const_lv25_1FFFF77.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1548_fu_1726_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1549_fu_2217_p0() {
    mul_ln1118_1549_fu_2217_p0 =  (sc_lv<16>) (sext_ln1118_1094_fu_10336351_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1549_fu_2217_p2() {
    mul_ln1118_1549_fu_2217_p2 = (!mul_ln1118_1549_fu_2217_p0.read().is_01() || !ap_const_lv26_119.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1549_fu_2217_p0.read()) * sc_biguint<26>(ap_const_lv26_119);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1550_fu_1728_p0() {
    mul_ln1118_1550_fu_1728_p0 =  (sc_lv<16>) (sext_ln1118_1097_fu_10336375_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1550_fu_1728_p2() {
    mul_ln1118_1550_fu_1728_p2 = (!mul_ln1118_1550_fu_1728_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1550_fu_1728_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1551_fu_1729_p0() {
    mul_ln1118_1551_fu_1729_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1551_fu_1729_p2() {
    mul_ln1118_1551_fu_1729_p2 = (!mul_ln1118_1551_fu_1729_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1551_fu_1729_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1552_fu_1730_p0() {
    mul_ln1118_1552_fu_1730_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1552_fu_1730_p2() {
    mul_ln1118_1552_fu_1730_p2 = (!mul_ln1118_1552_fu_1730_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1552_fu_1730_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1553_fu_1731_p0() {
    mul_ln1118_1553_fu_1731_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1553_fu_1731_p2() {
    mul_ln1118_1553_fu_1731_p2 = (!mul_ln1118_1553_fu_1731_p0.read().is_01() || !ap_const_lv25_93.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1553_fu_1731_p0.read()) * sc_biguint<25>(ap_const_lv25_93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1554_fu_1732_p0() {
    mul_ln1118_1554_fu_1732_p0 =  (sc_lv<16>) (sext_ln1118_1099_fu_10336388_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1554_fu_1732_p2() {
    mul_ln1118_1554_fu_1732_p2 = (!mul_ln1118_1554_fu_1732_p0.read().is_01() || !ap_const_lv24_FFFF9A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1554_fu_1732_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1555_fu_2223_p0() {
    mul_ln1118_1555_fu_2223_p0 =  (sc_lv<16>) (sext_ln1118_1095_fu_10336358_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1555_fu_2223_p2() {
    mul_ln1118_1555_fu_2223_p2 = (!mul_ln1118_1555_fu_2223_p0.read().is_01() || !ap_const_lv25_1FFFF30.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1555_fu_2223_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF30);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1556_fu_3293_p0() {
    mul_ln1118_1556_fu_3293_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1556_fu_3293_p2() {
    mul_ln1118_1556_fu_3293_p2 = (!mul_ln1118_1556_fu_3293_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1556_fu_3293_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1557_fu_2225_p0() {
    mul_ln1118_1557_fu_2225_p0 =  (sc_lv<16>) (sext_ln1118_1112_fu_10337003_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1557_fu_2225_p2() {
    mul_ln1118_1557_fu_2225_p2 = (!mul_ln1118_1557_fu_2225_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1557_fu_2225_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1558_fu_2226_p0() {
    mul_ln1118_1558_fu_2226_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1558_fu_2226_p2() {
    mul_ln1118_1558_fu_2226_p2 = (!mul_ln1118_1558_fu_2226_p0.read().is_01() || !ap_const_lv25_B5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1558_fu_2226_p0.read()) * sc_biguint<25>(ap_const_lv25_B5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1559_fu_2227_p0() {
    mul_ln1118_1559_fu_2227_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1559_fu_2227_p2() {
    mul_ln1118_1559_fu_2227_p2 = (!mul_ln1118_1559_fu_2227_p0.read().is_01() || !ap_const_lv24_FFFF83.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1559_fu_2227_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1560_fu_2228_p0() {
    mul_ln1118_1560_fu_2228_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1560_fu_2228_p2() {
    mul_ln1118_1560_fu_2228_p2 = (!mul_ln1118_1560_fu_2228_p0.read().is_01() || !ap_const_lv25_BA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1560_fu_2228_p0.read()) * sc_biguint<25>(ap_const_lv25_BA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1561_fu_2229_p0() {
    mul_ln1118_1561_fu_2229_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1561_fu_2229_p2() {
    mul_ln1118_1561_fu_2229_p2 = (!mul_ln1118_1561_fu_2229_p0.read().is_01() || !ap_const_lv24_FFFF93.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1561_fu_2229_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1562_fu_1740_p0() {
    mul_ln1118_1562_fu_1740_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1562_fu_1740_p2() {
    mul_ln1118_1562_fu_1740_p2 = (!mul_ln1118_1562_fu_1740_p0.read().is_01() || !ap_const_lv25_CB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1562_fu_1740_p0.read()) * sc_biguint<25>(ap_const_lv25_CB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1563_fu_2231_p0() {
    mul_ln1118_1563_fu_2231_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1563_fu_2231_p2() {
    mul_ln1118_1563_fu_2231_p2 = (!mul_ln1118_1563_fu_2231_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1563_fu_2231_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1564_fu_3301_p0() {
    mul_ln1118_1564_fu_3301_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1564_fu_3301_p2() {
    mul_ln1118_1564_fu_3301_p2 = (!mul_ln1118_1564_fu_3301_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1564_fu_3301_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1565_fu_1743_p0() {
    mul_ln1118_1565_fu_1743_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1565_fu_1743_p2() {
    mul_ln1118_1565_fu_1743_p2 = (!mul_ln1118_1565_fu_1743_p0.read().is_01() || !ap_const_lv24_66.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1565_fu_1743_p0.read()) * sc_biguint<24>(ap_const_lv24_66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1566_fu_1744_p0() {
    mul_ln1118_1566_fu_1744_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1566_fu_1744_p2() {
    mul_ln1118_1566_fu_1744_p2 = (!mul_ln1118_1566_fu_1744_p0.read().is_01() || !ap_const_lv25_B9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1566_fu_1744_p0.read()) * sc_biguint<25>(ap_const_lv25_B9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1567_fu_2796_p0() {
    mul_ln1118_1567_fu_2796_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1567_fu_2796_p2() {
    mul_ln1118_1567_fu_2796_p2 = (!mul_ln1118_1567_fu_2796_p0.read().is_01() || !ap_const_lv25_1FFFF5D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1567_fu_2796_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1568_fu_3182_p0() {
    mul_ln1118_1568_fu_3182_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1568_fu_3182_p2() {
    mul_ln1118_1568_fu_3182_p2 = (!mul_ln1118_1568_fu_3182_p0.read().is_01() || !ap_const_lv24_4D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1568_fu_3182_p0.read()) * sc_biguint<24>(ap_const_lv24_4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1569_fu_1845_p0() {
    mul_ln1118_1569_fu_1845_p0 =  (sc_lv<16>) (sext_ln1118_1112_fu_10337003_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1569_fu_1845_p2() {
    mul_ln1118_1569_fu_1845_p2 = (!mul_ln1118_1569_fu_1845_p0.read().is_01() || !ap_const_lv23_36.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1569_fu_1845_p0.read()) * sc_biguint<23>(ap_const_lv23_36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1570_fu_2942_p0() {
    mul_ln1118_1570_fu_2942_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1570_fu_2942_p2() {
    mul_ln1118_1570_fu_2942_p2 = (!mul_ln1118_1570_fu_2942_p0.read().is_01() || !ap_const_lv25_A3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1570_fu_2942_p0.read()) * sc_biguint<25>(ap_const_lv25_A3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1571_fu_2152_p0() {
    mul_ln1118_1571_fu_2152_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1571_fu_2152_p2() {
    mul_ln1118_1571_fu_2152_p2 = (!mul_ln1118_1571_fu_2152_p0.read().is_01() || !ap_const_lv24_5F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1571_fu_2152_p0.read()) * sc_biguint<24>(ap_const_lv24_5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1572_fu_1909_p0() {
    mul_ln1118_1572_fu_1909_p0 =  (sc_lv<16>) (sext_ln1118_1112_fu_10337003_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1572_fu_1909_p2() {
    mul_ln1118_1572_fu_1909_p2 = (!mul_ln1118_1572_fu_1909_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1572_fu_1909_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1573_fu_3088_p0() {
    mul_ln1118_1573_fu_3088_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1573_fu_3088_p2() {
    mul_ln1118_1573_fu_3088_p2 = (!mul_ln1118_1573_fu_3088_p0.read().is_01() || !ap_const_lv25_E3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1573_fu_3088_p0.read()) * sc_biguint<25>(ap_const_lv25_E3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1574_fu_1669_p0() {
    mul_ln1118_1574_fu_1669_p0 =  (sc_lv<16>) (sext_ln1118_1108_fu_10336968_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1574_fu_1669_p2() {
    mul_ln1118_1574_fu_1669_p2 = (!mul_ln1118_1574_fu_1669_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1574_fu_1669_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1575_fu_2766_p0() {
    mul_ln1118_1575_fu_2766_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1575_fu_2766_p2() {
    mul_ln1118_1575_fu_2766_p2 = (!mul_ln1118_1575_fu_2766_p0.read().is_01() || !ap_const_lv25_BB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1575_fu_2766_p0.read()) * sc_biguint<25>(ap_const_lv25_BB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1576_fu_1894_p0() {
    mul_ln1118_1576_fu_1894_p0 =  (sc_lv<16>) (sext_ln1118_1112_fu_10337003_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1576_fu_1894_p2() {
    mul_ln1118_1576_fu_1894_p2 = (!mul_ln1118_1576_fu_1894_p0.read().is_01() || !ap_const_lv23_7FFFC3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1576_fu_1894_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1577_fu_3073_p0() {
    mul_ln1118_1577_fu_3073_p0 =  (sc_lv<16>) (sext_ln1118_1110_fu_10336983_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1577_fu_3073_p2() {
    mul_ln1118_1577_fu_3073_p2 = (!mul_ln1118_1577_fu_3073_p0.read().is_01() || !ap_const_lv25_1FFFF4E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1577_fu_3073_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1578_fu_1654_p0() {
    mul_ln1118_1578_fu_1654_p0 = sext_ln1118_1111_fu_10336998_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1578_fu_1654_p2() {
    mul_ln1118_1578_fu_1654_p2 = (!mul_ln1118_1578_fu_1654_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1578_fu_1654_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1579_fu_2122_p0() {
    mul_ln1118_1579_fu_2122_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1579_fu_2122_p2() {
    mul_ln1118_1579_fu_2122_p2 = (!mul_ln1118_1579_fu_2122_p0.read().is_01() || !ap_const_lv24_6D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1579_fu_2122_p0.read()) * sc_biguint<24>(ap_const_lv24_6D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1580_fu_2590_p0() {
    mul_ln1118_1580_fu_2590_p0 =  (sc_lv<16>) (sext_ln1118_1126_fu_10337599_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1580_fu_2590_p2() {
    mul_ln1118_1580_fu_2590_p2 = (!mul_ln1118_1580_fu_2590_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1580_fu_2590_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1581_fu_2218_p0() {
    mul_ln1118_1581_fu_2218_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1581_fu_2218_p2() {
    mul_ln1118_1581_fu_2218_p2 = (!mul_ln1118_1581_fu_2218_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1581_fu_2218_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1582_fu_2057_p0() {
    mul_ln1118_1582_fu_2057_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1582_fu_2057_p2() {
    mul_ln1118_1582_fu_2057_p2 = (!mul_ln1118_1582_fu_2057_p0.read().is_01() || !ap_const_lv25_1FFFF72.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1582_fu_2057_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1583_fu_3154_p0() {
    mul_ln1118_1583_fu_3154_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1583_fu_3154_p2() {
    mul_ln1118_1583_fu_3154_p2 = (!mul_ln1118_1583_fu_3154_p0.read().is_01() || !ap_const_lv24_FFFF98.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1583_fu_3154_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1584_fu_2364_p0() {
    mul_ln1118_1584_fu_2364_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1584_fu_2364_p2() {
    mul_ln1118_1584_fu_2364_p2 = (!mul_ln1118_1584_fu_2364_p0.read().is_01() || !ap_const_lv25_D2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1584_fu_2364_p0.read()) * sc_biguint<25>(ap_const_lv25_D2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1585_fu_2832_p0() {
    mul_ln1118_1585_fu_2832_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1585_fu_2832_p2() {
    mul_ln1118_1585_fu_2832_p2 = (!mul_ln1118_1585_fu_2832_p0.read().is_01() || !ap_const_lv25_E5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1585_fu_2832_p0.read()) * sc_biguint<25>(ap_const_lv25_E5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1586_fu_3443_p0() {
    mul_ln1118_1586_fu_3443_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1586_fu_3443_p2() {
    mul_ln1118_1586_fu_3443_p2 = (!mul_ln1118_1586_fu_3443_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1586_fu_3443_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1587_fu_2510_p0() {
    mul_ln1118_1587_fu_2510_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1587_fu_2510_p2() {
    mul_ln1118_1587_fu_2510_p2 = (!mul_ln1118_1587_fu_2510_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1587_fu_2510_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1588_fu_2349_p0() {
    mul_ln1118_1588_fu_2349_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1588_fu_2349_p2() {
    mul_ln1118_1588_fu_2349_p2 = (!mul_ln1118_1588_fu_2349_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1588_fu_2349_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1589_fu_3446_p0() {
    mul_ln1118_1589_fu_3446_p0 =  (sc_lv<16>) (sext_ln1118_1127_fu_10337604_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1589_fu_3446_p2() {
    mul_ln1118_1589_fu_3446_p2 = (!mul_ln1118_1589_fu_3446_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1589_fu_3446_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1590_fu_2170_p0() {
    mul_ln1118_1590_fu_2170_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1590_fu_2170_p2() {
    mul_ln1118_1590_fu_2170_p2 = (!mul_ln1118_1590_fu_2170_p0.read().is_01() || !ap_const_lv24_64.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1590_fu_2170_p0.read()) * sc_biguint<24>(ap_const_lv24_64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1591_fu_1866_p0() {
    mul_ln1118_1591_fu_1866_p0 =  (sc_lv<16>) (sext_ln1118_1123_fu_10337581_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1591_fu_1866_p2() {
    mul_ln1118_1591_fu_1866_p2 = (!mul_ln1118_1591_fu_1866_p0.read().is_01() || !ap_const_lv24_56.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1591_fu_1866_p0.read()) * sc_biguint<24>(ap_const_lv24_56);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1592_fu_2334_p0() {
    mul_ln1118_1592_fu_2334_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1592_fu_2334_p2() {
    mul_ln1118_1592_fu_2334_p2 = (!mul_ln1118_1592_fu_2334_p0.read().is_01() || !ap_const_lv25_C1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1592_fu_2334_p0.read()) * sc_biguint<25>(ap_const_lv25_C1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1593_fu_2173_p0() {
    mul_ln1118_1593_fu_2173_p0 = sext_ln1118_1121_fu_10337561_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1593_fu_2173_p2() {
    mul_ln1118_1593_fu_2173_p2 = (!mul_ln1118_1593_fu_2173_p0.read().is_01() || !ap_const_lv26_111.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1593_fu_2173_p0.read()) * sc_biguint<26>(ap_const_lv26_111);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1594_fu_2641_p0() {
    mul_ln1118_1594_fu_2641_p0 =  (sc_lv<16>) (sext_ln1118_1127_fu_10337604_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1594_fu_2641_p2() {
    mul_ln1118_1594_fu_2641_p2 = (!mul_ln1118_1594_fu_2641_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1594_fu_2641_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1595_fu_2393_p0() {
    mul_ln1118_1595_fu_2393_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1595_fu_2393_p2() {
    mul_ln1118_1595_fu_2393_p2 = (!mul_ln1118_1595_fu_2393_p0.read().is_01() || !ap_const_lv25_D0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1595_fu_2393_p0.read()) * sc_biguint<25>(ap_const_lv25_D0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1596_fu_2884_p0() {
    mul_ln1118_1596_fu_2884_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1596_fu_2884_p2() {
    mul_ln1118_1596_fu_2884_p2 = (!mul_ln1118_1596_fu_2884_p0.read().is_01() || !ap_const_lv25_99.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1596_fu_2884_p0.read()) * sc_biguint<25>(ap_const_lv25_99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1597_fu_2885_p0() {
    mul_ln1118_1597_fu_2885_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1597_fu_2885_p2() {
    mul_ln1118_1597_fu_2885_p2 = (!mul_ln1118_1597_fu_2885_p0.read().is_01() || !ap_const_lv25_F3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1597_fu_2885_p0.read()) * sc_biguint<25>(ap_const_lv25_F3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1598_fu_2886_p0() {
    mul_ln1118_1598_fu_2886_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1598_fu_2886_p2() {
    mul_ln1118_1598_fu_2886_p2 = (!mul_ln1118_1598_fu_2886_p0.read().is_01() || !ap_const_lv25_C8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1598_fu_2886_p0.read()) * sc_biguint<25>(ap_const_lv25_C8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1599_fu_2709_p0() {
    mul_ln1118_1599_fu_2709_p0 =  (sc_lv<16>) (sext_ln1118_1122_fu_10337566_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1599_fu_2709_p2() {
    mul_ln1118_1599_fu_2709_p2 = (!mul_ln1118_1599_fu_2709_p0.read().is_01() || !ap_const_lv25_1FFFF3A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1599_fu_2709_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1600_fu_2888_p0() {
    mul_ln1118_1600_fu_2888_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1600_fu_2888_p2() {
    mul_ln1118_1600_fu_2888_p2 = (!mul_ln1118_1600_fu_2888_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1600_fu_2888_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1601_fu_3379_p0() {
    mul_ln1118_1601_fu_3379_p0 =  (sc_lv<16>) (sext_ln1118_1140_fu_10338200_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1601_fu_3379_p2() {
    mul_ln1118_1601_fu_3379_p2 = (!mul_ln1118_1601_fu_3379_p0.read().is_01() || !ap_const_lv26_3FFFE5D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1601_fu_3379_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1602_fu_2890_p0() {
    mul_ln1118_1602_fu_2890_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1602_fu_2890_p2() {
    mul_ln1118_1602_fu_2890_p2 = (!mul_ln1118_1602_fu_2890_p0.read().is_01() || !ap_const_lv25_D1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1602_fu_2890_p0.read()) * sc_biguint<25>(ap_const_lv25_D1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1603_fu_2401_p0() {
    mul_ln1118_1603_fu_2401_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1603_fu_2401_p2() {
    mul_ln1118_1603_fu_2401_p2 = (!mul_ln1118_1603_fu_2401_p0.read().is_01() || !ap_const_lv25_1FFFF39.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1603_fu_2401_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1604_fu_2892_p0() {
    mul_ln1118_1604_fu_2892_p0 =  (sc_lv<16>) (sext_ln1118_1143_fu_10338229_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1604_fu_2892_p2() {
    mul_ln1118_1604_fu_2892_p2 = (!mul_ln1118_1604_fu_2892_p0.read().is_01() || !ap_const_lv24_FFFFAA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1604_fu_2892_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1605_fu_2893_p0() {
    mul_ln1118_1605_fu_2893_p0 =  (sc_lv<16>) (sext_ln1118_1140_fu_10338200_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1605_fu_2893_p2() {
    mul_ln1118_1605_fu_2893_p2 = (!mul_ln1118_1605_fu_2893_p0.read().is_01() || !ap_const_lv26_3FFFDFD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1605_fu_2893_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDFD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1606_fu_2894_p0() {
    mul_ln1118_1606_fu_2894_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1606_fu_2894_p2() {
    mul_ln1118_1606_fu_2894_p2 = (!mul_ln1118_1606_fu_2894_p0.read().is_01() || !ap_const_lv25_1FFFF7D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1606_fu_2894_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1607_fu_2405_p0() {
    mul_ln1118_1607_fu_2405_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1607_fu_2405_p2() {
    mul_ln1118_1607_fu_2405_p2 = (!mul_ln1118_1607_fu_2405_p0.read().is_01() || !ap_const_lv25_F5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1607_fu_2405_p0.read()) * sc_biguint<25>(ap_const_lv25_F5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1608_fu_2317_p0() {
    mul_ln1118_1608_fu_2317_p0 =  (sc_lv<16>) (sext_ln1118_1144_fu_10338237_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1608_fu_2317_p2() {
    mul_ln1118_1608_fu_2317_p2 = (!mul_ln1118_1608_fu_2317_p0.read().is_01() || !ap_const_lv23_23.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1608_fu_2317_p0.read()) * sc_biguint<23>(ap_const_lv23_23);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1609_fu_2407_p0() {
    mul_ln1118_1609_fu_2407_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1609_fu_2407_p2() {
    mul_ln1118_1609_fu_2407_p2 = (!mul_ln1118_1609_fu_2407_p0.read().is_01() || !ap_const_lv25_EA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1609_fu_2407_p0.read()) * sc_biguint<25>(ap_const_lv25_EA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1610_fu_2898_p0() {
    mul_ln1118_1610_fu_2898_p0 = sext_ln1118_1142_fu_10338224_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1610_fu_2898_p2() {
    mul_ln1118_1610_fu_2898_p2 = (!mul_ln1118_1610_fu_2898_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1610_fu_2898_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1611_fu_2409_p0() {
    mul_ln1118_1611_fu_2409_p0 =  (sc_lv<16>) (sext_ln1118_1144_fu_10338237_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1611_fu_2409_p2() {
    mul_ln1118_1611_fu_2409_p2 = (!mul_ln1118_1611_fu_2409_p0.read().is_01() || !ap_const_lv23_7FFFDD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1611_fu_2409_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1612_fu_2900_p0() {
    mul_ln1118_1612_fu_2900_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1612_fu_2900_p2() {
    mul_ln1118_1612_fu_2900_p2 = (!mul_ln1118_1612_fu_2900_p0.read().is_01() || !ap_const_lv25_1FFFF50.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1612_fu_2900_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF50);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1613_fu_2901_p0() {
    mul_ln1118_1613_fu_2901_p0 =  (sc_lv<16>) (sext_ln1118_1140_fu_10338200_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1613_fu_2901_p2() {
    mul_ln1118_1613_fu_2901_p2 = (!mul_ln1118_1613_fu_2901_p0.read().is_01() || !ap_const_lv26_14F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1613_fu_2901_p0.read()) * sc_biguint<26>(ap_const_lv26_14F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1614_fu_2902_p0() {
    mul_ln1118_1614_fu_2902_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1614_fu_2902_p2() {
    mul_ln1118_1614_fu_2902_p2 = (!mul_ln1118_1614_fu_2902_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1614_fu_2902_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1615_fu_3393_p0() {
    mul_ln1118_1615_fu_3393_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1615_fu_3393_p2() {
    mul_ln1118_1615_fu_3393_p2 = (!mul_ln1118_1615_fu_3393_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1615_fu_3393_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1616_fu_2414_p0() {
    mul_ln1118_1616_fu_2414_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1616_fu_2414_p2() {
    mul_ln1118_1616_fu_2414_p2 = (!mul_ln1118_1616_fu_2414_p0.read().is_01() || !ap_const_lv25_E9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1616_fu_2414_p0.read()) * sc_biguint<25>(ap_const_lv25_E9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1617_fu_2905_p0() {
    mul_ln1118_1617_fu_2905_p0 =  (sc_lv<16>) (sext_ln1118_1143_fu_10338229_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1617_fu_2905_p2() {
    mul_ln1118_1617_fu_2905_p2 = (!mul_ln1118_1617_fu_2905_p0.read().is_01() || !ap_const_lv24_FFFF91.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1617_fu_2905_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1618_fu_2906_p0() {
    mul_ln1118_1618_fu_2906_p0 =  (sc_lv<16>) (sext_ln1118_1144_fu_10338237_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1618_fu_2906_p2() {
    mul_ln1118_1618_fu_2906_p2 = (!mul_ln1118_1618_fu_2906_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1618_fu_2906_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1619_fu_2907_p0() {
    mul_ln1118_1619_fu_2907_p0 =  (sc_lv<16>) (sext_ln1118_1144_fu_10338237_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1619_fu_2907_p2() {
    mul_ln1118_1619_fu_2907_p2 = (!mul_ln1118_1619_fu_2907_p0.read().is_01() || !ap_const_lv23_7FFFC9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1619_fu_2907_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1620_fu_3309_p0() {
    mul_ln1118_1620_fu_3309_p0 =  (sc_lv<16>) (sext_ln1118_1143_fu_10338229_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1620_fu_3309_p2() {
    mul_ln1118_1620_fu_3309_p2 = (!mul_ln1118_1620_fu_3309_p0.read().is_01() || !ap_const_lv24_FFFFB3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1620_fu_3309_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1621_fu_2909_p0() {
    mul_ln1118_1621_fu_2909_p0 =  (sc_lv<16>) (sext_ln1118_1143_fu_10338229_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1621_fu_2909_p2() {
    mul_ln1118_1621_fu_2909_p2 = (!mul_ln1118_1621_fu_2909_p0.read().is_01() || !ap_const_lv24_FFFF92.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1621_fu_2909_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF92);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1622_fu_2821_p0() {
    mul_ln1118_1622_fu_2821_p0 =  (sc_lv<16>) (sext_ln1118_1141_fu_10338209_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1622_fu_2821_p2() {
    mul_ln1118_1622_fu_2821_p2 = (!mul_ln1118_1622_fu_2821_p0.read().is_01() || !ap_const_lv25_D8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1622_fu_2821_p0.read()) * sc_biguint<25>(ap_const_lv25_D8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1623_fu_2288_p0() {
    mul_ln1118_1623_fu_2288_p0 =  (sc_lv<16>) (sext_ln1118_1140_fu_10338200_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1623_fu_2288_p2() {
    mul_ln1118_1623_fu_2288_p2 = (!mul_ln1118_1623_fu_2288_p0.read().is_01() || !ap_const_lv26_125.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1623_fu_2288_p0.read()) * sc_biguint<26>(ap_const_lv26_125);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1624_fu_2674_p0() {
    mul_ln1118_1624_fu_2674_p0 =  (sc_lv<16>) (sext_ln1118_1140_fu_10338200_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1624_fu_2674_p2() {
    mul_ln1118_1624_fu_2674_p2 = (!mul_ln1118_1624_fu_2674_p0.read().is_01() || !ap_const_lv26_3FFFE67.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1624_fu_2674_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1625_fu_2595_p0() {
    mul_ln1118_1625_fu_2595_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1625_fu_2595_p2() {
    mul_ln1118_1625_fu_2595_p2 = (!mul_ln1118_1625_fu_2595_p0.read().is_01() || !ap_const_lv25_EE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1625_fu_2595_p0.read()) * sc_biguint<25>(ap_const_lv25_EE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1626_fu_2434_p0() {
    mul_ln1118_1626_fu_2434_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1626_fu_2434_p2() {
    mul_ln1118_1626_fu_2434_p2 = (!mul_ln1118_1626_fu_2434_p0.read().is_01() || !ap_const_lv24_46.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1626_fu_2434_p0.read()) * sc_biguint<24>(ap_const_lv24_46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1627_fu_1644_p0() {
    mul_ln1118_1627_fu_1644_p0 =  (sc_lv<16>) (sext_ln1118_1156_fu_10338778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1627_fu_1644_p2() {
    mul_ln1118_1627_fu_1644_p2 = (!mul_ln1118_1627_fu_1644_p0.read().is_01() || !ap_const_lv23_7FFFD1.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1627_fu_1644_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1628_fu_2112_p0() {
    mul_ln1118_1628_fu_2112_p0 =  (sc_lv<16>) (sext_ln1118_1157_fu_10338785_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1628_fu_2112_p2() {
    mul_ln1118_1628_fu_2112_p2 = (!mul_ln1118_1628_fu_2112_p0.read().is_01() || !ap_const_lv22_3FFFE9.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1628_fu_2112_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1629_fu_1951_p0() {
    mul_ln1118_1629_fu_1951_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1629_fu_1951_p2() {
    mul_ln1118_1629_fu_1951_p2 = (!mul_ln1118_1629_fu_1951_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1629_fu_1951_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1630_fu_3048_p0() {
    mul_ln1118_1630_fu_3048_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1630_fu_3048_p2() {
    mul_ln1118_1630_fu_3048_p2 = (!mul_ln1118_1630_fu_3048_p0.read().is_01() || !ap_const_lv24_FFFFA3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1630_fu_3048_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1631_fu_2887_p0() {
    mul_ln1118_1631_fu_2887_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1631_fu_2887_p2() {
    mul_ln1118_1631_fu_2887_p2 = (!mul_ln1118_1631_fu_2887_p0.read().is_01() || !ap_const_lv25_E5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1631_fu_2887_p0.read()) * sc_biguint<25>(ap_const_lv25_E5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1632_fu_2726_p0() {
    mul_ln1118_1632_fu_2726_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1632_fu_2726_p2() {
    mul_ln1118_1632_fu_2726_p2 = (!mul_ln1118_1632_fu_2726_p0.read().is_01() || !ap_const_lv25_A8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1632_fu_2726_p0.read()) * sc_biguint<25>(ap_const_lv25_A8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1633_fu_3194_p0() {
    mul_ln1118_1633_fu_3194_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1633_fu_3194_p2() {
    mul_ln1118_1633_fu_3194_p2 = (!mul_ln1118_1633_fu_3194_p0.read().is_01() || !ap_const_lv24_6E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1633_fu_3194_p0.read()) * sc_biguint<24>(ap_const_lv24_6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1634_fu_3033_p0() {
    mul_ln1118_1634_fu_3033_p0 =  (sc_lv<16>) (sext_ln1118_1156_fu_10338778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1634_fu_3033_p2() {
    mul_ln1118_1634_fu_3033_p2 = (!mul_ln1118_1634_fu_3033_p0.read().is_01() || !ap_const_lv23_7FFFC5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1634_fu_3033_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1635_fu_2243_p0() {
    mul_ln1118_1635_fu_2243_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1635_fu_2243_p2() {
    mul_ln1118_1635_fu_2243_p2 = (!mul_ln1118_1635_fu_2243_p0.read().is_01() || !ap_const_lv24_64.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1635_fu_2243_p0.read()) * sc_biguint<24>(ap_const_lv24_64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1636_fu_2137_p0() {
    mul_ln1118_1636_fu_2137_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1636_fu_2137_p2() {
    mul_ln1118_1636_fu_2137_p2 = (!mul_ln1118_1636_fu_2137_p0.read().is_01() || !ap_const_lv24_55.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1636_fu_2137_p0.read()) * sc_biguint<24>(ap_const_lv24_55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1637_fu_3234_p0() {
    mul_ln1118_1637_fu_3234_p0 =  (sc_lv<16>) (sext_ln1118_1153_fu_10338753_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1637_fu_3234_p2() {
    mul_ln1118_1637_fu_3234_p2 = (!mul_ln1118_1637_fu_3234_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1637_fu_3234_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1638_fu_1815_p0() {
    mul_ln1118_1638_fu_1815_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1638_fu_1815_p2() {
    mul_ln1118_1638_fu_1815_p2 = (!mul_ln1118_1638_fu_1815_p0.read().is_01() || !ap_const_lv25_1FFFF6C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1638_fu_1815_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1639_fu_2283_p0() {
    mul_ln1118_1639_fu_2283_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1639_fu_2283_p2() {
    mul_ln1118_1639_fu_2283_p2 = (!mul_ln1118_1639_fu_2283_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1639_fu_2283_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1640_fu_3380_p0() {
    mul_ln1118_1640_fu_3380_p0 =  (sc_lv<16>) (sext_ln1118_1156_fu_10338778_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1640_fu_3380_p2() {
    mul_ln1118_1640_fu_3380_p2 = (!mul_ln1118_1640_fu_3380_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1640_fu_3380_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1641_fu_2733_p0() {
    mul_ln1118_1641_fu_2733_p0 =  (sc_lv<16>) (sext_ln1118_1158_fu_10338791_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1641_fu_2733_p2() {
    mul_ln1118_1641_fu_2733_p2 = (!mul_ln1118_1641_fu_2733_p0.read().is_01() || !ap_const_lv21_1FFFF5.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1641_fu_2733_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1642_fu_1800_p0() {
    mul_ln1118_1642_fu_1800_p0 =  (sc_lv<16>) (sext_ln1118_1154_fu_10338763_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1642_fu_1800_p2() {
    mul_ln1118_1642_fu_1800_p2 = (!mul_ln1118_1642_fu_1800_p0.read().is_01() || !ap_const_lv25_B5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1642_fu_1800_p0.read()) * sc_biguint<25>(ap_const_lv25_B5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1643_fu_2897_p0() {
    mul_ln1118_1643_fu_2897_p0 =  (sc_lv<16>) (sext_ln1118_1157_fu_10338785_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1643_fu_2897_p2() {
    mul_ln1118_1643_fu_2897_p2 = (!mul_ln1118_1643_fu_2897_p0.read().is_01() || !ap_const_lv22_3FFFE6.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1643_fu_2897_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1644_fu_2736_p0() {
    mul_ln1118_1644_fu_2736_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1644_fu_2736_p2() {
    mul_ln1118_1644_fu_2736_p2 = (!mul_ln1118_1644_fu_2736_p0.read().is_01() || !ap_const_lv24_FFFFA8.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1644_fu_2736_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1645_fu_3204_p0() {
    mul_ln1118_1645_fu_3204_p0 = sext_ln1118_1168_fu_10339356_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1645_fu_3204_p2() {
    mul_ln1118_1645_fu_3204_p2 = (!mul_ln1118_1645_fu_3204_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1645_fu_3204_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1646_fu_2472_p0() {
    mul_ln1118_1646_fu_2472_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1646_fu_2472_p2() {
    mul_ln1118_1646_fu_2472_p2 = (!mul_ln1118_1646_fu_2472_p0.read().is_01() || !ap_const_lv24_FFFFBD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1646_fu_2472_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1647_fu_2882_p0() {
    mul_ln1118_1647_fu_2882_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1647_fu_2882_p2() {
    mul_ln1118_1647_fu_2882_p2 = (!mul_ln1118_1647_fu_2882_p0.read().is_01() || !ap_const_lv25_1FFFF6D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1647_fu_2882_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1648_fu_2092_p0() {
    mul_ln1118_1648_fu_2092_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1648_fu_2092_p2() {
    mul_ln1118_1648_fu_2092_p2 = (!mul_ln1118_1648_fu_2092_p0.read().is_01() || !ap_const_lv25_E6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1648_fu_2092_p0.read()) * sc_biguint<25>(ap_const_lv25_E6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1649_fu_1931_p0() {
    mul_ln1118_1649_fu_1931_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1649_fu_1931_p2() {
    mul_ln1118_1649_fu_1931_p2 = (!mul_ln1118_1649_fu_1931_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1649_fu_1931_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1650_fu_3028_p0() {
    mul_ln1118_1650_fu_3028_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1650_fu_3028_p2() {
    mul_ln1118_1650_fu_3028_p2 = (!mul_ln1118_1650_fu_3028_p0.read().is_01() || !ap_const_lv25_D2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1650_fu_3028_p0.read()) * sc_biguint<25>(ap_const_lv25_D2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1651_fu_2980_p0() {
    mul_ln1118_1651_fu_2980_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1651_fu_2980_p2() {
    mul_ln1118_1651_fu_2980_p2 = (!mul_ln1118_1651_fu_2980_p0.read().is_01() || !ap_const_lv25_1FFFF62.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1651_fu_2980_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1652_fu_2001_p0() {
    mul_ln1118_1652_fu_2001_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1652_fu_2001_p2() {
    mul_ln1118_1652_fu_2001_p2 = (!mul_ln1118_1652_fu_2001_p0.read().is_01() || !ap_const_lv24_58.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1652_fu_2001_p0.read()) * sc_biguint<24>(ap_const_lv24_58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1653_fu_2002_p0() {
    mul_ln1118_1653_fu_2002_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1653_fu_2002_p2() {
    mul_ln1118_1653_fu_2002_p2 = (!mul_ln1118_1653_fu_2002_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1653_fu_2002_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1654_fu_3562_p0() {
    mul_ln1118_1654_fu_3562_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1654_fu_3562_p2() {
    mul_ln1118_1654_fu_3562_p2 = (!mul_ln1118_1654_fu_3562_p0.read().is_01() || !ap_const_lv25_ED.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1654_fu_3562_p0.read()) * sc_biguint<25>(ap_const_lv25_ED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1655_fu_2004_p0() {
    mul_ln1118_1655_fu_2004_p0 = sext_ln1118_1171_fu_10339378_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1655_fu_2004_p2() {
    mul_ln1118_1655_fu_2004_p2 = (!mul_ln1118_1655_fu_2004_p0.read().is_01() || !ap_const_lv22_3FFFEB.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1655_fu_2004_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1656_fu_2495_p0() {
    mul_ln1118_1656_fu_2495_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1656_fu_2495_p2() {
    mul_ln1118_1656_fu_2495_p2 = (!mul_ln1118_1656_fu_2495_p0.read().is_01() || !ap_const_lv24_6C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1656_fu_2495_p0.read()) * sc_biguint<24>(ap_const_lv24_6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1657_fu_2986_p0() {
    mul_ln1118_1657_fu_2986_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1657_fu_2986_p2() {
    mul_ln1118_1657_fu_2986_p2 = (!mul_ln1118_1657_fu_2986_p0.read().is_01() || !ap_const_lv25_8E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1657_fu_2986_p0.read()) * sc_biguint<25>(ap_const_lv25_8E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1658_fu_2987_p0() {
    mul_ln1118_1658_fu_2987_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1658_fu_2987_p2() {
    mul_ln1118_1658_fu_2987_p2 = (!mul_ln1118_1658_fu_2987_p0.read().is_01() || !ap_const_lv24_FFFFB7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1658_fu_2987_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1659_fu_2988_p0() {
    mul_ln1118_1659_fu_2988_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1659_fu_2988_p2() {
    mul_ln1118_1659_fu_2988_p2 = (!mul_ln1118_1659_fu_2988_p0.read().is_01() || !ap_const_lv24_FFFFB3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1659_fu_2988_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1660_fu_2499_p0() {
    mul_ln1118_1660_fu_2499_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1660_fu_2499_p2() {
    mul_ln1118_1660_fu_2499_p2 = (!mul_ln1118_1660_fu_2499_p0.read().is_01() || !ap_const_lv25_E5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1660_fu_2499_p0.read()) * sc_biguint<25>(ap_const_lv25_E5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1661_fu_2010_p0() {
    mul_ln1118_1661_fu_2010_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1661_fu_2010_p2() {
    mul_ln1118_1661_fu_2010_p2 = (!mul_ln1118_1661_fu_2010_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1661_fu_2010_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1662_fu_2011_p0() {
    mul_ln1118_1662_fu_2011_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1662_fu_2011_p2() {
    mul_ln1118_1662_fu_2011_p2 = (!mul_ln1118_1662_fu_2011_p0.read().is_01() || !ap_const_lv25_D0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1662_fu_2011_p0.read()) * sc_biguint<25>(ap_const_lv25_D0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1663_fu_3571_p0() {
    mul_ln1118_1663_fu_3571_p0 =  (sc_lv<16>) (sext_ln1118_1169_fu_10339361_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1663_fu_3571_p2() {
    mul_ln1118_1663_fu_3571_p2 = (!mul_ln1118_1663_fu_3571_p0.read().is_01() || !ap_const_lv24_45.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1663_fu_3571_p0.read()) * sc_biguint<24>(ap_const_lv24_45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1664_fu_2013_p0() {
    mul_ln1118_1664_fu_2013_p0 =  (sc_lv<16>) (sext_ln1118_1167_fu_10339342_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1664_fu_2013_p2() {
    mul_ln1118_1664_fu_2013_p2 = (!mul_ln1118_1664_fu_2013_p0.read().is_01() || !ap_const_lv25_1FFFF48.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1664_fu_2013_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF48);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1665_fu_2014_p0() {
    mul_ln1118_1665_fu_2014_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1665_fu_2014_p2() {
    mul_ln1118_1665_fu_2014_p2 = (!mul_ln1118_1665_fu_2014_p0.read().is_01() || !ap_const_lv24_5A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1665_fu_2014_p0.read()) * sc_biguint<24>(ap_const_lv24_5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1666_fu_2505_p0() {
    mul_ln1118_1666_fu_2505_p0 =  (sc_lv<16>) (sext_ln1118_1178_fu_10339828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1666_fu_2505_p2() {
    mul_ln1118_1666_fu_2505_p2 = (!mul_ln1118_1666_fu_2505_p0.read().is_01() || !ap_const_lv23_7FFFC3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1666_fu_2505_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1667_fu_3575_p0() {
    mul_ln1118_1667_fu_3575_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1667_fu_3575_p2() {
    mul_ln1118_1667_fu_3575_p2 = (!mul_ln1118_1667_fu_3575_p0.read().is_01() || !ap_const_lv25_DB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1667_fu_3575_p0.read()) * sc_biguint<25>(ap_const_lv25_DB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1668_fu_2507_p0() {
    mul_ln1118_1668_fu_2507_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1668_fu_2507_p2() {
    mul_ln1118_1668_fu_2507_p2 = (!mul_ln1118_1668_fu_2507_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1668_fu_2507_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1669_fu_2508_p0() {
    mul_ln1118_1669_fu_2508_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1669_fu_2508_p2() {
    mul_ln1118_1669_fu_2508_p2 = (!mul_ln1118_1669_fu_2508_p0.read().is_01() || !ap_const_lv25_B2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1669_fu_2508_p0.read()) * sc_biguint<25>(ap_const_lv25_B2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1670_fu_2019_p0() {
    mul_ln1118_1670_fu_2019_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1670_fu_2019_p2() {
    mul_ln1118_1670_fu_2019_p2 = (!mul_ln1118_1670_fu_2019_p0.read().is_01() || !ap_const_lv24_FFFF8F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1670_fu_2019_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1671_fu_2020_p0() {
    mul_ln1118_1671_fu_2020_p0 =  (sc_lv<16>) (sext_ln1118_1178_fu_10339828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1671_fu_2020_p2() {
    mul_ln1118_1671_fu_2020_p2 = (!mul_ln1118_1671_fu_2020_p0.read().is_01() || !ap_const_lv23_31.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1671_fu_2020_p0.read()) * sc_biguint<23>(ap_const_lv23_31);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1672_fu_2021_p0() {
    mul_ln1118_1672_fu_2021_p0 =  (sc_lv<16>) (sext_ln1118_1179_fu_10339835_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1672_fu_2021_p2() {
    mul_ln1118_1672_fu_2021_p2 = (!mul_ln1118_1672_fu_2021_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1672_fu_2021_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1673_fu_3002_p0() {
    mul_ln1118_1673_fu_3002_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1673_fu_3002_p2() {
    mul_ln1118_1673_fu_3002_p2 = (!mul_ln1118_1673_fu_3002_p0.read().is_01() || !ap_const_lv24_46.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1673_fu_3002_p0.read()) * sc_biguint<24>(ap_const_lv24_46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1674_fu_3003_p0() {
    mul_ln1118_1674_fu_3003_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1674_fu_3003_p2() {
    mul_ln1118_1674_fu_3003_p2 = (!mul_ln1118_1674_fu_3003_p0.read().is_01() || !ap_const_lv24_51.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1674_fu_3003_p0.read()) * sc_biguint<24>(ap_const_lv24_51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1675_fu_3004_p0() {
    mul_ln1118_1675_fu_3004_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1675_fu_3004_p2() {
    mul_ln1118_1675_fu_3004_p2 = (!mul_ln1118_1675_fu_3004_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1675_fu_3004_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1676_fu_1936_p0() {
    mul_ln1118_1676_fu_1936_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1676_fu_1936_p2() {
    mul_ln1118_1676_fu_1936_p2 = (!mul_ln1118_1676_fu_1936_p0.read().is_01() || !ap_const_lv25_D0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1676_fu_1936_p0.read()) * sc_biguint<25>(ap_const_lv25_D0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1677_fu_2516_p0() {
    mul_ln1118_1677_fu_2516_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1677_fu_2516_p2() {
    mul_ln1118_1677_fu_2516_p2 = (!mul_ln1118_1677_fu_2516_p0.read().is_01() || !ap_const_lv25_B3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1677_fu_2516_p0.read()) * sc_biguint<25>(ap_const_lv25_B3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1678_fu_3199_p0() {
    mul_ln1118_1678_fu_3199_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1678_fu_3199_p2() {
    mul_ln1118_1678_fu_3199_p2 = (!mul_ln1118_1678_fu_3199_p0.read().is_01() || !ap_const_lv25_1FFFF4E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1678_fu_3199_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1679_fu_1698_p0() {
    mul_ln1118_1679_fu_1698_p0 =  (sc_lv<16>) (sext_ln1118_1178_fu_10339828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1679_fu_1698_p2() {
    mul_ln1118_1679_fu_1698_p2 = (!mul_ln1118_1679_fu_1698_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1679_fu_1698_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1680_fu_2248_p0() {
    mul_ln1118_1680_fu_2248_p0 =  (sc_lv<16>) (sext_ln1118_1179_fu_10339835_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1680_fu_2248_p2() {
    mul_ln1118_1680_fu_2248_p2 = (!mul_ln1118_1680_fu_2248_p0.read().is_01() || !ap_const_lv22_3FFFE5.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1680_fu_2248_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1681_fu_2005_p0() {
    mul_ln1118_1681_fu_2005_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1681_fu_2005_p2() {
    mul_ln1118_1681_fu_2005_p2 = (!mul_ln1118_1681_fu_2005_p0.read().is_01() || !ap_const_lv25_E3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1681_fu_2005_p0.read()) * sc_biguint<25>(ap_const_lv25_E3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1682_fu_2555_p0() {
    mul_ln1118_1682_fu_2555_p0 =  (sc_lv<16>) (sext_ln1118_1176_fu_10339805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1682_fu_2555_p2() {
    mul_ln1118_1682_fu_2555_p2 = (!mul_ln1118_1682_fu_2555_p0.read().is_01() || !ap_const_lv25_1FFFF4F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1682_fu_2555_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1683_fu_3652_p0() {
    mul_ln1118_1683_fu_3652_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1683_fu_3652_p2() {
    mul_ln1118_1683_fu_3652_p2 = (!mul_ln1118_1683_fu_3652_p0.read().is_01() || !ap_const_lv24_FFFF95.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1683_fu_3652_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1684_fu_2233_p0() {
    mul_ln1118_1684_fu_2233_p0 =  (sc_lv<16>) (sext_ln1118_1177_fu_10339816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1684_fu_2233_p2() {
    mul_ln1118_1684_fu_2233_p2 = (!mul_ln1118_1684_fu_2233_p0.read().is_01() || !ap_const_lv24_4F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1684_fu_2233_p0.read()) * sc_biguint<24>(ap_const_lv24_4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1685_fu_3330_p0() {
    mul_ln1118_1685_fu_3330_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1685_fu_3330_p2() {
    mul_ln1118_1685_fu_3330_p2 = (!mul_ln1118_1685_fu_3330_p0.read().is_01() || !ap_const_lv26_3FFFDC7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1685_fu_3330_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDC7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1686_fu_1911_p0() {
    mul_ln1118_1686_fu_1911_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1686_fu_1911_p2() {
    mul_ln1118_1686_fu_1911_p2 = (!mul_ln1118_1686_fu_1911_p0.read().is_01() || !ap_const_lv26_3FFFEC1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1686_fu_1911_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1687_fu_1750_p0() {
    mul_ln1118_1687_fu_1750_p0 =  (sc_lv<16>) (sext_ln1118_1194_fu_10340403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1687_fu_1750_p2() {
    mul_ln1118_1687_fu_1750_p2 = (!mul_ln1118_1687_fu_1750_p0.read().is_01() || !ap_const_lv24_FFFFA7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1687_fu_1750_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1688_fu_3476_p0() {
    mul_ln1118_1688_fu_3476_p0 =  (sc_lv<16>) (sext_ln1118_1194_fu_10340403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1688_fu_3476_p2() {
    mul_ln1118_1688_fu_3476_p2 = (!mul_ln1118_1688_fu_3476_p0.read().is_01() || !ap_const_lv24_5F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1688_fu_3476_p0.read()) * sc_biguint<24>(ap_const_lv24_5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1689_fu_3315_p0() {
    mul_ln1118_1689_fu_3315_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1689_fu_3315_p2() {
    mul_ln1118_1689_fu_3315_p2 = (!mul_ln1118_1689_fu_3315_p0.read().is_01() || !ap_const_lv26_178.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1689_fu_3315_p0.read()) * sc_biguint<26>(ap_const_lv26_178);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1690_fu_1896_p0() {
    mul_ln1118_1690_fu_1896_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1690_fu_1896_p2() {
    mul_ln1118_1690_fu_1896_p2 = (!mul_ln1118_1690_fu_1896_p0.read().is_01() || !ap_const_lv25_1FFFF27.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1690_fu_1896_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1691_fu_3114_p0() {
    mul_ln1118_1691_fu_3114_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1691_fu_3114_p2() {
    mul_ln1118_1691_fu_3114_p2 = (!mul_ln1118_1691_fu_3114_p0.read().is_01() || !ap_const_lv25_A4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1691_fu_3114_p0.read()) * sc_biguint<25>(ap_const_lv25_A4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1692_fu_2667_p0() {
    mul_ln1118_1692_fu_2667_p0 =  (sc_lv<16>) (sext_ln1118_1192_fu_10340385_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1692_fu_2667_p2() {
    mul_ln1118_1692_fu_2667_p2 = (!mul_ln1118_1692_fu_2667_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1692_fu_2667_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1693_fu_2506_p0() {
    mul_ln1118_1693_fu_2506_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1693_fu_2506_p2() {
    mul_ln1118_1693_fu_2506_p2 = (!mul_ln1118_1693_fu_2506_p0.read().is_01() || !ap_const_lv25_1FFFF2D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1693_fu_2506_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1694_fu_2345_p0() {
    mul_ln1118_1694_fu_2345_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1694_fu_2345_p2() {
    mul_ln1118_1694_fu_2345_p2 = (!mul_ln1118_1694_fu_2345_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1694_fu_2345_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1695_fu_3442_p0() {
    mul_ln1118_1695_fu_3442_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1695_fu_3442_p2() {
    mul_ln1118_1695_fu_3442_p2 = (!mul_ln1118_1695_fu_3442_p0.read().is_01() || !ap_const_lv26_3FFFD8A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1695_fu_3442_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1696_fu_3281_p0() {
    mul_ln1118_1696_fu_3281_p0 =  (sc_lv<16>) (sext_ln1118_1191_fu_10340378_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1696_fu_3281_p2() {
    mul_ln1118_1696_fu_3281_p2 = (!mul_ln1118_1696_fu_3281_p0.read().is_01() || !ap_const_lv23_7FFFD5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1696_fu_3281_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1697_fu_1862_p0() {
    mul_ln1118_1697_fu_1862_p0 =  (sc_lv<16>) (sext_ln1118_1191_fu_10340378_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1697_fu_1862_p2() {
    mul_ln1118_1697_fu_1862_p2 = (!mul_ln1118_1697_fu_1862_p0.read().is_01() || !ap_const_lv23_2A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1697_fu_1862_p0.read()) * sc_biguint<23>(ap_const_lv23_2A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1698_fu_2330_p0() {
    mul_ln1118_1698_fu_2330_p0 =  (sc_lv<16>) (sext_ln1118_1194_fu_10340403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1698_fu_2330_p2() {
    mul_ln1118_1698_fu_2330_p2 = (!mul_ln1118_1698_fu_2330_p0.read().is_01() || !ap_const_lv24_FFFFA6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1698_fu_2330_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1699_fu_2169_p0() {
    mul_ln1118_1699_fu_2169_p0 =  (sc_lv<16>) (sext_ln1118_1191_fu_10340378_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1699_fu_2169_p2() {
    mul_ln1118_1699_fu_2169_p2 = (!mul_ln1118_1699_fu_2169_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1699_fu_2169_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1700_fu_3266_p0() {
    mul_ln1118_1700_fu_3266_p0 = sext_ln1118_1190_fu_10340373_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1700_fu_3266_p2() {
    mul_ln1118_1700_fu_3266_p2 = (!mul_ln1118_1700_fu_3266_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1700_fu_3266_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1701_fu_1990_p0() {
    mul_ln1118_1701_fu_1990_p0 =  (sc_lv<16>) (sext_ln1118_1192_fu_10340385_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1701_fu_1990_p2() {
    mul_ln1118_1701_fu_1990_p2 = (!mul_ln1118_1701_fu_1990_p0.read().is_01() || !ap_const_lv22_16.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1701_fu_1990_p0.read()) * sc_biguint<22>(ap_const_lv22_16);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1702_fu_2944_p0() {
    mul_ln1118_1702_fu_2944_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1702_fu_2944_p2() {
    mul_ln1118_1702_fu_2944_p2 = (!mul_ln1118_1702_fu_2944_p0.read().is_01() || !ap_const_lv26_3FFFE3F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1702_fu_2944_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE3F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1703_fu_2783_p0() {
    mul_ln1118_1703_fu_2783_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1703_fu_2783_p2() {
    mul_ln1118_1703_fu_2783_p2 = (!mul_ln1118_1703_fu_2783_p0.read().is_01() || !ap_const_lv25_1FFFF53.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1703_fu_2783_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1704_fu_2765_p0() {
    mul_ln1118_1704_fu_2765_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1704_fu_2765_p2() {
    mul_ln1118_1704_fu_2765_p2 = (!mul_ln1118_1704_fu_2765_p0.read().is_01() || !ap_const_lv25_CA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1704_fu_2765_p0.read()) * sc_biguint<25>(ap_const_lv25_CA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1705_fu_2461_p0() {
    mul_ln1118_1705_fu_2461_p0 =  (sc_lv<16>) (sext_ln1118_1194_fu_10340403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1705_fu_2461_p2() {
    mul_ln1118_1705_fu_2461_p2 = (!mul_ln1118_1705_fu_2461_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1705_fu_2461_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1706_fu_3165_p0() {
    mul_ln1118_1706_fu_3165_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1706_fu_3165_p2() {
    mul_ln1118_1706_fu_3165_p2 = (!mul_ln1118_1706_fu_3165_p0.read().is_01() || !ap_const_lv26_3FFFDEC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1706_fu_3165_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDEC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1707_fu_3166_p0() {
    mul_ln1118_1707_fu_3166_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1707_fu_3166_p2() {
    mul_ln1118_1707_fu_3166_p2 = (!mul_ln1118_1707_fu_3166_p0.read().is_01() || !ap_const_lv25_D1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1707_fu_3166_p0.read()) * sc_biguint<25>(ap_const_lv25_D1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1708_fu_3167_p0() {
    mul_ln1118_1708_fu_3167_p0 =  (sc_lv<16>) (sext_ln1118_1193_fu_10340391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1708_fu_3167_p2() {
    mul_ln1118_1708_fu_3167_p2 = (!mul_ln1118_1708_fu_3167_p0.read().is_01() || !ap_const_lv25_97.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1708_fu_3167_p0.read()) * sc_biguint<25>(ap_const_lv25_97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1709_fu_2678_p0() {
    mul_ln1118_1709_fu_2678_p0 =  (sc_lv<16>) (sext_ln1118_1195_fu_10340411_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1709_fu_2678_p2() {
    mul_ln1118_1709_fu_2678_p2 = (!mul_ln1118_1709_fu_2678_p0.read().is_01() || !ap_const_lv26_271.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1709_fu_2678_p0.read()) * sc_biguint<26>(ap_const_lv26_271);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1710_fu_3169_p0() {
    mul_ln1118_1710_fu_3169_p0 =  (sc_lv<16>) (sext_ln1118_1204_fu_10340942_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1710_fu_3169_p2() {
    mul_ln1118_1710_fu_3169_p2 = (!mul_ln1118_1710_fu_3169_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1710_fu_3169_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1711_fu_3170_p0() {
    mul_ln1118_1711_fu_3170_p0 =  (sc_lv<16>) (sext_ln1118_1203_fu_10340934_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1711_fu_3170_p2() {
    mul_ln1118_1711_fu_3170_p2 = (!mul_ln1118_1711_fu_3170_p0.read().is_01() || !ap_const_lv26_145.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1711_fu_3170_p0.read()) * sc_biguint<26>(ap_const_lv26_145);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1712_fu_3171_p0() {
    mul_ln1118_1712_fu_3171_p0 =  (sc_lv<16>) (sext_ln1118_1203_fu_10340934_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1712_fu_3171_p2() {
    mul_ln1118_1712_fu_3171_p2 = (!mul_ln1118_1712_fu_3171_p0.read().is_01() || !ap_const_lv26_3FFFEDE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1712_fu_3171_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1713_fu_3083_p0() {
    mul_ln1118_1713_fu_3083_p0 =  (sc_lv<16>) (sext_ln1118_1204_fu_10340942_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1713_fu_3083_p2() {
    mul_ln1118_1713_fu_3083_p2 = (!mul_ln1118_1713_fu_3083_p0.read().is_01() || !ap_const_lv23_7FFFCA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1713_fu_3083_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1714_fu_3173_p0() {
    mul_ln1118_1714_fu_3173_p0 =  (sc_lv<16>) (sext_ln1118_1205_fu_10340950_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1714_fu_3173_p2() {
    mul_ln1118_1714_fu_3173_p2 = (!mul_ln1118_1714_fu_3173_p0.read().is_01() || !ap_const_lv24_4F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1714_fu_3173_p0.read()) * sc_biguint<24>(ap_const_lv24_4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1715_fu_3174_p0() {
    mul_ln1118_1715_fu_3174_p0 =  (sc_lv<16>) (sext_ln1118_1202_fu_10340926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1715_fu_3174_p2() {
    mul_ln1118_1715_fu_3174_p2 = (!mul_ln1118_1715_fu_3174_p0.read().is_01() || !ap_const_lv25_1FFFF36.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1715_fu_3174_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1716_fu_3175_p0() {
    mul_ln1118_1716_fu_3175_p0 =  (sc_lv<16>) (sext_ln1118_1205_fu_10340950_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1716_fu_3175_p2() {
    mul_ln1118_1716_fu_3175_p2 = (!mul_ln1118_1716_fu_3175_p0.read().is_01() || !ap_const_lv24_FFFFB3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1716_fu_3175_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1717_fu_3176_p0() {
    mul_ln1118_1717_fu_3176_p0 =  (sc_lv<16>) (sext_ln1118_1204_fu_10340942_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1717_fu_3176_p2() {
    mul_ln1118_1717_fu_3176_p2 = (!mul_ln1118_1717_fu_3176_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1717_fu_3176_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1718_fu_3667_p0() {
    mul_ln1118_1718_fu_3667_p0 =  (sc_lv<16>) (sext_ln1118_1202_fu_10340926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1718_fu_3667_p2() {
    mul_ln1118_1718_fu_3667_p2 = (!mul_ln1118_1718_fu_3667_p0.read().is_01() || !ap_const_lv25_1FFFF66.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1718_fu_3667_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1719_fu_2109_p0() {
    mul_ln1118_1719_fu_2109_p0 =  (sc_lv<16>) (sext_ln1118_1205_fu_10340950_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1719_fu_2109_p2() {
    mul_ln1118_1719_fu_2109_p2 = (!mul_ln1118_1719_fu_2109_p0.read().is_01() || !ap_const_lv24_FFFF9E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1719_fu_2109_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1720_fu_3179_p0() {
    mul_ln1118_1720_fu_3179_p0 =  (sc_lv<16>) (sext_ln1118_1202_fu_10340926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1720_fu_3179_p2() {
    mul_ln1118_1720_fu_3179_p2 = (!mul_ln1118_1720_fu_3179_p0.read().is_01() || !ap_const_lv25_BB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1720_fu_3179_p0.read()) * sc_biguint<25>(ap_const_lv25_BB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1721_fu_3180_p0() {
    mul_ln1118_1721_fu_3180_p0 =  (sc_lv<16>) (sext_ln1118_1205_fu_10340950_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1721_fu_3180_p2() {
    mul_ln1118_1721_fu_3180_p2 = (!mul_ln1118_1721_fu_3180_p0.read().is_01() || !ap_const_lv24_62.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1721_fu_3180_p0.read()) * sc_biguint<24>(ap_const_lv24_62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1722_fu_3671_p0() {
    mul_ln1118_1722_fu_3671_p0 =  (sc_lv<16>) (sext_ln1118_1202_fu_10340926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1722_fu_3671_p2() {
    mul_ln1118_1722_fu_3671_p2 = (!mul_ln1118_1722_fu_3671_p0.read().is_01() || !ap_const_lv25_DB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1722_fu_3671_p0.read()) * sc_biguint<25>(ap_const_lv25_DB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1723_fu_3672_p0() {
    mul_ln1118_1723_fu_3672_p0 =  (sc_lv<16>) (sext_ln1118_1203_fu_10340934_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1723_fu_3672_p2() {
    mul_ln1118_1723_fu_3672_p2 = (!mul_ln1118_1723_fu_3672_p0.read().is_01() || !ap_const_lv26_3FFFECE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1723_fu_3672_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1724_fu_3183_p0() {
    mul_ln1118_1724_fu_3183_p0 =  (sc_lv<16>) (sext_ln1118_1204_fu_10340942_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1724_fu_3183_p2() {
    mul_ln1118_1724_fu_3183_p2 = (!mul_ln1118_1724_fu_3183_p0.read().is_01() || !ap_const_lv23_2C.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1724_fu_3183_p0.read()) * sc_biguint<23>(ap_const_lv23_2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1725_fu_3674_p0() {
    mul_ln1118_1725_fu_3674_p0 =  (sc_lv<16>) (sext_ln1118_1203_fu_10340934_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1725_fu_3674_p2() {
    mul_ln1118_1725_fu_3674_p2 = (!mul_ln1118_1725_fu_3674_p0.read().is_01() || !ap_const_lv26_3FFFEC1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1725_fu_3674_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1726_fu_3586_p0() {
    mul_ln1118_1726_fu_3586_p0 =  (sc_lv<16>) (sext_ln1118_1205_fu_10340950_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1726_fu_3586_p2() {
    mul_ln1118_1726_fu_3586_p2 = (!mul_ln1118_1726_fu_3586_p0.read().is_01() || !ap_const_lv24_FFFF9F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1726_fu_3586_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1727_fu_3186_p0() {
    mul_ln1118_1727_fu_3186_p0 =  (sc_lv<16>) (sext_ln1118_1217_fu_10341417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1727_fu_3186_p2() {
    mul_ln1118_1727_fu_3186_p2 = (!mul_ln1118_1727_fu_3186_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1727_fu_3186_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1728_fu_3677_p0() {
    mul_ln1118_1728_fu_3677_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1728_fu_3677_p2() {
    mul_ln1118_1728_fu_3677_p2 = (!mul_ln1118_1728_fu_3677_p0.read().is_01() || !ap_const_lv25_E7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1728_fu_3677_p0.read()) * sc_biguint<25>(ap_const_lv25_E7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1729_fu_3678_p0() {
    mul_ln1118_1729_fu_3678_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1729_fu_3678_p2() {
    mul_ln1118_1729_fu_3678_p2 = (!mul_ln1118_1729_fu_3678_p0.read().is_01() || !ap_const_lv25_1FFFF37.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1729_fu_3678_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1730_fu_3679_p0() {
    mul_ln1118_1730_fu_3679_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1730_fu_3679_p2() {
    mul_ln1118_1730_fu_3679_p2 = (!mul_ln1118_1730_fu_3679_p0.read().is_01() || !ap_const_lv24_FFFF8B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1730_fu_3679_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1731_fu_3190_p0() {
    mul_ln1118_1731_fu_3190_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1731_fu_3190_p2() {
    mul_ln1118_1731_fu_3190_p2 = (!mul_ln1118_1731_fu_3190_p0.read().is_01() || !ap_const_lv25_1FFFF55.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1731_fu_3190_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1732_fu_3191_p0() {
    mul_ln1118_1732_fu_3191_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1732_fu_3191_p2() {
    mul_ln1118_1732_fu_3191_p2 = (!mul_ln1118_1732_fu_3191_p0.read().is_01() || !ap_const_lv25_91.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1732_fu_3191_p0.read()) * sc_biguint<25>(ap_const_lv25_91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1733_fu_3481_p0() {
    mul_ln1118_1733_fu_3481_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1733_fu_3481_p2() {
    mul_ln1118_1733_fu_3481_p2 = (!mul_ln1118_1733_fu_3481_p0.read().is_01() || !ap_const_lv25_1FFFF17.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1733_fu_3481_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1734_fu_2062_p0() {
    mul_ln1118_1734_fu_2062_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1734_fu_2062_p2() {
    mul_ln1118_1734_fu_2062_p2 = (!mul_ln1118_1734_fu_2062_p0.read().is_01() || !ap_const_lv25_1FFFF57.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1734_fu_2062_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1735_fu_1901_p0() {
    mul_ln1118_1735_fu_1901_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1735_fu_1901_p2() {
    mul_ln1118_1735_fu_1901_p2 = (!mul_ln1118_1735_fu_1901_p0.read().is_01() || !ap_const_lv24_6E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1735_fu_1901_p0.read()) * sc_biguint<24>(ap_const_lv24_6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1736_fu_2998_p0() {
    mul_ln1118_1736_fu_2998_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1736_fu_2998_p2() {
    mul_ln1118_1736_fu_2998_p2 = (!mul_ln1118_1736_fu_2998_p0.read().is_01() || !ap_const_lv24_FFFFA3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1736_fu_2998_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1737_fu_2837_p0() {
    mul_ln1118_1737_fu_2837_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1737_fu_2837_p2() {
    mul_ln1118_1737_fu_2837_p2 = (!mul_ln1118_1737_fu_2837_p0.read().is_01() || !ap_const_lv25_1FFFF46.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1737_fu_2837_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1738_fu_2676_p0() {
    mul_ln1118_1738_fu_2676_p0 =  (sc_lv<16>) (sext_ln1118_1214_fu_10341385_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1738_fu_2676_p2() {
    mul_ln1118_1738_fu_2676_p2 = (!mul_ln1118_1738_fu_2676_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1738_fu_2676_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1739_fu_2515_p0() {
    mul_ln1118_1739_fu_2515_p0 =  (sc_lv<16>) (sext_ln1118_1217_fu_10341417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1739_fu_2515_p2() {
    mul_ln1118_1739_fu_2515_p2 = (!mul_ln1118_1739_fu_2515_p0.read().is_01() || !ap_const_lv23_27.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1739_fu_2515_p0.read()) * sc_biguint<23>(ap_const_lv23_27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1740_fu_2983_p0() {
    mul_ln1118_1740_fu_2983_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1740_fu_2983_p2() {
    mul_ln1118_1740_fu_2983_p2 = (!mul_ln1118_1740_fu_2983_p0.read().is_01() || !ap_const_lv24_FFFF9F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1740_fu_2983_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1741_fu_2822_p0() {
    mul_ln1118_1741_fu_2822_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1741_fu_2822_p2() {
    mul_ln1118_1741_fu_2822_p2 = (!mul_ln1118_1741_fu_2822_p0.read().is_01() || !ap_const_lv25_BC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1741_fu_2822_p0.read()) * sc_biguint<25>(ap_const_lv25_BC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1742_fu_2661_p0() {
    mul_ln1118_1742_fu_2661_p0 =  (sc_lv<16>) (sext_ln1118_1217_fu_10341417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1742_fu_2661_p2() {
    mul_ln1118_1742_fu_2661_p2 = (!mul_ln1118_1742_fu_2661_p0.read().is_01() || !ap_const_lv23_2B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1742_fu_2661_p0.read()) * sc_biguint<23>(ap_const_lv23_2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1743_fu_2500_p0() {
    mul_ln1118_1743_fu_2500_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1743_fu_2500_p2() {
    mul_ln1118_1743_fu_2500_p2 = (!mul_ln1118_1743_fu_2500_p0.read().is_01() || !ap_const_lv24_53.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1743_fu_2500_p0.read()) * sc_biguint<24>(ap_const_lv24_53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1744_fu_2339_p0() {
    mul_ln1118_1744_fu_2339_p0 = sext_ln1118_1218_fu_10341424_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1744_fu_2339_p2() {
    mul_ln1118_1744_fu_2339_p2 = (!mul_ln1118_1744_fu_2339_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1744_fu_2339_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1745_fu_3436_p0() {
    mul_ln1118_1745_fu_3436_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1745_fu_3436_p2() {
    mul_ln1118_1745_fu_3436_p2 = (!mul_ln1118_1745_fu_3436_p0.read().is_01() || !ap_const_lv24_FFFF9B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1745_fu_3436_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1746_fu_2564_p0() {
    mul_ln1118_1746_fu_2564_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1746_fu_2564_p2() {
    mul_ln1118_1746_fu_2564_p2 = (!mul_ln1118_1746_fu_2564_p0.read().is_01() || !ap_const_lv25_EE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1746_fu_2564_p0.read()) * sc_biguint<25>(ap_const_lv25_EE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1747_fu_2586_p0() {
    mul_ln1118_1747_fu_2586_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1747_fu_2586_p2() {
    mul_ln1118_1747_fu_2586_p2 = (!mul_ln1118_1747_fu_2586_p0.read().is_01() || !ap_const_lv24_75.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1747_fu_2586_p0.read()) * sc_biguint<24>(ap_const_lv24_75);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1748_fu_3054_p0() {
    mul_ln1118_1748_fu_3054_p0 =  (sc_lv<16>) (sext_ln1118_1215_fu_10341391_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1748_fu_3054_p2() {
    mul_ln1118_1748_fu_3054_p2 = (!mul_ln1118_1748_fu_3054_p0.read().is_01() || !ap_const_lv24_73.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1748_fu_3054_p0.read()) * sc_biguint<24>(ap_const_lv24_73);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1749_fu_1635_p0() {
    mul_ln1118_1749_fu_1635_p0 =  (sc_lv<16>) (sext_ln1118_1216_fu_10341403_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1749_fu_1635_p2() {
    mul_ln1118_1749_fu_1635_p2 = (!mul_ln1118_1749_fu_1635_p0.read().is_01() || !ap_const_lv25_A5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1749_fu_1635_p0.read()) * sc_biguint<25>(ap_const_lv25_A5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1750_fu_2732_p0() {
    mul_ln1118_1750_fu_2732_p0 =  (sc_lv<16>) (sext_ln1118_1214_fu_10341385_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1750_fu_2732_p2() {
    mul_ln1118_1750_fu_2732_p2 = (!mul_ln1118_1750_fu_2732_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1750_fu_2732_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1751_fu_2571_p0() {
    mul_ln1118_1751_fu_2571_p0 =  (sc_lv<16>) (sext_ln1118_1226_fu_10341932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1751_fu_2571_p2() {
    mul_ln1118_1751_fu_2571_p2 = (!mul_ln1118_1751_fu_2571_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1751_fu_2571_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1752_fu_3668_p0() {
    mul_ln1118_1752_fu_3668_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1752_fu_3668_p2() {
    mul_ln1118_1752_fu_3668_p2 = (!mul_ln1118_1752_fu_3668_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1752_fu_3668_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1753_fu_2878_p0() {
    mul_ln1118_1753_fu_2878_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1753_fu_2878_p2() {
    mul_ln1118_1753_fu_2878_p2 = (!mul_ln1118_1753_fu_2878_p0.read().is_01() || !ap_const_lv24_FFFF94.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1753_fu_2878_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1754_fu_2717_p0() {
    mul_ln1118_1754_fu_2717_p0 =  (sc_lv<16>) (sext_ln1118_1229_fu_10341949_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1754_fu_2717_p2() {
    mul_ln1118_1754_fu_2717_p2 = (!mul_ln1118_1754_fu_2717_p0.read().is_01() || !ap_const_lv23_39.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1754_fu_2717_p0.read()) * sc_biguint<23>(ap_const_lv23_39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1755_fu_3185_p0() {
    mul_ln1118_1755_fu_3185_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1755_fu_3185_p2() {
    mul_ln1118_1755_fu_3185_p2 = (!mul_ln1118_1755_fu_3185_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1755_fu_3185_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1756_fu_2395_p0() {
    mul_ln1118_1756_fu_2395_p0 =  (sc_lv<16>) (sext_ln1118_1229_fu_10341949_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1756_fu_2395_p2() {
    mul_ln1118_1756_fu_2395_p2 = (!mul_ln1118_1756_fu_2395_p0.read().is_01() || !ap_const_lv23_3B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1756_fu_2395_p0.read()) * sc_biguint<23>(ap_const_lv23_3B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1757_fu_2863_p0() {
    mul_ln1118_1757_fu_2863_p0 =  (sc_lv<16>) (sext_ln1118_1226_fu_10341932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1757_fu_2863_p2() {
    mul_ln1118_1757_fu_2863_p2 = (!mul_ln1118_1757_fu_2863_p0.read().is_01() || !ap_const_lv25_1FFFF50.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1757_fu_2863_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF50);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1758_fu_2702_p0() {
    mul_ln1118_1758_fu_2702_p0 =  (sc_lv<16>) (sext_ln1118_1224_fu_10341917_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1758_fu_2702_p2() {
    mul_ln1118_1758_fu_2702_p2 = (!mul_ln1118_1758_fu_2702_p0.read().is_01() || !ap_const_lv22_3FFFE7.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1758_fu_2702_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1759_fu_2541_p0() {
    mul_ln1118_1759_fu_2541_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1759_fu_2541_p2() {
    mul_ln1118_1759_fu_2541_p2 = (!mul_ln1118_1759_fu_2541_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1759_fu_2541_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1760_fu_2380_p0() {
    mul_ln1118_1760_fu_2380_p0 =  (sc_lv<16>) (sext_ln1118_1226_fu_10341932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1760_fu_2380_p2() {
    mul_ln1118_1760_fu_2380_p2 = (!mul_ln1118_1760_fu_2380_p0.read().is_01() || !ap_const_lv25_8C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1760_fu_2380_p0.read()) * sc_biguint<25>(ap_const_lv25_8C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1761_fu_2771_p0() {
    mul_ln1118_1761_fu_2771_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1761_fu_2771_p2() {
    mul_ln1118_1761_fu_2771_p2 = (!mul_ln1118_1761_fu_2771_p0.read().is_01() || !ap_const_lv24_72.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1761_fu_2771_p0.read()) * sc_biguint<24>(ap_const_lv24_72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1762_fu_2193_p0() {
    mul_ln1118_1762_fu_2193_p0 =  (sc_lv<16>) (sext_ln1118_1229_fu_10341949_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1762_fu_2193_p2() {
    mul_ln1118_1762_fu_2193_p2 = (!mul_ln1118_1762_fu_2193_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1762_fu_2193_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1763_fu_2773_p0() {
    mul_ln1118_1763_fu_2773_p0 =  (sc_lv<16>) (sext_ln1118_1229_fu_10341949_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1763_fu_2773_p2() {
    mul_ln1118_1763_fu_2773_p2 = (!mul_ln1118_1763_fu_2773_p0.read().is_01() || !ap_const_lv23_7FFFC9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1763_fu_2773_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1764_fu_2284_p0() {
    mul_ln1118_1764_fu_2284_p0 =  (sc_lv<16>) (sext_ln1118_1226_fu_10341932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1764_fu_2284_p2() {
    mul_ln1118_1764_fu_2284_p2 = (!mul_ln1118_1764_fu_2284_p0.read().is_01() || !ap_const_lv25_B6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1764_fu_2284_p0.read()) * sc_biguint<25>(ap_const_lv25_B6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1765_fu_1706_p0() {
    mul_ln1118_1765_fu_1706_p0 =  (sc_lv<16>) (sext_ln1118_1226_fu_10341932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1765_fu_1706_p2() {
    mul_ln1118_1765_fu_1706_p2 = (!mul_ln1118_1765_fu_1706_p0.read().is_01() || !ap_const_lv25_1FFFF49.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1765_fu_1706_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1766_fu_1796_p0() {
    mul_ln1118_1766_fu_1796_p0 =  (sc_lv<16>) (sext_ln1118_1229_fu_10341949_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1766_fu_1796_p2() {
    mul_ln1118_1766_fu_1796_p2 = (!mul_ln1118_1766_fu_1796_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1766_fu_1796_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1767_fu_2777_p0() {
    mul_ln1118_1767_fu_2777_p0 =  (sc_lv<16>) (sext_ln1118_1225_fu_10341922_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1767_fu_2777_p2() {
    mul_ln1118_1767_fu_2777_p2 = (!mul_ln1118_1767_fu_2777_p0.read().is_01() || !ap_const_lv24_5A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1767_fu_2777_p0.read()) * sc_biguint<24>(ap_const_lv24_5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1768_fu_1798_p0() {
    mul_ln1118_1768_fu_1798_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1768_fu_1798_p2() {
    mul_ln1118_1768_fu_1798_p2 = (!mul_ln1118_1768_fu_1798_p0.read().is_01() || !ap_const_lv25_AC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1768_fu_1798_p0.read()) * sc_biguint<25>(ap_const_lv25_AC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1769_fu_2779_p0() {
    mul_ln1118_1769_fu_2779_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1769_fu_2779_p2() {
    mul_ln1118_1769_fu_2779_p2 = (!mul_ln1118_1769_fu_2779_p0.read().is_01() || !ap_const_lv26_3FFFEA8.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1769_fu_2779_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1770_fu_2780_p0() {
    mul_ln1118_1770_fu_2780_p0 =  (sc_lv<16>) (sext_ln1118_1243_fu_10342516_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1770_fu_2780_p2() {
    mul_ln1118_1770_fu_2780_p2 = (!mul_ln1118_1770_fu_2780_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1770_fu_2780_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1771_fu_2291_p0() {
    mul_ln1118_1771_fu_2291_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1771_fu_2291_p2() {
    mul_ln1118_1771_fu_2291_p2 = (!mul_ln1118_1771_fu_2291_p0.read().is_01() || !ap_const_lv25_1FFFF6F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1771_fu_2291_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1772_fu_3272_p0() {
    mul_ln1118_1772_fu_3272_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1772_fu_3272_p2() {
    mul_ln1118_1772_fu_3272_p2 = (!mul_ln1118_1772_fu_3272_p0.read().is_01() || !ap_const_lv26_3FFFD6C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1772_fu_3272_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1773_fu_2293_p0() {
    mul_ln1118_1773_fu_2293_p0 =  (sc_lv<16>) (sext_ln1118_1239_fu_10342482_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1773_fu_2293_p2() {
    mul_ln1118_1773_fu_2293_p2 = (!mul_ln1118_1773_fu_2293_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1773_fu_2293_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1774_fu_2294_p0() {
    mul_ln1118_1774_fu_2294_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1774_fu_2294_p2() {
    mul_ln1118_1774_fu_2294_p2 = (!mul_ln1118_1774_fu_2294_p0.read().is_01() || !ap_const_lv26_131.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1774_fu_2294_p0.read()) * sc_biguint<26>(ap_const_lv26_131);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1775_fu_2785_p0() {
    mul_ln1118_1775_fu_2785_p0 =  (sc_lv<16>) (sext_ln1118_1245_fu_10342527_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1775_fu_2785_p2() {
    mul_ln1118_1775_fu_2785_p2 = (!mul_ln1118_1775_fu_2785_p0.read().is_01() || !ap_const_lv22_1B.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1775_fu_2785_p0.read()) * sc_biguint<22>(ap_const_lv22_1B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1776_fu_2786_p0() {
    mul_ln1118_1776_fu_2786_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1776_fu_2786_p2() {
    mul_ln1118_1776_fu_2786_p2 = (!mul_ln1118_1776_fu_2786_p0.read().is_01() || !ap_const_lv26_3FFFEA9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1776_fu_2786_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1777_fu_2787_p0() {
    mul_ln1118_1777_fu_2787_p0 =  (sc_lv<16>) (sext_ln1118_1243_fu_10342516_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1777_fu_2787_p2() {
    mul_ln1118_1777_fu_2787_p2 = (!mul_ln1118_1777_fu_2787_p0.read().is_01() || !ap_const_lv24_67.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1777_fu_2787_p0.read()) * sc_biguint<24>(ap_const_lv24_67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1778_fu_2298_p0() {
    mul_ln1118_1778_fu_2298_p0 =  (sc_lv<16>) (sext_ln1118_1245_fu_10342527_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1778_fu_2298_p2() {
    mul_ln1118_1778_fu_2298_p2 = (!mul_ln1118_1778_fu_2298_p0.read().is_01() || !ap_const_lv22_3FFFE6.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1778_fu_2298_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1779_fu_2299_p0() {
    mul_ln1118_1779_fu_2299_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1779_fu_2299_p2() {
    mul_ln1118_1779_fu_2299_p2 = (!mul_ln1118_1779_fu_2299_p0.read().is_01() || !ap_const_lv26_1F1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1779_fu_2299_p0.read()) * sc_biguint<26>(ap_const_lv26_1F1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1780_fu_1810_p0() {
    mul_ln1118_1780_fu_1810_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1780_fu_1810_p2() {
    mul_ln1118_1780_fu_1810_p2 = (!mul_ln1118_1780_fu_1810_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1780_fu_1810_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1781_fu_2212_p0() {
    mul_ln1118_1781_fu_2212_p0 =  (sc_lv<16>) (sext_ln1118_1245_fu_10342527_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1781_fu_2212_p2() {
    mul_ln1118_1781_fu_2212_p2 = (!mul_ln1118_1781_fu_2212_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1781_fu_2212_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1782_fu_2302_p0() {
    mul_ln1118_1782_fu_2302_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1782_fu_2302_p2() {
    mul_ln1118_1782_fu_2302_p2 = (!mul_ln1118_1782_fu_2302_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1782_fu_2302_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1783_fu_2303_p0() {
    mul_ln1118_1783_fu_2303_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1783_fu_2303_p2() {
    mul_ln1118_1783_fu_2303_p2 = (!mul_ln1118_1783_fu_2303_p0.read().is_01() || !ap_const_lv26_157.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1783_fu_2303_p0.read()) * sc_biguint<26>(ap_const_lv26_157);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1784_fu_2304_p0() {
    mul_ln1118_1784_fu_2304_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1784_fu_2304_p2() {
    mul_ln1118_1784_fu_2304_p2 = (!mul_ln1118_1784_fu_2304_p0.read().is_01() || !ap_const_lv25_1FFFF14.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1784_fu_2304_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF14);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1785_fu_2795_p0() {
    mul_ln1118_1785_fu_2795_p0 =  (sc_lv<16>) (sext_ln1118_1243_fu_10342516_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1785_fu_2795_p2() {
    mul_ln1118_1785_fu_2795_p2 = (!mul_ln1118_1785_fu_2795_p0.read().is_01() || !ap_const_lv24_FFFFB7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1785_fu_2795_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1786_fu_2306_p0() {
    mul_ln1118_1786_fu_2306_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1786_fu_2306_p2() {
    mul_ln1118_1786_fu_2306_p2 = (!mul_ln1118_1786_fu_2306_p0.read().is_01() || !ap_const_lv25_B6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1786_fu_2306_p0.read()) * sc_biguint<25>(ap_const_lv25_B6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1787_fu_2307_p0() {
    mul_ln1118_1787_fu_2307_p0 =  (sc_lv<16>) (sext_ln1118_1241_fu_10342501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1787_fu_2307_p2() {
    mul_ln1118_1787_fu_2307_p2 = (!mul_ln1118_1787_fu_2307_p0.read().is_01() || !ap_const_lv25_1FFFF28.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1787_fu_2307_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF28);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1788_fu_2308_p0() {
    mul_ln1118_1788_fu_2308_p0 =  (sc_lv<16>) (sext_ln1118_1239_fu_10342482_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1788_fu_2308_p2() {
    mul_ln1118_1788_fu_2308_p2 = (!mul_ln1118_1788_fu_2308_p0.read().is_01() || !ap_const_lv23_26.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1788_fu_2308_p0.read()) * sc_biguint<23>(ap_const_lv23_26);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1789_fu_2344_p0() {
    mul_ln1118_1789_fu_2344_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1789_fu_2344_p2() {
    mul_ln1118_1789_fu_2344_p2 = (!mul_ln1118_1789_fu_2344_p0.read().is_01() || !ap_const_lv26_126.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1789_fu_2344_p0.read()) * sc_biguint<26>(ap_const_lv26_126);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1790_fu_2812_p0() {
    mul_ln1118_1790_fu_2812_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1790_fu_2812_p2() {
    mul_ln1118_1790_fu_2812_p2 = (!mul_ln1118_1790_fu_2812_p0.read().is_01() || !ap_const_lv26_12A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1790_fu_2812_p0.read()) * sc_biguint<26>(ap_const_lv26_12A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1791_fu_2651_p0() {
    mul_ln1118_1791_fu_2651_p0 =  (sc_lv<16>) (sext_ln1118_1240_fu_10342488_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1791_fu_2651_p2() {
    mul_ln1118_1791_fu_2651_p2 = (!mul_ln1118_1791_fu_2651_p0.read().is_01() || !ap_const_lv26_3FFFE5B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1791_fu_2651_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1792_fu_1861_p0() {
    mul_ln1118_1792_fu_1861_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1792_fu_1861_p2() {
    mul_ln1118_1792_fu_1861_p2 = (!mul_ln1118_1792_fu_1861_p0.read().is_01() || !ap_const_lv25_1FFFF7A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1792_fu_1861_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1793_fu_2958_p0() {
    mul_ln1118_1793_fu_2958_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1793_fu_2958_p2() {
    mul_ln1118_1793_fu_2958_p2 = (!mul_ln1118_1793_fu_2958_p0.read().is_01() || !ap_const_lv25_91.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1793_fu_2958_p0.read()) * sc_biguint<25>(ap_const_lv25_91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1794_fu_2797_p0() {
    mul_ln1118_1794_fu_2797_p0 = sext_ln1118_1260_fu_10343102_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1794_fu_2797_p2() {
    mul_ln1118_1794_fu_2797_p2 = (!mul_ln1118_1794_fu_2797_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1794_fu_2797_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1795_fu_3265_p0() {
    mul_ln1118_1795_fu_3265_p0 =  (sc_lv<16>) (sext_ln1118_1261_fu_10343107_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1795_fu_3265_p2() {
    mul_ln1118_1795_fu_3265_p2 = (!mul_ln1118_1795_fu_3265_p0.read().is_01() || !ap_const_lv23_7FFFC7.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1795_fu_3265_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1796_fu_1764_p0() {
    mul_ln1118_1796_fu_1764_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1796_fu_1764_p2() {
    mul_ln1118_1796_fu_1764_p2 = (!mul_ln1118_1796_fu_1764_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1796_fu_1764_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1797_fu_1685_p0() {
    mul_ln1118_1797_fu_1685_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1797_fu_1685_p2() {
    mul_ln1118_1797_fu_1685_p2 = (!mul_ln1118_1797_fu_1685_p0.read().is_01() || !ap_const_lv25_1FFFF22.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1797_fu_1685_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF22);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1798_fu_2153_p0() {
    mul_ln1118_1798_fu_2153_p0 =  (sc_lv<16>) (sext_ln1118_1261_fu_10343107_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1798_fu_2153_p2() {
    mul_ln1118_1798_fu_2153_p2 = (!mul_ln1118_1798_fu_2153_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1798_fu_2153_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1799_fu_1910_p0() {
    mul_ln1118_1799_fu_1910_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1799_fu_1910_p2() {
    mul_ln1118_1799_fu_1910_p2 = (!mul_ln1118_1799_fu_1910_p0.read().is_01() || !ap_const_lv24_55.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1799_fu_1910_p0.read()) * sc_biguint<24>(ap_const_lv24_55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1800_fu_2460_p0() {
    mul_ln1118_1800_fu_2460_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1800_fu_2460_p2() {
    mul_ln1118_1800_fu_2460_p2 = (!mul_ln1118_1800_fu_2460_p0.read().is_01() || !ap_const_lv25_1FFFF69.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1800_fu_2460_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1801_fu_1670_p0() {
    mul_ln1118_1801_fu_1670_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1801_fu_1670_p2() {
    mul_ln1118_1801_fu_1670_p2 = (!mul_ln1118_1801_fu_1670_p0.read().is_01() || !ap_const_lv25_E1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1801_fu_1670_p0.read()) * sc_biguint<25>(ap_const_lv25_E1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1802_fu_2138_p0() {
    mul_ln1118_1802_fu_2138_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1802_fu_2138_p2() {
    mul_ln1118_1802_fu_2138_p2 = (!mul_ln1118_1802_fu_2138_p0.read().is_01() || !ap_const_lv25_1FFFF1A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1802_fu_2138_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1803_fu_3116_p0() {
    mul_ln1118_1803_fu_3116_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1803_fu_3116_p2() {
    mul_ln1118_1803_fu_3116_p2 = (!mul_ln1118_1803_fu_3116_p0.read().is_01() || !ap_const_lv25_9E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1803_fu_3116_p0.read()) * sc_biguint<25>(ap_const_lv25_9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1804_fu_1840_p0() {
    mul_ln1118_1804_fu_1840_p0 =  (sc_lv<16>) (sext_ln1118_1261_fu_10343107_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1804_fu_1840_p2() {
    mul_ln1118_1804_fu_1840_p2 = (!mul_ln1118_1804_fu_1840_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1804_fu_1840_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1805_fu_3423_p0() {
    mul_ln1118_1805_fu_3423_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1805_fu_3423_p2() {
    mul_ln1118_1805_fu_3423_p2 = (!mul_ln1118_1805_fu_3423_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1805_fu_3423_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1806_fu_2147_p0() {
    mul_ln1118_1806_fu_2147_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1806_fu_2147_p2() {
    mul_ln1118_1806_fu_2147_p2 = (!mul_ln1118_1806_fu_2147_p0.read().is_01() || !ap_const_lv25_1FFFF55.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1806_fu_2147_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1807_fu_1843_p0() {
    mul_ln1118_1807_fu_1843_p0 =  (sc_lv<16>) (sext_ln1118_1261_fu_10343107_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1807_fu_1843_p2() {
    mul_ln1118_1807_fu_1843_p2 = (!mul_ln1118_1807_fu_1843_p0.read().is_01() || !ap_const_lv23_7FFFD5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1807_fu_1843_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1808_fu_1682_p0() {
    mul_ln1118_1808_fu_1682_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1808_fu_1682_p2() {
    mul_ln1118_1808_fu_1682_p2 = (!mul_ln1118_1808_fu_1682_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1808_fu_1682_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1809_fu_2922_p0() {
    mul_ln1118_1809_fu_2922_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1809_fu_2922_p2() {
    mul_ln1118_1809_fu_2922_p2 = (!mul_ln1118_1809_fu_2922_p0.read().is_01() || !ap_const_lv25_8C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1809_fu_2922_p0.read()) * sc_biguint<25>(ap_const_lv25_8C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1810_fu_1989_p0() {
    mul_ln1118_1810_fu_1989_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1810_fu_1989_p2() {
    mul_ln1118_1810_fu_1989_p2 = (!mul_ln1118_1810_fu_1989_p0.read().is_01() || !ap_const_lv24_72.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1810_fu_1989_p0.read()) * sc_biguint<24>(ap_const_lv24_72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1811_fu_3086_p0() {
    mul_ln1118_1811_fu_3086_p0 =  (sc_lv<16>) (sext_ln1118_1256_fu_10343070_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1811_fu_3086_p2() {
    mul_ln1118_1811_fu_3086_p2 = (!mul_ln1118_1811_fu_3086_p0.read().is_01() || !ap_const_lv24_79.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1811_fu_3086_p0.read()) * sc_biguint<24>(ap_const_lv24_79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1812_fu_1667_p0() {
    mul_ln1118_1812_fu_1667_p0 =  (sc_lv<16>) (sext_ln1118_1257_fu_10343080_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1812_fu_1667_p2() {
    mul_ln1118_1812_fu_1667_p2 = (!mul_ln1118_1812_fu_1667_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1812_fu_1667_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1813_fu_2135_p0() {
    mul_ln1118_1813_fu_2135_p0 =  (sc_lv<16>) (sext_ln1118_1255_fu_10343064_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1813_fu_2135_p2() {
    mul_ln1118_1813_fu_2135_p2 = (!mul_ln1118_1813_fu_2135_p0.read().is_01() || !ap_const_lv26_3FFFEF6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1813_fu_2135_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1814_fu_1974_p0() {
    mul_ln1118_1814_fu_1974_p0 =  (sc_lv<16>) (sext_ln1118_1255_fu_10343064_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1814_fu_1974_p2() {
    mul_ln1118_1814_fu_1974_p2 = (!mul_ln1118_1814_fu_1974_p0.read().is_01() || !ap_const_lv26_147.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1814_fu_1974_p0.read()) * sc_biguint<26>(ap_const_lv26_147);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1815_fu_2442_p0() {
    mul_ln1118_1815_fu_2442_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1815_fu_2442_p2() {
    mul_ln1118_1815_fu_2442_p2 = (!mul_ln1118_1815_fu_2442_p0.read().is_01() || !ap_const_lv25_1FFFF7A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1815_fu_2442_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1816_fu_2910_p0() {
    mul_ln1118_1816_fu_2910_p0 =  (sc_lv<16>) (sext_ln1118_1275_fu_10343692_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1816_fu_2910_p2() {
    mul_ln1118_1816_fu_2910_p2 = (!mul_ln1118_1816_fu_2910_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1816_fu_2910_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1817_fu_2957_p0() {
    mul_ln1118_1817_fu_2957_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1817_fu_2957_p2() {
    mul_ln1118_1817_fu_2957_p2 = (!mul_ln1118_1817_fu_2957_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1817_fu_2957_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1818_fu_3448_p0() {
    mul_ln1118_1818_fu_3448_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1818_fu_3448_p2() {
    mul_ln1118_1818_fu_3448_p2 = (!mul_ln1118_1818_fu_3448_p0.read().is_01() || !ap_const_lv24_FFFFA5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1818_fu_3448_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1819_fu_1890_p0() {
    mul_ln1118_1819_fu_1890_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1819_fu_1890_p2() {
    mul_ln1118_1819_fu_1890_p2 = (!mul_ln1118_1819_fu_1890_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1819_fu_1890_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1820_fu_2381_p0() {
    mul_ln1118_1820_fu_2381_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1820_fu_2381_p2() {
    mul_ln1118_1820_fu_2381_p2 = (!mul_ln1118_1820_fu_2381_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1820_fu_2381_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1821_fu_3451_p0() {
    mul_ln1118_1821_fu_3451_p0 =  (sc_lv<16>) (sext_ln1118_1273_fu_10343681_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1821_fu_3451_p2() {
    mul_ln1118_1821_fu_3451_p2 = (!mul_ln1118_1821_fu_3451_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1821_fu_3451_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1822_fu_2962_p0() {
    mul_ln1118_1822_fu_2962_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1822_fu_2962_p2() {
    mul_ln1118_1822_fu_2962_p2 = (!mul_ln1118_1822_fu_2962_p0.read().is_01() || !ap_const_lv24_FFFF96.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1822_fu_2962_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1823_fu_3453_p0() {
    mul_ln1118_1823_fu_3453_p0 =  (sc_lv<16>) (sext_ln1118_1273_fu_10343681_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1823_fu_3453_p2() {
    mul_ln1118_1823_fu_3453_p2 = (!mul_ln1118_1823_fu_3453_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1823_fu_3453_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1824_fu_1895_p0() {
    mul_ln1118_1824_fu_1895_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1824_fu_1895_p2() {
    mul_ln1118_1824_fu_1895_p2 = (!mul_ln1118_1824_fu_1895_p0.read().is_01() || !ap_const_lv24_FFFFB4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1824_fu_1895_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1825_fu_3455_p0() {
    mul_ln1118_1825_fu_3455_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1825_fu_3455_p2() {
    mul_ln1118_1825_fu_3455_p2 = (!mul_ln1118_1825_fu_3455_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1825_fu_3455_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1826_fu_3456_p0() {
    mul_ln1118_1826_fu_3456_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1826_fu_3456_p2() {
    mul_ln1118_1826_fu_3456_p2 = (!mul_ln1118_1826_fu_3456_p0.read().is_01() || !ap_const_lv24_7B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1826_fu_3456_p0.read()) * sc_biguint<24>(ap_const_lv24_7B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1827_fu_2388_p0() {
    mul_ln1118_1827_fu_2388_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1827_fu_2388_p2() {
    mul_ln1118_1827_fu_2388_p2 = (!mul_ln1118_1827_fu_2388_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1827_fu_2388_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1828_fu_2968_p0() {
    mul_ln1118_1828_fu_2968_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1828_fu_2968_p2() {
    mul_ln1118_1828_fu_2968_p2 = (!mul_ln1118_1828_fu_2968_p0.read().is_01() || !ap_const_lv24_47.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1828_fu_2968_p0.read()) * sc_biguint<24>(ap_const_lv24_47);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1829_fu_3459_p0() {
    mul_ln1118_1829_fu_3459_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1829_fu_3459_p2() {
    mul_ln1118_1829_fu_3459_p2 = (!mul_ln1118_1829_fu_3459_p0.read().is_01() || !ap_const_lv25_AD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1829_fu_3459_p0.read()) * sc_biguint<25>(ap_const_lv25_AD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1830_fu_3460_p0() {
    mul_ln1118_1830_fu_3460_p0 =  (sc_lv<16>) (sext_ln1118_1275_fu_10343692_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1830_fu_3460_p2() {
    mul_ln1118_1830_fu_3460_p2 = (!mul_ln1118_1830_fu_3460_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1830_fu_3460_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1831_fu_3461_p0() {
    mul_ln1118_1831_fu_3461_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1831_fu_3461_p2() {
    mul_ln1118_1831_fu_3461_p2 = (!mul_ln1118_1831_fu_3461_p0.read().is_01() || !ap_const_lv25_C9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1831_fu_3461_p0.read()) * sc_biguint<25>(ap_const_lv25_C9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1832_fu_1903_p0() {
    mul_ln1118_1832_fu_1903_p0 =  (sc_lv<16>) (sext_ln1118_1273_fu_10343681_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1832_fu_1903_p2() {
    mul_ln1118_1832_fu_1903_p2 = (!mul_ln1118_1832_fu_1903_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1832_fu_1903_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1833_fu_2973_p0() {
    mul_ln1118_1833_fu_2973_p0 =  (sc_lv<16>) (sext_ln1118_1272_fu_10343671_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1833_fu_2973_p2() {
    mul_ln1118_1833_fu_2973_p2 = (!mul_ln1118_1833_fu_2973_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1833_fu_2973_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1834_fu_3464_p0() {
    mul_ln1118_1834_fu_3464_p0 =  (sc_lv<16>) (sext_ln1118_1275_fu_10343692_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1834_fu_3464_p2() {
    mul_ln1118_1834_fu_3464_p2 = (!mul_ln1118_1834_fu_3464_p0.read().is_01() || !ap_const_lv23_31.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1834_fu_3464_p0.read()) * sc_biguint<23>(ap_const_lv23_31);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1835_fu_1906_p0() {
    mul_ln1118_1835_fu_1906_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1835_fu_1906_p2() {
    mul_ln1118_1835_fu_1906_p2 = (!mul_ln1118_1835_fu_1906_p0.read().is_01() || !ap_const_lv24_57.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1835_fu_1906_p0.read()) * sc_biguint<24>(ap_const_lv24_57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1836_fu_2219_p0() {
    mul_ln1118_1836_fu_2219_p0 =  (sc_lv<16>) (sext_ln1118_1271_fu_10343657_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1836_fu_2219_p2() {
    mul_ln1118_1836_fu_2219_p2 = (!mul_ln1118_1836_fu_2219_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1836_fu_2219_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1837_fu_1908_p0() {
    mul_ln1118_1837_fu_1908_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1837_fu_1908_p2() {
    mul_ln1118_1837_fu_1908_p2 = (!mul_ln1118_1837_fu_1908_p0.read().is_01() || !ap_const_lv24_FFFF99.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1837_fu_1908_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1838_fu_2399_p0() {
    mul_ln1118_1838_fu_2399_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1838_fu_2399_p2() {
    mul_ln1118_1838_fu_2399_p2 = (!mul_ln1118_1838_fu_2399_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1838_fu_2399_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1839_fu_2400_p0() {
    mul_ln1118_1839_fu_2400_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1839_fu_2400_p2() {
    mul_ln1118_1839_fu_2400_p2 = (!mul_ln1118_1839_fu_2400_p0.read().is_01() || !ap_const_lv25_1FFFF17.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1839_fu_2400_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1840_fu_3470_p0() {
    mul_ln1118_1840_fu_3470_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1840_fu_3470_p2() {
    mul_ln1118_1840_fu_3470_p2 = (!mul_ln1118_1840_fu_3470_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1840_fu_3470_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1841_fu_1912_p0() {
    mul_ln1118_1841_fu_1912_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1841_fu_1912_p2() {
    mul_ln1118_1841_fu_1912_p2 = (!mul_ln1118_1841_fu_1912_p0.read().is_01() || !ap_const_lv25_1FFFF2D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1841_fu_1912_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1842_fu_1913_p0() {
    mul_ln1118_1842_fu_1913_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1842_fu_1913_p2() {
    mul_ln1118_1842_fu_1913_p2 = (!mul_ln1118_1842_fu_1913_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1842_fu_1913_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1843_fu_2404_p0() {
    mul_ln1118_1843_fu_2404_p0 =  (sc_lv<16>) (sext_ln1118_1290_fu_10344299_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1843_fu_2404_p2() {
    mul_ln1118_1843_fu_2404_p2 = (!mul_ln1118_1843_fu_2404_p0.read().is_01() || !ap_const_lv23_39.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1843_fu_2404_p0.read()) * sc_biguint<23>(ap_const_lv23_39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1844_fu_3255_p0() {
    mul_ln1118_1844_fu_3255_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1844_fu_3255_p2() {
    mul_ln1118_1844_fu_3255_p2 = (!mul_ln1118_1844_fu_3255_p0.read().is_01() || !ap_const_lv25_B1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1844_fu_3255_p0.read()) * sc_biguint<25>(ap_const_lv25_B1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1845_fu_3094_p0() {
    mul_ln1118_1845_fu_3094_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1845_fu_3094_p2() {
    mul_ln1118_1845_fu_3094_p2 = (!mul_ln1118_1845_fu_3094_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1845_fu_3094_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1846_fu_1675_p0() {
    mul_ln1118_1846_fu_1675_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1846_fu_1675_p2() {
    mul_ln1118_1846_fu_1675_p2 = (!mul_ln1118_1846_fu_1675_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1846_fu_1675_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1847_fu_2772_p0() {
    mul_ln1118_1847_fu_2772_p0 = sext_ln1118_1285_fu_10344263_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1847_fu_2772_p2() {
    mul_ln1118_1847_fu_2772_p2 = (!mul_ln1118_1847_fu_2772_p0.read().is_01() || !ap_const_lv26_118.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1847_fu_2772_p0.read()) * sc_biguint<26>(ap_const_lv26_118);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1848_fu_3240_p0() {
    mul_ln1118_1848_fu_3240_p0 =  (sc_lv<16>) (sext_ln1118_1290_fu_10344299_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1848_fu_3240_p2() {
    mul_ln1118_1848_fu_3240_p2 = (!mul_ln1118_1848_fu_3240_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1848_fu_3240_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1849_fu_3079_p0() {
    mul_ln1118_1849_fu_3079_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1849_fu_3079_p2() {
    mul_ln1118_1849_fu_3079_p2 = (!mul_ln1118_1849_fu_3079_p0.read().is_01() || !ap_const_lv25_1FFFF24.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1849_fu_3079_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF24);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1850_fu_2289_p0() {
    mul_ln1118_1850_fu_2289_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1850_fu_2289_p2() {
    mul_ln1118_1850_fu_2289_p2 = (!mul_ln1118_1850_fu_2289_p0.read().is_01() || !ap_const_lv24_4E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1850_fu_2289_p0.read()) * sc_biguint<24>(ap_const_lv24_4E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1851_fu_3386_p0() {
    mul_ln1118_1851_fu_3386_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1851_fu_3386_p2() {
    mul_ln1118_1851_fu_3386_p2 = (!mul_ln1118_1851_fu_3386_p0.read().is_01() || !ap_const_lv24_FFFF97.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1851_fu_3386_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1852_fu_1967_p0() {
    mul_ln1118_1852_fu_1967_p0 =  (sc_lv<16>) (sext_ln1118_1287_fu_10344279_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1852_fu_1967_p2() {
    mul_ln1118_1852_fu_1967_p2 = (!mul_ln1118_1852_fu_1967_p0.read().is_01() || !ap_const_lv24_76.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1852_fu_1967_p0.read()) * sc_biguint<24>(ap_const_lv24_76);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1853_fu_2435_p0() {
    mul_ln1118_1853_fu_2435_p0 =  (sc_lv<16>) (sext_ln1118_1286_fu_10344268_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1853_fu_2435_p2() {
    mul_ln1118_1853_fu_2435_p2 = (!mul_ln1118_1853_fu_2435_p0.read().is_01() || !ap_const_lv25_1FFFF50.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1853_fu_2435_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF50);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1854_fu_3532_p0() {
    mul_ln1118_1854_fu_3532_p0 = sext_ln1118_1289_fu_10344294_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1854_fu_3532_p2() {
    mul_ln1118_1854_fu_3532_p2 = (!mul_ln1118_1854_fu_3532_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1854_fu_3532_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1855_fu_2742_p0() {
    mul_ln1118_1855_fu_2742_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1855_fu_2742_p2() {
    mul_ln1118_1855_fu_2742_p2 = (!mul_ln1118_1855_fu_2742_p0.read().is_01() || !ap_const_lv25_8E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1855_fu_2742_p0.read()) * sc_biguint<25>(ap_const_lv25_8E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1856_fu_3383_p0() {
    mul_ln1118_1856_fu_3383_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1856_fu_3383_p2() {
    mul_ln1118_1856_fu_3383_p2 = (!mul_ln1118_1856_fu_3383_p0.read().is_01() || !ap_const_lv24_77.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1856_fu_3383_p0.read()) * sc_biguint<24>(ap_const_lv24_77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1857_fu_3196_p0() {
    mul_ln1118_1857_fu_3196_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1857_fu_3196_p2() {
    mul_ln1118_1857_fu_3196_p2 = (!mul_ln1118_1857_fu_3196_p0.read().is_01() || !ap_const_lv25_AB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1857_fu_3196_p0.read()) * sc_biguint<25>(ap_const_lv25_AB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1858_fu_2406_p0() {
    mul_ln1118_1858_fu_2406_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1858_fu_2406_p2() {
    mul_ln1118_1858_fu_2406_p2 = (!mul_ln1118_1858_fu_2406_p0.read().is_01() || !ap_const_lv25_1FFFF49.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1858_fu_2406_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1859_fu_2245_p0() {
    mul_ln1118_1859_fu_2245_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1859_fu_2245_p2() {
    mul_ln1118_1859_fu_2245_p2 = (!mul_ln1118_1859_fu_2245_p0.read().is_01() || !ap_const_lv24_4C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1859_fu_2245_p0.read()) * sc_biguint<24>(ap_const_lv24_4C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1860_fu_3342_p0() {
    mul_ln1118_1860_fu_3342_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1860_fu_3342_p2() {
    mul_ln1118_1860_fu_3342_p2 = (!mul_ln1118_1860_fu_3342_p0.read().is_01() || !ap_const_lv25_1FFFF47.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1860_fu_3342_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF47);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1861_fu_3181_p0() {
    mul_ln1118_1861_fu_3181_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1861_fu_3181_p2() {
    mul_ln1118_1861_fu_3181_p2 = (!mul_ln1118_1861_fu_3181_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1861_fu_3181_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1862_fu_3020_p0() {
    mul_ln1118_1862_fu_3020_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1862_fu_3020_p2() {
    mul_ln1118_1862_fu_3020_p2 = (!mul_ln1118_1862_fu_3020_p0.read().is_01() || !ap_const_lv25_99.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1862_fu_3020_p0.read()) * sc_biguint<25>(ap_const_lv25_99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1863_fu_3488_p0() {
    mul_ln1118_1863_fu_3488_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1863_fu_3488_p2() {
    mul_ln1118_1863_fu_3488_p2 = (!mul_ln1118_1863_fu_3488_p0.read().is_01() || !ap_const_lv24_6F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1863_fu_3488_p0.read()) * sc_biguint<24>(ap_const_lv24_6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1864_fu_3327_p0() {
    mul_ln1118_1864_fu_3327_p0 =  (sc_lv<16>) (sext_ln1118_1303_fu_10344832_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1864_fu_3327_p2() {
    mul_ln1118_1864_fu_3327_p2 = (!mul_ln1118_1864_fu_3327_p0.read().is_01() || !ap_const_lv23_3B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1864_fu_3327_p0.read()) * sc_biguint<23>(ap_const_lv23_3B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1865_fu_2537_p0() {
    mul_ln1118_1865_fu_2537_p0 = sext_ln1118_1302_fu_10344827_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1865_fu_2537_p2() {
    mul_ln1118_1865_fu_2537_p2 = (!mul_ln1118_1865_fu_2537_p0.read().is_01() || !ap_const_lv22_1A.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1865_fu_2537_p0.read()) * sc_biguint<22>(ap_const_lv22_1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1866_fu_3005_p0() {
    mul_ln1118_1866_fu_3005_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1866_fu_3005_p2() {
    mul_ln1118_1866_fu_3005_p2 = (!mul_ln1118_1866_fu_3005_p0.read().is_01() || !ap_const_lv24_79.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1866_fu_3005_p0.read()) * sc_biguint<24>(ap_const_lv24_79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1867_fu_2215_p0() {
    mul_ln1118_1867_fu_2215_p0 =  (sc_lv<16>) (sext_ln1118_1303_fu_10344832_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1867_fu_2215_p2() {
    mul_ln1118_1867_fu_2215_p2 = (!mul_ln1118_1867_fu_2215_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1867_fu_2215_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1868_fu_2826_p0() {
    mul_ln1118_1868_fu_2826_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1868_fu_2826_p2() {
    mul_ln1118_1868_fu_2826_p2 = (!mul_ln1118_1868_fu_2826_p0.read().is_01() || !ap_const_lv24_FFFF9A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1868_fu_2826_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1869_fu_2522_p0() {
    mul_ln1118_1869_fu_2522_p0 =  (sc_lv<16>) (sext_ln1118_1303_fu_10344832_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1869_fu_2522_p2() {
    mul_ln1118_1869_fu_2522_p2 = (!mul_ln1118_1869_fu_2522_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1869_fu_2522_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1870_fu_3619_p0() {
    mul_ln1118_1870_fu_3619_p0 =  (sc_lv<16>) (sext_ln1118_1303_fu_10344832_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1870_fu_3619_p2() {
    mul_ln1118_1870_fu_3619_p2 = (!mul_ln1118_1870_fu_3619_p0.read().is_01() || !ap_const_lv23_2A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1870_fu_3619_p0.read()) * sc_biguint<23>(ap_const_lv23_2A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1871_fu_2200_p0() {
    mul_ln1118_1871_fu_2200_p0 =  (sc_lv<16>) (sext_ln1118_1306_fu_10344856_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1871_fu_2200_p2() {
    mul_ln1118_1871_fu_2200_p2 = (!mul_ln1118_1871_fu_2200_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1871_fu_2200_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1872_fu_2563_p0() {
    mul_ln1118_1872_fu_2563_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1872_fu_2563_p2() {
    mul_ln1118_1872_fu_2563_p2 = (!mul_ln1118_1872_fu_2563_p0.read().is_01() || !ap_const_lv25_D4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1872_fu_2563_p0.read()) * sc_biguint<25>(ap_const_lv25_D4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1873_fu_2475_p0() {
    mul_ln1118_1873_fu_2475_p0 =  (sc_lv<16>) (sext_ln1118_1305_fu_10344844_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1873_fu_2475_p2() {
    mul_ln1118_1873_fu_2475_p2 = (!mul_ln1118_1873_fu_2475_p0.read().is_01() || !ap_const_lv25_1FFFF66.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1873_fu_2475_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1874_fu_2565_p0() {
    mul_ln1118_1874_fu_2565_p0 =  (sc_lv<16>) (sext_ln1118_1321_fu_10345476_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1874_fu_2565_p2() {
    mul_ln1118_1874_fu_2565_p2 = (!mul_ln1118_1874_fu_2565_p0.read().is_01() || !ap_const_lv23_7FFFC7.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1874_fu_2565_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1875_fu_2566_p0() {
    mul_ln1118_1875_fu_2566_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1875_fu_2566_p2() {
    mul_ln1118_1875_fu_2566_p2 = (!mul_ln1118_1875_fu_2566_p0.read().is_01() || !ap_const_lv24_FFFFA2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1875_fu_2566_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1876_fu_3547_p0() {
    mul_ln1118_1876_fu_3547_p0 =  (sc_lv<16>) (sext_ln1118_1316_fu_10345440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1876_fu_3547_p2() {
    mul_ln1118_1876_fu_3547_p2 = (!mul_ln1118_1876_fu_3547_p0.read().is_01() || !ap_const_lv26_3FFFEEE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1876_fu_3547_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1877_fu_2568_p0() {
    mul_ln1118_1877_fu_2568_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1877_fu_2568_p2() {
    mul_ln1118_1877_fu_2568_p2 = (!mul_ln1118_1877_fu_2568_p0.read().is_01() || !ap_const_lv24_54.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1877_fu_2568_p0.read()) * sc_biguint<24>(ap_const_lv24_54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1878_fu_2569_p0() {
    mul_ln1118_1878_fu_2569_p0 =  (sc_lv<16>) (sext_ln1118_1316_fu_10345440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1878_fu_2569_p2() {
    mul_ln1118_1878_fu_2569_p2 = (!mul_ln1118_1878_fu_2569_p0.read().is_01() || !ap_const_lv26_152.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1878_fu_2569_p0.read()) * sc_biguint<26>(ap_const_lv26_152);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1879_fu_2570_p0() {
    mul_ln1118_1879_fu_2570_p0 =  (sc_lv<16>) (sext_ln1118_1317_fu_10345447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1879_fu_2570_p2() {
    mul_ln1118_1879_fu_2570_p2 = (!mul_ln1118_1879_fu_2570_p0.read().is_01() || !ap_const_lv25_1FFFF5C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1879_fu_2570_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1880_fu_2081_p0() {
    mul_ln1118_1880_fu_2081_p0 = sext_ln1118_1320_fu_10345471_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1880_fu_2081_p2() {
    mul_ln1118_1880_fu_2081_p2 = (!mul_ln1118_1880_fu_2081_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1880_fu_2081_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1881_fu_3062_p0() {
    mul_ln1118_1881_fu_3062_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1881_fu_3062_p2() {
    mul_ln1118_1881_fu_3062_p2 = (!mul_ln1118_1881_fu_3062_p0.read().is_01() || !ap_const_lv24_58.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1881_fu_3062_p0.read()) * sc_biguint<24>(ap_const_lv24_58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1882_fu_2573_p0() {
    mul_ln1118_1882_fu_2573_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1882_fu_2573_p2() {
    mul_ln1118_1882_fu_2573_p2 = (!mul_ln1118_1882_fu_2573_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1882_fu_2573_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1883_fu_3064_p0() {
    mul_ln1118_1883_fu_3064_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1883_fu_3064_p2() {
    mul_ln1118_1883_fu_3064_p2 = (!mul_ln1118_1883_fu_3064_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1883_fu_3064_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1884_fu_2575_p0() {
    mul_ln1118_1884_fu_2575_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1884_fu_2575_p2() {
    mul_ln1118_1884_fu_2575_p2 = (!mul_ln1118_1884_fu_2575_p0.read().is_01() || !ap_const_lv24_68.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1884_fu_2575_p0.read()) * sc_biguint<24>(ap_const_lv24_68);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1885_fu_2086_p0() {
    mul_ln1118_1885_fu_2086_p0 =  (sc_lv<16>) (sext_ln1118_1316_fu_10345440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1885_fu_2086_p2() {
    mul_ln1118_1885_fu_2086_p2 = (!mul_ln1118_1885_fu_2086_p0.read().is_01() || !ap_const_lv26_142.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1885_fu_2086_p0.read()) * sc_biguint<26>(ap_const_lv26_142);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1886_fu_3067_p0() {
    mul_ln1118_1886_fu_3067_p0 =  (sc_lv<16>) (sext_ln1118_1317_fu_10345447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1886_fu_3067_p2() {
    mul_ln1118_1886_fu_3067_p2 = (!mul_ln1118_1886_fu_3067_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1886_fu_3067_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1887_fu_3558_p0() {
    mul_ln1118_1887_fu_3558_p0 =  (sc_lv<16>) (sext_ln1118_1317_fu_10345447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1887_fu_3558_p2() {
    mul_ln1118_1887_fu_3558_p2 = (!mul_ln1118_1887_fu_3558_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1887_fu_3558_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1888_fu_2579_p0() {
    mul_ln1118_1888_fu_2579_p0 =  (sc_lv<16>) (sext_ln1118_1317_fu_10345447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1888_fu_2579_p2() {
    mul_ln1118_1888_fu_2579_p2 = (!mul_ln1118_1888_fu_2579_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1888_fu_2579_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1889_fu_2090_p0() {
    mul_ln1118_1889_fu_2090_p0 =  (sc_lv<16>) (sext_ln1118_1321_fu_10345476_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1889_fu_2090_p2() {
    mul_ln1118_1889_fu_2090_p2 = (!mul_ln1118_1889_fu_2090_p0.read().is_01() || !ap_const_lv23_7FFFD1.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1889_fu_2090_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1890_fu_2581_p0() {
    mul_ln1118_1890_fu_2581_p0 =  (sc_lv<16>) (sext_ln1118_1318_fu_10345456_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1890_fu_2581_p2() {
    mul_ln1118_1890_fu_2581_p2 = (!mul_ln1118_1890_fu_2581_p0.read().is_01() || !ap_const_lv24_FFFFB2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1890_fu_2581_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1891_fu_2003_p0() {
    mul_ln1118_1891_fu_2003_p0 =  (sc_lv<16>) (sext_ln1118_1317_fu_10345447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1891_fu_2003_p2() {
    mul_ln1118_1891_fu_2003_p2 = (!mul_ln1118_1891_fu_2003_p0.read().is_01() || !ap_const_lv25_F9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1891_fu_2003_p0.read()) * sc_biguint<25>(ap_const_lv25_F9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1892_fu_2583_p0() {
    mul_ln1118_1892_fu_2583_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1892_fu_2583_p2() {
    mul_ln1118_1892_fu_2583_p2 = (!mul_ln1118_1892_fu_2583_p0.read().is_01() || !ap_const_lv24_4A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1892_fu_2583_p0.read()) * sc_biguint<24>(ap_const_lv24_4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1893_fu_2584_p0() {
    mul_ln1118_1893_fu_2584_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1893_fu_2584_p2() {
    mul_ln1118_1893_fu_2584_p2 = (!mul_ln1118_1893_fu_2584_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1893_fu_2584_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1894_fu_2585_p0() {
    mul_ln1118_1894_fu_2585_p0 =  (sc_lv<16>) (sext_ln1118_1338_fu_10346093_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1894_fu_2585_p2() {
    mul_ln1118_1894_fu_2585_p2 = (!mul_ln1118_1894_fu_2585_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1894_fu_2585_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1895_fu_3076_p0() {
    mul_ln1118_1895_fu_3076_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1895_fu_3076_p2() {
    mul_ln1118_1895_fu_3076_p2 = (!mul_ln1118_1895_fu_3076_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1895_fu_3076_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1896_fu_2587_p0() {
    mul_ln1118_1896_fu_2587_p0 = sext_ln1118_1337_fu_10346088_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1896_fu_2587_p2() {
    mul_ln1118_1896_fu_2587_p2 = (!mul_ln1118_1896_fu_2587_p0.read().is_01() || !ap_const_lv26_11A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1896_fu_2587_p0.read()) * sc_biguint<26>(ap_const_lv26_11A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1897_fu_3078_p0() {
    mul_ln1118_1897_fu_3078_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1897_fu_3078_p2() {
    mul_ln1118_1897_fu_3078_p2 = (!mul_ln1118_1897_fu_3078_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1897_fu_3078_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1898_fu_2589_p0() {
    mul_ln1118_1898_fu_2589_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1898_fu_2589_p2() {
    mul_ln1118_1898_fu_2589_p2 = (!mul_ln1118_1898_fu_2589_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1898_fu_2589_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1899_fu_2501_p0() {
    mul_ln1118_1899_fu_2501_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1899_fu_2501_p2() {
    mul_ln1118_1899_fu_2501_p2 = (!mul_ln1118_1899_fu_2501_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1899_fu_2501_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1900_fu_3376_p0() {
    mul_ln1118_1900_fu_3376_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1900_fu_3376_p2() {
    mul_ln1118_1900_fu_3376_p2 = (!mul_ln1118_1900_fu_3376_p0.read().is_01() || !ap_const_lv25_F6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1900_fu_3376_p0.read()) * sc_biguint<25>(ap_const_lv25_F6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1901_fu_1957_p0() {
    mul_ln1118_1901_fu_1957_p0 =  (sc_lv<16>) (sext_ln1118_1338_fu_10346093_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1901_fu_1957_p2() {
    mul_ln1118_1901_fu_1957_p2 = (!mul_ln1118_1901_fu_1957_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1901_fu_1957_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1902_fu_3601_p0() {
    mul_ln1118_1902_fu_3601_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1902_fu_3601_p2() {
    mul_ln1118_1902_fu_3601_p2 = (!mul_ln1118_1902_fu_3601_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1902_fu_3601_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1903_fu_3522_p0() {
    mul_ln1118_1903_fu_3522_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1903_fu_3522_p2() {
    mul_ln1118_1903_fu_3522_p2 = (!mul_ln1118_1903_fu_3522_p0.read().is_01() || !ap_const_lv25_FA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1903_fu_3522_p0.read()) * sc_biguint<25>(ap_const_lv25_FA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1904_fu_2650_p0() {
    mul_ln1118_1904_fu_2650_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1904_fu_2650_p2() {
    mul_ln1118_1904_fu_2650_p2 = (!mul_ln1118_1904_fu_2650_p0.read().is_01() || !ap_const_lv24_FFFF99.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1904_fu_2650_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1905_fu_1942_p0() {
    mul_ln1118_1905_fu_1942_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1905_fu_1942_p2() {
    mul_ln1118_1905_fu_1942_p2 = (!mul_ln1118_1905_fu_1942_p0.read().is_01() || !ap_const_lv24_63.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1905_fu_1942_p0.read()) * sc_biguint<24>(ap_const_lv24_63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1906_fu_2410_p0() {
    mul_ln1118_1906_fu_2410_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1906_fu_2410_p2() {
    mul_ln1118_1906_fu_2410_p2 = (!mul_ln1118_1906_fu_2410_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1906_fu_2410_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1907_fu_3507_p0() {
    mul_ln1118_1907_fu_3507_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1907_fu_3507_p2() {
    mul_ln1118_1907_fu_3507_p2 = (!mul_ln1118_1907_fu_3507_p0.read().is_01() || !ap_const_lv24_79.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1907_fu_3507_p0.read()) * sc_biguint<24>(ap_const_lv24_79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1908_fu_3346_p0() {
    mul_ln1118_1908_fu_3346_p0 = sext_ln1118_1335_fu_10346072_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1908_fu_3346_p2() {
    mul_ln1118_1908_fu_3346_p2 = (!mul_ln1118_1908_fu_3346_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1908_fu_3346_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1909_fu_2556_p0() {
    mul_ln1118_1909_fu_2556_p0 =  (sc_lv<16>) (sext_ln1118_1339_fu_10346099_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1909_fu_2556_p2() {
    mul_ln1118_1909_fu_2556_p2 = (!mul_ln1118_1909_fu_2556_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1909_fu_2556_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1910_fu_2313_p0() {
    mul_ln1118_1910_fu_2313_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1910_fu_2313_p2() {
    mul_ln1118_1910_fu_2313_p2 = (!mul_ln1118_1910_fu_2313_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1910_fu_2313_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1911_fu_2070_p0() {
    mul_ln1118_1911_fu_2070_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1911_fu_2070_p2() {
    mul_ln1118_1911_fu_2070_p2 = (!mul_ln1118_1911_fu_2070_p0.read().is_01() || !ap_const_lv25_EA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1911_fu_2070_p0.read()) * sc_biguint<25>(ap_const_lv25_EA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1912_fu_1991_p0() {
    mul_ln1118_1912_fu_1991_p0 =  (sc_lv<16>) (sext_ln1118_1336_fu_10346077_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1912_fu_1991_p2() {
    mul_ln1118_1912_fu_1991_p2 = (!mul_ln1118_1912_fu_1991_p0.read().is_01() || !ap_const_lv25_8F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1912_fu_1991_p0.read()) * sc_biguint<25>(ap_const_lv25_8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_649_fu_2006_p0() {
    mul_ln1118_649_fu_2006_p0 =  (sc_lv<16>) (sext_ln1118_420_fu_10309833_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_649_fu_2006_p2() {
    mul_ln1118_649_fu_2006_p2 = (!mul_ln1118_649_fu_2006_p0.read().is_01() || !ap_const_lv26_126.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_649_fu_2006_p0.read()) * sc_biguint<26>(ap_const_lv26_126);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_650_fu_3566_p0() {
    mul_ln1118_650_fu_3566_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_650_fu_3566_p2() {
    mul_ln1118_650_fu_3566_p2 = (!mul_ln1118_650_fu_3566_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_650_fu_3566_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_651_fu_3567_p0() {
    mul_ln1118_651_fu_3567_p0 =  (sc_lv<16>) (sext_ln1118_fu_10309824_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_651_fu_3567_p2() {
    mul_ln1118_651_fu_3567_p2 = (!mul_ln1118_651_fu_3567_p0.read().is_01() || !ap_const_lv24_61.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_651_fu_3567_p0.read()) * sc_biguint<24>(ap_const_lv24_61);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_652_fu_2009_p0() {
    mul_ln1118_652_fu_2009_p0 =  (sc_lv<16>) (sext_ln1118_fu_10309824_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_652_fu_2009_p2() {
    mul_ln1118_652_fu_2009_p2 = (!mul_ln1118_652_fu_2009_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_652_fu_2009_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_653_fu_3569_p0() {
    mul_ln1118_653_fu_3569_p0 =  (sc_lv<16>) (sext_ln1118_420_fu_10309833_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_653_fu_3569_p2() {
    mul_ln1118_653_fu_3569_p2 = (!mul_ln1118_653_fu_3569_p0.read().is_01() || !ap_const_lv26_115.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_653_fu_3569_p0.read()) * sc_biguint<26>(ap_const_lv26_115);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_654_fu_3570_p0() {
    mul_ln1118_654_fu_3570_p0 =  (sc_lv<16>) (sext_ln1118_fu_10309824_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_654_fu_3570_p2() {
    mul_ln1118_654_fu_3570_p2 = (!mul_ln1118_654_fu_3570_p0.read().is_01() || !ap_const_lv24_47.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_654_fu_3570_p0.read()) * sc_biguint<24>(ap_const_lv24_47);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_655_fu_2012_p0() {
    mul_ln1118_655_fu_2012_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_655_fu_2012_p2() {
    mul_ln1118_655_fu_2012_p2 = (!mul_ln1118_655_fu_2012_p0.read().is_01() || !ap_const_lv25_1FFFF5E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_655_fu_2012_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_656_fu_2503_p0() {
    mul_ln1118_656_fu_2503_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_656_fu_2503_p2() {
    mul_ln1118_656_fu_2503_p2 = (!mul_ln1118_656_fu_2503_p0.read().is_01() || !ap_const_lv25_AB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_656_fu_2503_p0.read()) * sc_biguint<25>(ap_const_lv25_AB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_657_fu_3573_p0() {
    mul_ln1118_657_fu_3573_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_657_fu_3573_p2() {
    mul_ln1118_657_fu_3573_p2 = (!mul_ln1118_657_fu_3573_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_657_fu_3573_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_658_fu_3574_p0() {
    mul_ln1118_658_fu_3574_p0 =  (sc_lv<16>) (sext_ln1118_422_fu_10309851_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_658_fu_3574_p2() {
    mul_ln1118_658_fu_3574_p2 = (!mul_ln1118_658_fu_3574_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_658_fu_3574_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_659_fu_2016_p0() {
    mul_ln1118_659_fu_2016_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_659_fu_2016_p2() {
    mul_ln1118_659_fu_2016_p2 = (!mul_ln1118_659_fu_2016_p0.read().is_01() || !ap_const_lv25_1FFFF6C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_659_fu_2016_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_660_fu_3576_p0() {
    mul_ln1118_660_fu_3576_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_660_fu_3576_p2() {
    mul_ln1118_660_fu_3576_p2 = (!mul_ln1118_660_fu_3576_p0.read().is_01() || !ap_const_lv25_A3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_660_fu_3576_p0.read()) * sc_biguint<25>(ap_const_lv25_A3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_661_fu_2018_p0() {
    mul_ln1118_661_fu_2018_p0 =  (sc_lv<16>) (sext_ln1118_423_fu_10309858_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_661_fu_2018_p2() {
    mul_ln1118_661_fu_2018_p2 = (!mul_ln1118_661_fu_2018_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_661_fu_2018_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_662_fu_2999_p0() {
    mul_ln1118_662_fu_2999_p0 =  (sc_lv<16>) (sext_ln1118_422_fu_10309851_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_662_fu_2999_p2() {
    mul_ln1118_662_fu_2999_p2 = (!mul_ln1118_662_fu_2999_p0.read().is_01() || !ap_const_lv23_31.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_662_fu_2999_p0.read()) * sc_biguint<23>(ap_const_lv23_31);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_663_fu_3579_p0() {
    mul_ln1118_663_fu_3579_p0 =  (sc_lv<16>) (sext_ln1118_421_fu_10309839_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_663_fu_3579_p2() {
    mul_ln1118_663_fu_3579_p2 = (!mul_ln1118_663_fu_3579_p0.read().is_01() || !ap_const_lv25_E4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_663_fu_3579_p0.read()) * sc_biguint<25>(ap_const_lv25_E4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_664_fu_3580_p0() {
    mul_ln1118_664_fu_3580_p0 =  (sc_lv<16>) (sext_ln1118_fu_10309824_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_664_fu_3580_p2() {
    mul_ln1118_664_fu_3580_p2 = (!mul_ln1118_664_fu_3580_p0.read().is_01() || !ap_const_lv24_6F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_664_fu_3580_p0.read()) * sc_biguint<24>(ap_const_lv24_6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_665_fu_2022_p0() {
    mul_ln1118_665_fu_2022_p0 =  (sc_lv<16>) (sext_ln1118_fu_10309824_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_665_fu_2022_p2() {
    mul_ln1118_665_fu_2022_p2 = (!mul_ln1118_665_fu_2022_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_665_fu_2022_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_666_fu_3092_p0() {
    mul_ln1118_666_fu_3092_p0 =  (sc_lv<16>) (sext_ln1118_423_fu_10309858_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_666_fu_3092_p2() {
    mul_ln1118_666_fu_3092_p2 = (!mul_ln1118_666_fu_3092_p0.read().is_01() || !ap_const_lv22_1B.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_666_fu_3092_p0.read()) * sc_biguint<22>(ap_const_lv22_1B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_667_fu_2271_p0() {
    mul_ln1118_667_fu_2271_p0 =  (sc_lv<16>) (sext_ln1118_423_fu_10309858_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_667_fu_2271_p2() {
    mul_ln1118_667_fu_2271_p2 = (!mul_ln1118_667_fu_2271_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_667_fu_2271_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_668_fu_3584_p0() {
    mul_ln1118_668_fu_3584_p0 =  (sc_lv<16>) (sext_ln1118_422_fu_10309851_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_668_fu_3584_p2() {
    mul_ln1118_668_fu_3584_p2 = (!mul_ln1118_668_fu_3584_p0.read().is_01() || !ap_const_lv23_26.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_668_fu_3584_p0.read()) * sc_biguint<23>(ap_const_lv23_26);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_670_fu_2026_p0() {
    mul_ln1118_670_fu_2026_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_670_fu_2026_p2() {
    mul_ln1118_670_fu_2026_p2 = (!mul_ln1118_670_fu_2026_p0.read().is_01() || !ap_const_lv25_9E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_670_fu_2026_p0.read()) * sc_biguint<25>(ap_const_lv25_9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_671_fu_2027_p0() {
    mul_ln1118_671_fu_2027_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_671_fu_2027_p2() {
    mul_ln1118_671_fu_2027_p2 = (!mul_ln1118_671_fu_2027_p0.read().is_01() || !ap_const_lv25_D5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_671_fu_2027_p0.read()) * sc_biguint<25>(ap_const_lv25_D5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_672_fu_3587_p0() {
    mul_ln1118_672_fu_3587_p0 =  (sc_lv<16>) (sext_ln1118_442_fu_10310493_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_672_fu_3587_p2() {
    mul_ln1118_672_fu_3587_p2 = (!mul_ln1118_672_fu_3587_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_672_fu_3587_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_673_fu_3098_p0() {
    mul_ln1118_673_fu_3098_p0 = sext_ln1118_443_fu_10310498_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_673_fu_3098_p2() {
    mul_ln1118_673_fu_3098_p2 = (!mul_ln1118_673_fu_3098_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_673_fu_3098_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_674_fu_3653_p0() {
    mul_ln1118_674_fu_3653_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_674_fu_3653_p2() {
    mul_ln1118_674_fu_3653_p2 = (!mul_ln1118_674_fu_3653_p0.read().is_01() || !ap_const_lv24_FFFF97.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_674_fu_3653_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_675_fu_2234_p0() {
    mul_ln1118_675_fu_2234_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_675_fu_2234_p2() {
    mul_ln1118_675_fu_2234_p2 = (!mul_ln1118_675_fu_2234_p0.read().is_01() || !ap_const_lv25_B4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_675_fu_2234_p0.read()) * sc_biguint<25>(ap_const_lv25_B4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_676_fu_2073_p0() {
    mul_ln1118_676_fu_2073_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_676_fu_2073_p2() {
    mul_ln1118_676_fu_2073_p2 = (!mul_ln1118_676_fu_2073_p0.read().is_01() || !ap_const_lv25_B2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_676_fu_2073_p0.read()) * sc_biguint<25>(ap_const_lv25_B2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_677_fu_1830_p0() {
    mul_ln1118_677_fu_1830_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_677_fu_1830_p2() {
    mul_ln1118_677_fu_1830_p2 = (!mul_ln1118_677_fu_1830_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_677_fu_1830_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_678_fu_3638_p0() {
    mul_ln1118_678_fu_3638_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_678_fu_3638_p2() {
    mul_ln1118_678_fu_3638_p2 = (!mul_ln1118_678_fu_3638_p0.read().is_01() || !ap_const_lv24_46.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_678_fu_3638_p0.read()) * sc_biguint<24>(ap_const_lv24_46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_679_fu_3477_p0() {
    mul_ln1118_679_fu_3477_p0 =  (sc_lv<16>) (sext_ln1118_444_fu_10310503_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_679_fu_3477_p2() {
    mul_ln1118_679_fu_3477_p2 = (!mul_ln1118_679_fu_3477_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_679_fu_3477_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_680_fu_2058_p0() {
    mul_ln1118_680_fu_2058_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_680_fu_2058_p2() {
    mul_ln1118_680_fu_2058_p2 = (!mul_ln1118_680_fu_2058_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_680_fu_2058_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_681_fu_2526_p0() {
    mul_ln1118_681_fu_2526_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_681_fu_2526_p2() {
    mul_ln1118_681_fu_2526_p2 = (!mul_ln1118_681_fu_2526_p0.read().is_01() || !ap_const_lv24_FFFF99.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_681_fu_2526_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_682_fu_3623_p0() {
    mul_ln1118_682_fu_3623_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_682_fu_3623_p2() {
    mul_ln1118_682_fu_3623_p2 = (!mul_ln1118_682_fu_3623_p0.read().is_01() || !ap_const_lv25_89.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_682_fu_3623_p0.read()) * sc_biguint<25>(ap_const_lv25_89);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_683_fu_3462_p0() {
    mul_ln1118_683_fu_3462_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_683_fu_3462_p2() {
    mul_ln1118_683_fu_3462_p2 = (!mul_ln1118_683_fu_3462_p0.read().is_01() || !ap_const_lv24_FFFF8F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_683_fu_3462_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_684_fu_2043_p0() {
    mul_ln1118_684_fu_2043_p0 =  (sc_lv<16>) (sext_ln1118_440_fu_10310478_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_684_fu_2043_p2() {
    mul_ln1118_684_fu_2043_p2 = (!mul_ln1118_684_fu_2043_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_684_fu_2043_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_685_fu_1882_p0() {
    mul_ln1118_685_fu_1882_p0 =  (sc_lv<16>) (sext_ln1118_444_fu_10310503_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_685_fu_1882_p2() {
    mul_ln1118_685_fu_1882_p2 = (!mul_ln1118_685_fu_1882_p0.read().is_01() || !ap_const_lv23_39.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_685_fu_1882_p0.read()) * sc_biguint<23>(ap_const_lv23_39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_686_fu_1721_p0() {
    mul_ln1118_686_fu_1721_p0 =  (sc_lv<16>) (sext_ln1118_439_fu_10310468_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_686_fu_1721_p2() {
    mul_ln1118_686_fu_1721_p2 = (!mul_ln1118_686_fu_1721_p0.read().is_01() || !ap_const_lv24_74.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_686_fu_1721_p0.read()) * sc_biguint<24>(ap_const_lv24_74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_687_fu_2818_p0() {
    mul_ln1118_687_fu_2818_p0 =  (sc_lv<16>) (sext_ln1118_444_fu_10310503_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_687_fu_2818_p2() {
    mul_ln1118_687_fu_2818_p2 = (!mul_ln1118_687_fu_2818_p0.read().is_01() || !ap_const_lv23_2A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_687_fu_2818_p0.read()) * sc_biguint<23>(ap_const_lv23_2A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_688_fu_2221_p0() {
    mul_ln1118_688_fu_2221_p0 =  (sc_lv<16>) (sext_ln1118_444_fu_10310503_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_688_fu_2221_p2() {
    mul_ln1118_688_fu_2221_p2 = (!mul_ln1118_688_fu_2221_p0.read().is_01() || !ap_const_lv23_2D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_688_fu_2221_p0.read()) * sc_biguint<23>(ap_const_lv23_2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_689_fu_2203_p0() {
    mul_ln1118_689_fu_2203_p0 = sext_ln1118_438_fu_10310463_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_689_fu_2203_p2() {
    mul_ln1118_689_fu_2203_p2 = (!mul_ln1118_689_fu_2203_p0.read().is_01() || !ap_const_lv26_3FFFECA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_689_fu_2203_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_690_fu_1899_p0() {
    mul_ln1118_690_fu_1899_p0 =  (sc_lv<16>) (sext_ln1118_456_fu_10311076_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_690_fu_1899_p2() {
    mul_ln1118_690_fu_1899_p2 = (!mul_ln1118_690_fu_1899_p0.read().is_01() || !ap_const_lv24_62.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_690_fu_1899_p0.read()) * sc_biguint<24>(ap_const_lv24_62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_691_fu_2996_p0() {
    mul_ln1118_691_fu_2996_p0 =  (sc_lv<16>) (sext_ln1118_455_fu_10311066_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_691_fu_2996_p2() {
    mul_ln1118_691_fu_2996_p2 = (!mul_ln1118_691_fu_2996_p0.read().is_01() || !ap_const_lv25_1FFFF4D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_691_fu_2996_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_692_fu_2206_p0() {
    mul_ln1118_692_fu_2206_p0 =  (sc_lv<16>) (sext_ln1118_458_fu_10311089_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_692_fu_2206_p2() {
    mul_ln1118_692_fu_2206_p2 = (!mul_ln1118_692_fu_2206_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_692_fu_2206_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_693_fu_2045_p0() {
    mul_ln1118_693_fu_2045_p0 =  (sc_lv<16>) (sext_ln1118_455_fu_10311066_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_693_fu_2045_p2() {
    mul_ln1118_693_fu_2045_p2 = (!mul_ln1118_693_fu_2045_p0.read().is_01() || !ap_const_lv25_C5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_693_fu_2045_p0.read()) * sc_biguint<25>(ap_const_lv25_C5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_694_fu_3142_p0() {
    mul_ln1118_694_fu_3142_p0 =  (sc_lv<16>) (sext_ln1118_455_fu_10311066_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_694_fu_3142_p2() {
    mul_ln1118_694_fu_3142_p2 = (!mul_ln1118_694_fu_3142_p0.read().is_01() || !ap_const_lv25_BA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_694_fu_3142_p0.read()) * sc_biguint<25>(ap_const_lv25_BA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_695_fu_2352_p0() {
    mul_ln1118_695_fu_2352_p0 = sext_ln1118_454_fu_10311061_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_695_fu_2352_p2() {
    mul_ln1118_695_fu_2352_p2 = (!mul_ln1118_695_fu_2352_p0.read().is_01() || !ap_const_lv26_3FFFEE7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_695_fu_2352_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_696_fu_3449_p0() {
    mul_ln1118_696_fu_3449_p0 =  (sc_lv<16>) (sext_ln1118_458_fu_10311089_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_696_fu_3449_p2() {
    mul_ln1118_696_fu_3449_p2 = (!mul_ln1118_696_fu_3449_p0.read().is_01() || !ap_const_lv23_27.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_696_fu_3449_p0.read()) * sc_biguint<23>(ap_const_lv23_27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_697_fu_3288_p0() {
    mul_ln1118_697_fu_3288_p0 =  (sc_lv<16>) (sext_ln1118_456_fu_10311076_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_697_fu_3288_p2() {
    mul_ln1118_697_fu_3288_p2 = (!mul_ln1118_697_fu_3288_p0.read().is_01() || !ap_const_lv24_7A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_697_fu_3288_p0.read()) * sc_biguint<24>(ap_const_lv24_7A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_698_fu_2498_p0() {
    mul_ln1118_698_fu_2498_p0 =  (sc_lv<16>) (sext_ln1118_458_fu_10311089_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_698_fu_2498_p2() {
    mul_ln1118_698_fu_2498_p2 = (!mul_ln1118_698_fu_2498_p0.read().is_01() || !ap_const_lv23_37.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_698_fu_2498_p0.read()) * sc_biguint<23>(ap_const_lv23_37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_699_fu_2337_p0() {
    mul_ln1118_699_fu_2337_p0 =  (sc_lv<16>) (sext_ln1118_455_fu_10311066_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_699_fu_2337_p2() {
    mul_ln1118_699_fu_2337_p2 = (!mul_ln1118_699_fu_2337_p0.read().is_01() || !ap_const_lv25_1FFFF7D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_699_fu_2337_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_700_fu_2319_p0() {
    mul_ln1118_700_fu_2319_p0 =  (sc_lv<16>) (sext_ln1118_456_fu_10311076_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_700_fu_2319_p2() {
    mul_ln1118_700_fu_2319_p2 = (!mul_ln1118_700_fu_2319_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_700_fu_2319_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

}

