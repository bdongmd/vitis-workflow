#include "dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_965_fu_10346697_p2() {
    add_ln703_965_fu_10346697_p2 = (!add_ln703_961_fu_10346665_p2.read().is_01() || !add_ln703_964_fu_10346691_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_961_fu_10346665_p2.read()) + sc_biguint<16>(add_ln703_964_fu_10346691_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_966_fu_10346703_p2() {
    add_ln703_966_fu_10346703_p2 = (!mult_896_V_fu_10326440_p1.read().is_01() || !mult_864_V_fu_10325792_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_896_V_fu_10326440_p1.read()) + sc_bigint<16>(mult_864_V_fu_10325792_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_967_fu_10346709_p2() {
    add_ln703_967_fu_10346709_p2 = (!mult_960_V_fu_10327422_p1.read().is_01() || !mult_928_V_fu_10326957_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_960_V_fu_10327422_p1.read()) + sc_bigint<16>(mult_928_V_fu_10326957_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_968_fu_10346715_p2() {
    add_ln703_968_fu_10346715_p2 = (!add_ln703_966_fu_10346703_p2.read().is_01() || !add_ln703_967_fu_10346709_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_966_fu_10346703_p2.read()) + sc_biguint<16>(add_ln703_967_fu_10346709_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_969_fu_10346721_p2() {
    add_ln703_969_fu_10346721_p2 = (!mult_1056_V_fu_10329036_p1.read().is_01() || !mult_1024_V_fu_10328551_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1056_V_fu_10329036_p1.read()) + sc_bigint<16>(mult_1024_V_fu_10328551_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_970_fu_10346727_p2() {
    add_ln703_970_fu_10346727_p2 = (!mult_1184_V_fu_10331358_p1.read().is_01() || !mult_1152_V_fu_10330847_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1184_V_fu_10331358_p1.read()) + sc_bigint<16>(mult_1152_V_fu_10330847_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_971_fu_10346733_p2() {
    add_ln703_971_fu_10346733_p2 = (!add_ln703_969_fu_10346721_p2.read().is_01() || !add_ln703_970_fu_10346727_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_969_fu_10346721_p2.read()) + sc_biguint<16>(add_ln703_970_fu_10346727_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_972_fu_10346739_p2() {
    add_ln703_972_fu_10346739_p2 = (!add_ln703_968_fu_10346715_p2.read().is_01() || !add_ln703_971_fu_10346733_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_968_fu_10346715_p2.read()) + sc_biguint<16>(add_ln703_971_fu_10346733_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_973_fu_10358552_p2() {
    add_ln703_973_fu_10358552_p2 = (!add_ln703_965_reg_10359912.read().is_01() || !add_ln703_972_reg_10359917.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_965_reg_10359912.read()) + sc_biguint<16>(add_ln703_972_reg_10359917.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_974_fu_10358556_p2() {
    add_ln703_974_fu_10358556_p2 = (!add_ln703_958_fu_10358547_p2.read().is_01() || !add_ln703_973_fu_10358552_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_958_fu_10358547_p2.read()) + sc_biguint<16>(add_ln703_973_fu_10358552_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_975_fu_10346745_p2() {
    add_ln703_975_fu_10346745_p2 = (!sext_ln203_635_fu_10333078_p1.read().is_01() || !sext_ln203_613_fu_10331931_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_635_fu_10333078_p1.read()) + sc_bigint<15>(sext_ln203_613_fu_10331931_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_976_fu_10346751_p2() {
    add_ln703_976_fu_10346751_p2 = (!sext_ln203_661_fu_10334140_p1.read().is_01() || !sext_ln203_648_fu_10333665_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_661_fu_10334140_p1.read()) + sc_bigint<13>(sext_ln203_648_fu_10333665_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_977_fu_10346761_p2() {
    add_ln703_977_fu_10346761_p2 = (!add_ln703_975_fu_10346745_p2.read().is_01() || !sext_ln703_103_fu_10346757_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_975_fu_10346745_p2.read()) + sc_bigint<15>(sext_ln703_103_fu_10346757_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_978_fu_10346771_p2() {
    add_ln703_978_fu_10346771_p2 = (!sext_ln203_688_fu_10335249_p1.read().is_01() || !sext_ln203_674_fu_10334631_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_688_fu_10335249_p1.read()) + sc_bigint<15>(sext_ln203_674_fu_10334631_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_979_fu_10346781_p2() {
    add_ln703_979_fu_10346781_p2 = (!sext_ln203_716_fu_10336410_p1.read().is_01() || !sext_ln203_702_fu_10335821_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_716_fu_10336410_p1.read()) + sc_bigint<15>(sext_ln203_702_fu_10335821_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_980_fu_10346791_p2() {
    add_ln703_980_fu_10346791_p2 = (!sext_ln703_105_fu_10346777_p1.read().is_01() || !sext_ln703_106_fu_10346787_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_105_fu_10346777_p1.read()) + sc_bigint<16>(sext_ln703_106_fu_10346787_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_981_fu_10346797_p2() {
    add_ln703_981_fu_10346797_p2 = (!sext_ln703_104_fu_10346767_p1.read().is_01() || !add_ln703_980_fu_10346791_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_104_fu_10346767_p1.read()) + sc_biguint<16>(add_ln703_980_fu_10346791_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_982_fu_10346803_p2() {
    add_ln703_982_fu_10346803_p2 = (!sext_ln203_745_fu_10337620_p1.read().is_01() || !sext_ln203_730_fu_10337063_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_745_fu_10337620_p1.read()) + sc_bigint<15>(sext_ln203_730_fu_10337063_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_983_fu_10346813_p2() {
    add_ln703_983_fu_10346813_p2 = (!mult_1600_V_fu_10338810_p1.read().is_01() || !mult_1568_V_fu_10338263_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1600_V_fu_10338810_p1.read()) + sc_bigint<16>(mult_1568_V_fu_10338263_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_984_fu_10346819_p2() {
    add_ln703_984_fu_10346819_p2 = (!sext_ln703_107_fu_10346809_p1.read().is_01() || !add_ln703_983_fu_10346813_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_107_fu_10346809_p1.read()) + sc_biguint<16>(add_ln703_983_fu_10346813_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_985_fu_10346825_p2() {
    add_ln703_985_fu_10346825_p2 = (!sext_ln203_781_fu_10339855_p1.read().is_01() || !sext_ln203_773_fu_10339397_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_781_fu_10339855_p1.read()) + sc_bigint<15>(sext_ln203_773_fu_10339397_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_986_fu_10346835_p2() {
    add_ln703_986_fu_10346835_p2 = (!mult_1728_V_fu_10340979_p1.read().is_01() || !mult_1696_V_fu_10340426_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1728_V_fu_10340979_p1.read()) + sc_biguint<16>(mult_1696_V_fu_10340426_p4.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_987_fu_10346841_p2() {
    add_ln703_987_fu_10346841_p2 = (!sext_ln703_108_fu_10346831_p1.read().is_01() || !add_ln703_986_fu_10346835_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_108_fu_10346831_p1.read()) + sc_biguint<16>(add_ln703_986_fu_10346835_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_988_fu_10358562_p2() {
    add_ln703_988_fu_10358562_p2 = (!add_ln703_984_reg_10359927.read().is_01() || !add_ln703_987_reg_10359932.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_984_reg_10359927.read()) + sc_biguint<16>(add_ln703_987_reg_10359932.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_989_fu_10358566_p2() {
    add_ln703_989_fu_10358566_p2 = (!add_ln703_981_reg_10359922.read().is_01() || !add_ln703_988_fu_10358562_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_981_reg_10359922.read()) + sc_biguint<16>(add_ln703_988_fu_10358562_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_990_fu_10346847_p2() {
    add_ln703_990_fu_10346847_p2 = (!mult_1792_V_fu_10341976_p1.read().is_01() || !mult_1760_V_fu_10341443_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1792_V_fu_10341976_p1.read()) + sc_bigint<16>(mult_1760_V_fu_10341443_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_991_fu_10346853_p2() {
    add_ln703_991_fu_10346853_p2 = (!mult_1856_V_fu_10343129_p1.read().is_01() || !mult_1824_V_fu_10342548_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1856_V_fu_10343129_p1.read()) + sc_bigint<16>(mult_1824_V_fu_10342548_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_992_fu_10346859_p2() {
    add_ln703_992_fu_10346859_p2 = (!add_ln703_990_fu_10346847_p2.read().is_01() || !add_ln703_991_fu_10346853_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_990_fu_10346847_p2.read()) + sc_biguint<16>(add_ln703_991_fu_10346853_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_993_fu_10346865_p2() {
    add_ln703_993_fu_10346865_p2 = (!sext_ln203_877_fu_10344359_p1.read().is_01() || !sext_ln203_860_fu_10343747_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_877_fu_10344359_p1.read()) + sc_bigint<14>(sext_ln203_860_fu_10343747_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_994_fu_10346875_p2() {
    add_ln703_994_fu_10346875_p2 = (!mult_1984_V_fu_10345506_p1.read().is_01() || !mult_1952_V_fu_10344880_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1984_V_fu_10345506_p1.read()) + sc_bigint<16>(mult_1952_V_fu_10344880_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_995_fu_10346881_p2() {
    add_ln703_995_fu_10346881_p2 = (!sext_ln703_109_fu_10346871_p1.read().is_01() || !add_ln703_994_fu_10346875_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_109_fu_10346871_p1.read()) + sc_biguint<16>(add_ln703_994_fu_10346875_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_996_fu_10346887_p2() {
    add_ln703_996_fu_10346887_p2 = (!add_ln703_992_fu_10346859_p2.read().is_01() || !add_ln703_995_fu_10346881_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_992_fu_10346859_p2.read()) + sc_biguint<16>(add_ln703_995_fu_10346881_p2.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_997_fu_10346893_p2() {
    add_ln703_997_fu_10346893_p2 = (!sext_ln203_623_fu_10332448_p1.read().is_01() || !sext_ln203_921_fu_10346127_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_623_fu_10332448_p1.read()) + sc_bigint<15>(sext_ln203_921_fu_10346127_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_998_fu_10346899_p2() {
    add_ln703_998_fu_10346899_p2 = (!sext_ln203_43_fu_10329661_p1.read().is_01() || !ap_const_lv10_97.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_43_fu_10329661_p1.read()) + sc_biguint<10>(ap_const_lv10_97));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_999_fu_10346909_p2() {
    add_ln703_999_fu_10346909_p2 = (!add_ln703_997_fu_10346893_p2.read().is_01() || !sext_ln703_110_fu_10346905_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_997_fu_10346893_p2.read()) + sc_bigint<15>(sext_ln703_110_fu_10346905_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_add_ln703_fu_10346565_p2() {
    add_ln703_fu_10346565_p2 = (!sext_ln203_196_fu_10311117_p1.read().is_01() || !sext_ln203_180_fu_10310543_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_196_fu_10311117_p1.read()) + sc_bigint<15>(sext_ln203_180_fu_10310543_p1.read()));
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_block_state1_pp0_stage0_iter0() {
    ap_block_state1_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_block_state2_pp0_stage0_iter1() {
    ap_block_state2_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_0() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_0 = ap_return_0_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_0 = add_ln703_1197_fu_10358576_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_1() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_1 = ap_return_1_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_1 = acc_1_V_fu_10358615_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_10() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_10 = ap_return_10_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_10 = acc_10_V_fu_10358936_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_11() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_11 = ap_return_11_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_11 = acc_11_V_fu_10358979_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_12() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_12 = ap_return_12_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_12 = acc_12_V_fu_10359018_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_13() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_13 = ap_return_13_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_13 = acc_13_V_fu_10359065_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_14() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_14 = ap_return_14_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_14 = acc_14_V_fu_10359098_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_15() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_15 = ap_return_15_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_15 = acc_15_V_fu_10359151_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_16() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_16 = ap_return_16_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_16 = acc_16_V_fu_10359184_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_17() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_17 = ap_return_17_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_17 = acc_17_V_fu_10359203_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_18() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_18 = ap_return_18_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_18 = acc_18_V_fu_10359222_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_19() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_19 = ap_return_19_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_19 = acc_19_V_fu_10359279_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_2() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_2 = ap_return_2_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_2 = acc_2_V_fu_10358668_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_20() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_20 = ap_return_20_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_20 = acc_20_V_fu_10359308_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_21() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_21 = ap_return_21_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_21 = acc_21_V_fu_10359326_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_22() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_22 = ap_return_22_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_22 = acc_22_V_fu_10359368_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_23() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_23 = ap_return_23_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_23 = acc_23_V_fu_10359417_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_24() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_24 = ap_return_24_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_24 = acc_24_V_fu_10359454_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_25() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_25 = ap_return_25_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_25 = acc_25_V_fu_10359473_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_26() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_26 = ap_return_26_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_26 = acc_26_V_fu_10359512_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_27() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_27 = ap_return_27_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_27 = acc_27_V_fu_10359531_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_28() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_28 = ap_return_28_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_28 = acc_28_V_fu_10359584_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_29() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_29 = ap_return_29_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_29 = acc_29_V_fu_10359603_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_3() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_3 = ap_return_3_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_3 = acc_3_V_fu_10358725_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_30() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_30 = ap_return_30_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_30 = acc_30_V_fu_10359646_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_31() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_31 = ap_return_31_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_31 = acc_31_V_fu_10359699_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_4() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_4 = ap_return_4_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_4 = acc_4_V_fu_10358764_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_5() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_5 = ap_return_5_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_5 = acc_5_V_fu_10358783_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_6() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_6 = ap_return_6_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_6 = acc_6_V_fu_10358802_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_7() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_7 = ap_return_7_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_7 = acc_7_V_fu_10358831_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_8() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_8 = ap_return_8_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_8 = acc_8_V_fu_10358864_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_ap_return_9() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_9 = ap_return_9_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_9 = acc_9_V_fu_10358907_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1000_fu_2372_p0() {
    mul_ln1118_1000_fu_2372_p0 =  (sc_lv<16>) (sext_ln1118_693_fu_10319874_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1000_fu_2372_p2() {
    mul_ln1118_1000_fu_2372_p2 = (!mul_ln1118_1000_fu_2372_p0.read().is_01() || !ap_const_lv26_10A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1000_fu_2372_p0.read()) * sc_biguint<26>(ap_const_lv26_10A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1001_fu_2373_p0() {
    mul_ln1118_1001_fu_2373_p0 =  (sc_lv<16>) (sext_ln1118_695_fu_10319891_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1001_fu_2373_p2() {
    mul_ln1118_1001_fu_2373_p2 = (!mul_ln1118_1001_fu_2373_p0.read().is_01() || !ap_const_lv23_25.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1001_fu_2373_p0.read()) * sc_biguint<23>(ap_const_lv23_25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1002_fu_2374_p0() {
    mul_ln1118_1002_fu_2374_p0 =  (sc_lv<16>) (sext_ln1118_691_fu_10319861_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1002_fu_2374_p2() {
    mul_ln1118_1002_fu_2374_p2 = (!mul_ln1118_1002_fu_2374_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1002_fu_2374_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1003_fu_2865_p0() {
    mul_ln1118_1003_fu_2865_p0 =  (sc_lv<16>) (sext_ln708_320_fu_10320484_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1003_fu_2865_p2() {
    mul_ln1118_1003_fu_2865_p2 = (!mul_ln1118_1003_fu_2865_p0.read().is_01() || !ap_const_lv26_177.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1003_fu_2865_p0.read()) * sc_biguint<26>(ap_const_lv26_177);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1004_fu_2376_p0() {
    mul_ln1118_1004_fu_2376_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1004_fu_2376_p2() {
    mul_ln1118_1004_fu_2376_p2 = (!mul_ln1118_1004_fu_2376_p0.read().is_01() || !ap_const_lv25_ED.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1004_fu_2376_p0.read()) * sc_biguint<25>(ap_const_lv25_ED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1005_fu_2377_p0() {
    mul_ln1118_1005_fu_2377_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1005_fu_2377_p2() {
    mul_ln1118_1005_fu_2377_p2 = (!mul_ln1118_1005_fu_2377_p0.read().is_01() || !ap_const_lv25_1FFFF66.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1005_fu_2377_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1006_fu_2378_p0() {
    mul_ln1118_1006_fu_2378_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1006_fu_2378_p2() {
    mul_ln1118_1006_fu_2378_p2 = (!mul_ln1118_1006_fu_2378_p0.read().is_01() || !ap_const_lv24_FFFFB2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1006_fu_2378_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1007_fu_1889_p0() {
    mul_ln1118_1007_fu_1889_p0 =  (sc_lv<16>) (sext_ln708_317_fu_10320453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1007_fu_1889_p2() {
    mul_ln1118_1007_fu_1889_p2 = (!mul_ln1118_1007_fu_1889_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1007_fu_1889_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1008_fu_2870_p0() {
    mul_ln1118_1008_fu_2870_p0 =  (sc_lv<16>) (sext_ln708_317_fu_10320453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1008_fu_2870_p2() {
    mul_ln1118_1008_fu_2870_p2 = (!mul_ln1118_1008_fu_2870_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1008_fu_2870_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1009_fu_1891_p0() {
    mul_ln1118_1009_fu_1891_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1009_fu_1891_p2() {
    mul_ln1118_1009_fu_1891_p2 = (!mul_ln1118_1009_fu_1891_p0.read().is_01() || !ap_const_lv24_61.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1009_fu_1891_p0.read()) * sc_biguint<24>(ap_const_lv24_61);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1010_fu_2382_p0() {
    mul_ln1118_1010_fu_2382_p0 =  (sc_lv<16>) (sext_ln708_323_fu_10320498_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1010_fu_2382_p2() {
    mul_ln1118_1010_fu_2382_p2 = (!mul_ln1118_1010_fu_2382_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1010_fu_2382_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1011_fu_3363_p0() {
    mul_ln1118_1011_fu_3363_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1011_fu_3363_p2() {
    mul_ln1118_1011_fu_3363_p2 = (!mul_ln1118_1011_fu_3363_p0.read().is_01() || !ap_const_lv24_FFFF9A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1011_fu_3363_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1012_fu_2874_p0() {
    mul_ln1118_1012_fu_2874_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1012_fu_2874_p2() {
    mul_ln1118_1012_fu_2874_p2 = (!mul_ln1118_1012_fu_2874_p0.read().is_01() || !ap_const_lv24_75.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1012_fu_2874_p0.read()) * sc_biguint<24>(ap_const_lv24_75);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1013_fu_2385_p0() {
    mul_ln1118_1013_fu_2385_p0 =  (sc_lv<16>) (sext_ln708_317_fu_10320453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1013_fu_2385_p2() {
    mul_ln1118_1013_fu_2385_p2 = (!mul_ln1118_1013_fu_2385_p0.read().is_01() || !ap_const_lv23_25.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1013_fu_2385_p0.read()) * sc_biguint<23>(ap_const_lv23_25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1014_fu_2346_p0() {
    mul_ln1118_1014_fu_2346_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1014_fu_2346_p2() {
    mul_ln1118_1014_fu_2346_p2 = (!mul_ln1118_1014_fu_2346_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1014_fu_2346_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1015_fu_2185_p0() {
    mul_ln1118_1015_fu_2185_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1015_fu_2185_p2() {
    mul_ln1118_1015_fu_2185_p2 = (!mul_ln1118_1015_fu_2185_p0.read().is_01() || !ap_const_lv25_F5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1015_fu_2185_p0.read()) * sc_biguint<25>(ap_const_lv25_F5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1016_fu_2024_p0() {
    mul_ln1118_1016_fu_2024_p0 =  (sc_lv<16>) (sext_ln708_317_fu_10320453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1016_fu_2024_p2() {
    mul_ln1118_1016_fu_2024_p2 = (!mul_ln1118_1016_fu_2024_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1016_fu_2024_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1017_fu_1863_p0() {
    mul_ln1118_1017_fu_1863_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1017_fu_1863_p2() {
    mul_ln1118_1017_fu_1863_p2 = (!mul_ln1118_1017_fu_1863_p0.read().is_01() || !ap_const_lv25_D8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1017_fu_1863_p0.read()) * sc_biguint<25>(ap_const_lv25_D8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1018_fu_2960_p0() {
    mul_ln1118_1018_fu_2960_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1018_fu_2960_p2() {
    mul_ln1118_1018_fu_2960_p2 = (!mul_ln1118_1018_fu_2960_p0.read().is_01() || !ap_const_lv25_8F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1018_fu_2960_p0.read()) * sc_biguint<25>(ap_const_lv25_8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1019_fu_2799_p0() {
    mul_ln1118_1019_fu_2799_p0 =  (sc_lv<16>) (sext_ln708_320_fu_10320484_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1019_fu_2799_p2() {
    mul_ln1118_1019_fu_2799_p2 = (!mul_ln1118_1019_fu_2799_p0.read().is_01() || !ap_const_lv26_132.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1019_fu_2799_p0.read()) * sc_biguint<26>(ap_const_lv26_132);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1020_fu_2638_p0() {
    mul_ln1118_1020_fu_2638_p0 =  (sc_lv<16>) (sext_ln708_319_fu_10320473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1020_fu_2638_p2() {
    mul_ln1118_1020_fu_2638_p2 = (!mul_ln1118_1020_fu_2638_p0.read().is_01() || !ap_const_lv25_1FFFF14.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1020_fu_2638_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF14);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1021_fu_1848_p0() {
    mul_ln1118_1021_fu_1848_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1021_fu_1848_p2() {
    mul_ln1118_1021_fu_1848_p2 = (!mul_ln1118_1021_fu_1848_p0.read().is_01() || !ap_const_lv24_57.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1021_fu_1848_p0.read()) * sc_biguint<24>(ap_const_lv24_57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1022_fu_2945_p0() {
    mul_ln1118_1022_fu_2945_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1022_fu_2945_p2() {
    mul_ln1118_1022_fu_2945_p2 = (!mul_ln1118_1022_fu_2945_p0.read().is_01() || !ap_const_lv24_4C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1022_fu_2945_p0.read()) * sc_biguint<24>(ap_const_lv24_4C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1023_fu_2155_p0() {
    mul_ln1118_1023_fu_2155_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1023_fu_2155_p2() {
    mul_ln1118_1023_fu_2155_p2 = (!mul_ln1118_1023_fu_2155_p0.read().is_01() || !ap_const_lv24_6E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1023_fu_2155_p0.read()) * sc_biguint<24>(ap_const_lv24_6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1024_fu_1994_p0() {
    mul_ln1118_1024_fu_1994_p0 =  (sc_lv<16>) (sext_ln708_318_fu_10320461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1024_fu_1994_p2() {
    mul_ln1118_1024_fu_1994_p2 = (!mul_ln1118_1024_fu_1994_p0.read().is_01() || !ap_const_lv24_FFFF96.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1024_fu_1994_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1025_fu_3091_p0() {
    mul_ln1118_1025_fu_3091_p0 =  (sc_lv<16>) (sext_ln1118_714_fu_10321025_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1025_fu_3091_p2() {
    mul_ln1118_1025_fu_3091_p2 = (!mul_ln1118_1025_fu_3091_p0.read().is_01() || !ap_const_lv22_3FFFEA.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1025_fu_3091_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1026_fu_2301_p0() {
    mul_ln1118_1026_fu_2301_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1026_fu_2301_p2() {
    mul_ln1118_1026_fu_2301_p2 = (!mul_ln1118_1026_fu_2301_p0.read().is_01() || !ap_const_lv25_93.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1026_fu_2301_p0.read()) * sc_biguint<25>(ap_const_lv25_93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1027_fu_2614_p0() {
    mul_ln1118_1027_fu_2614_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1027_fu_2614_p2() {
    mul_ln1118_1027_fu_2614_p2 = (!mul_ln1118_1027_fu_2614_p0.read().is_01() || !ap_const_lv25_DB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1027_fu_2614_p0.read()) * sc_biguint<25>(ap_const_lv25_DB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1028_fu_3568_p0() {
    mul_ln1118_1028_fu_3568_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1028_fu_3568_p2() {
    mul_ln1118_1028_fu_3568_p2 = (!mul_ln1118_1028_fu_3568_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1028_fu_3568_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1029_fu_2149_p0() {
    mul_ln1118_1029_fu_2149_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1029_fu_2149_p2() {
    mul_ln1118_1029_fu_2149_p2 = (!mul_ln1118_1029_fu_2149_p0.read().is_01() || !ap_const_lv25_1FFFF35.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1029_fu_2149_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1030_fu_2617_p0() {
    mul_ln1118_1030_fu_2617_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1030_fu_2617_p2() {
    mul_ln1118_1030_fu_2617_p2 = (!mul_ln1118_1030_fu_2617_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1030_fu_2617_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1031_fu_2456_p0() {
    mul_ln1118_1031_fu_2456_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1031_fu_2456_p2() {
    mul_ln1118_1031_fu_2456_p2 = (!mul_ln1118_1031_fu_2456_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1031_fu_2456_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1032_fu_2295_p0() {
    mul_ln1118_1032_fu_2295_p0 =  (sc_lv<16>) (sext_ln1118_717_fu_10321041_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1032_fu_2295_p2() {
    mul_ln1118_1032_fu_2295_p2 = (!mul_ln1118_1032_fu_2295_p0.read().is_01() || !ap_const_lv23_7FFFCA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1032_fu_2295_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1033_fu_3392_p0() {
    mul_ln1118_1033_fu_3392_p0 =  (sc_lv<16>) (sext_ln1118_717_fu_10321041_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1033_fu_3392_p2() {
    mul_ln1118_1033_fu_3392_p2 = (!mul_ln1118_1033_fu_3392_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1033_fu_3392_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1034_fu_1973_p0() {
    mul_ln1118_1034_fu_1973_p0 =  (sc_lv<16>) (sext_ln1118_717_fu_10321041_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1034_fu_1973_p2() {
    mul_ln1118_1034_fu_1973_p2 = (!mul_ln1118_1034_fu_1973_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1034_fu_1973_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1035_fu_2441_p0() {
    mul_ln1118_1035_fu_2441_p0 = sext_ln1118_715_fu_10321031_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1035_fu_2441_p2() {
    mul_ln1118_1035_fu_2441_p2 = (!mul_ln1118_1035_fu_2441_p0.read().is_01() || !ap_const_lv24_FFFF83.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1035_fu_2441_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1036_fu_2280_p0() {
    mul_ln1118_1036_fu_2280_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1036_fu_2280_p2() {
    mul_ln1118_1036_fu_2280_p2 = (!mul_ln1118_1036_fu_2280_p0.read().is_01() || !ap_const_lv25_8B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1036_fu_2280_p0.read()) * sc_biguint<25>(ap_const_lv25_8B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1037_fu_3377_p0() {
    mul_ln1118_1037_fu_3377_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1037_fu_3377_p2() {
    mul_ln1118_1037_fu_3377_p2 = (!mul_ln1118_1037_fu_3377_p0.read().is_01() || !ap_const_lv25_1FFFF63.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1037_fu_3377_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1038_fu_3216_p0() {
    mul_ln1118_1038_fu_3216_p0 =  (sc_lv<16>) (sext_ln1118_717_fu_10321041_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1038_fu_3216_p2() {
    mul_ln1118_1038_fu_3216_p2 = (!mul_ln1118_1038_fu_3216_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1038_fu_3216_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1039_fu_3055_p0() {
    mul_ln1118_1039_fu_3055_p0 =  (sc_lv<16>) (sext_ln1118_714_fu_10321025_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1039_fu_3055_p2() {
    mul_ln1118_1039_fu_3055_p2 = (!mul_ln1118_1039_fu_3055_p0.read().is_01() || !ap_const_lv22_1B.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1039_fu_3055_p0.read()) * sc_biguint<22>(ap_const_lv22_1B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1040_fu_3523_p0() {
    mul_ln1118_1040_fu_3523_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1040_fu_3523_p2() {
    mul_ln1118_1040_fu_3523_p2 = (!mul_ln1118_1040_fu_3523_p0.read().is_01() || !ap_const_lv25_B4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1040_fu_3523_p0.read()) * sc_biguint<25>(ap_const_lv25_B4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1041_fu_2104_p0() {
    mul_ln1118_1041_fu_2104_p0 =  (sc_lv<16>) (sext_ln1118_717_fu_10321041_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1041_fu_2104_p2() {
    mul_ln1118_1041_fu_2104_p2 = (!mul_ln1118_1041_fu_2104_p0.read().is_01() || !ap_const_lv23_2C.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1041_fu_2104_p0.read()) * sc_biguint<23>(ap_const_lv23_2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1042_fu_3524_p0() {
    mul_ln1118_1042_fu_3524_p0 = sext_ln1118_716_fu_10321036_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1042_fu_3524_p2() {
    mul_ln1118_1042_fu_3524_p2 = (!mul_ln1118_1042_fu_3524_p0.read().is_01() || !ap_const_lv21_1FFFF5.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1042_fu_3524_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1043_fu_1966_p0() {
    mul_ln1118_1043_fu_1966_p0 =  (sc_lv<16>) (sext_ln1118_713_fu_10321011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1043_fu_1966_p2() {
    mul_ln1118_1043_fu_1966_p2 = (!mul_ln1118_1043_fu_1966_p0.read().is_01() || !ap_const_lv25_1FFFF6D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1043_fu_1966_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1044_fu_3036_p0() {
    mul_ln1118_1044_fu_3036_p0 =  (sc_lv<16>) (sext_ln708_361_fu_10321622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1044_fu_3036_p2() {
    mul_ln1118_1044_fu_3036_p2 = (!mul_ln1118_1044_fu_3036_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1044_fu_3036_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1045_fu_1968_p0() {
    mul_ln1118_1045_fu_1968_p0 =  (sc_lv<16>) (sext_ln708_360_fu_10321616_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1045_fu_1968_p2() {
    mul_ln1118_1045_fu_1968_p2 = (!mul_ln1118_1045_fu_1968_p0.read().is_01() || !ap_const_lv26_12C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1045_fu_1968_p0.read()) * sc_biguint<26>(ap_const_lv26_12C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1046_fu_3528_p0() {
    mul_ln1118_1046_fu_3528_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1046_fu_3528_p2() {
    mul_ln1118_1046_fu_3528_p2 = (!mul_ln1118_1046_fu_3528_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1046_fu_3528_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1047_fu_1970_p0() {
    mul_ln1118_1047_fu_1970_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1047_fu_1970_p2() {
    mul_ln1118_1047_fu_1970_p2 = (!mul_ln1118_1047_fu_1970_p0.read().is_01() || !ap_const_lv25_8D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1047_fu_1970_p0.read()) * sc_biguint<25>(ap_const_lv25_8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1048_fu_3530_p0() {
    mul_ln1118_1048_fu_3530_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1048_fu_3530_p2() {
    mul_ln1118_1048_fu_3530_p2 = (!mul_ln1118_1048_fu_3530_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1048_fu_3530_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1049_fu_3531_p0() {
    mul_ln1118_1049_fu_3531_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1049_fu_3531_p2() {
    mul_ln1118_1049_fu_3531_p2 = (!mul_ln1118_1049_fu_3531_p0.read().is_01() || !ap_const_lv25_1FFFF73.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1049_fu_3531_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF73);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1050_fu_3042_p0() {
    mul_ln1118_1050_fu_3042_p0 =  (sc_lv<16>) (sext_ln708_361_fu_10321622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1050_fu_3042_p2() {
    mul_ln1118_1050_fu_3042_p2 = (!mul_ln1118_1050_fu_3042_p0.read().is_01() || !ap_const_lv24_51.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1050_fu_3042_p0.read()) * sc_biguint<24>(ap_const_lv24_51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1051_fu_3533_p0() {
    mul_ln1118_1051_fu_3533_p0 =  (sc_lv<16>) (sext_ln708_363_fu_10321634_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1051_fu_3533_p2() {
    mul_ln1118_1051_fu_3533_p2 = (!mul_ln1118_1051_fu_3533_p0.read().is_01() || !ap_const_lv23_35.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1051_fu_3533_p0.read()) * sc_biguint<23>(ap_const_lv23_35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1052_fu_1975_p0() {
    mul_ln1118_1052_fu_1975_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1052_fu_1975_p2() {
    mul_ln1118_1052_fu_1975_p2 = (!mul_ln1118_1052_fu_1975_p0.read().is_01() || !ap_const_lv25_1FFFF28.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1052_fu_1975_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF28);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1053_fu_3535_p0() {
    mul_ln1118_1053_fu_3535_p0 =  (sc_lv<16>) (sext_ln708_361_fu_10321622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1053_fu_3535_p2() {
    mul_ln1118_1053_fu_3535_p2 = (!mul_ln1118_1053_fu_3535_p0.read().is_01() || !ap_const_lv24_61.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1053_fu_3535_p0.read()) * sc_biguint<24>(ap_const_lv24_61);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1054_fu_1977_p0() {
    mul_ln1118_1054_fu_1977_p0 =  (sc_lv<16>) (sext_ln708_358_fu_10321600_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1054_fu_1977_p2() {
    mul_ln1118_1054_fu_1977_p2 = (!mul_ln1118_1054_fu_1977_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1054_fu_1977_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1055_fu_3537_p0() {
    mul_ln1118_1055_fu_3537_p0 =  (sc_lv<16>) (sext_ln708_358_fu_10321600_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1055_fu_3537_p2() {
    mul_ln1118_1055_fu_3537_p2 = (!mul_ln1118_1055_fu_3537_p0.read().is_01() || !ap_const_lv22_3FFFEA.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1055_fu_3537_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1056_fu_3538_p0() {
    mul_ln1118_1056_fu_3538_p0 =  (sc_lv<16>) (sext_ln708_361_fu_10321622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1056_fu_3538_p2() {
    mul_ln1118_1056_fu_3538_p2 = (!mul_ln1118_1056_fu_3538_p0.read().is_01() || !ap_const_lv24_6D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1056_fu_3538_p0.read()) * sc_biguint<24>(ap_const_lv24_6D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1057_fu_3539_p0() {
    mul_ln1118_1057_fu_3539_p0 =  (sc_lv<16>) (sext_ln708_359_fu_10321606_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1057_fu_3539_p2() {
    mul_ln1118_1057_fu_3539_p2 = (!mul_ln1118_1057_fu_3539_p0.read().is_01() || !ap_const_lv25_1FFFF3E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1057_fu_3539_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1058_fu_3540_p0() {
    mul_ln1118_1058_fu_3540_p0 =  (sc_lv<16>) (sext_ln708_363_fu_10321634_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1058_fu_3540_p2() {
    mul_ln1118_1058_fu_3540_p2 = (!mul_ln1118_1058_fu_3540_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1058_fu_3540_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1059_fu_3541_p0() {
    mul_ln1118_1059_fu_3541_p0 =  (sc_lv<16>) (sext_ln708_363_fu_10321634_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1059_fu_3541_p2() {
    mul_ln1118_1059_fu_3541_p2 = (!mul_ln1118_1059_fu_3541_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1059_fu_3541_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1060_fu_3052_p0() {
    mul_ln1118_1060_fu_3052_p0 =  (sc_lv<16>) (sext_ln708_360_fu_10321616_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1060_fu_3052_p2() {
    mul_ln1118_1060_fu_3052_p2 = (!mul_ln1118_1060_fu_3052_p0.read().is_01() || !ap_const_lv26_3FFFDE7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1060_fu_3052_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1061_fu_3543_p0() {
    mul_ln1118_1061_fu_3543_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1061_fu_3543_p2() {
    mul_ln1118_1061_fu_3543_p2 = (!mul_ln1118_1061_fu_3543_p0.read().is_01() || !ap_const_lv24_FFFF87.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1061_fu_3543_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1062_fu_3544_p0() {
    mul_ln1118_1062_fu_3544_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1062_fu_3544_p2() {
    mul_ln1118_1062_fu_3544_p2 = (!mul_ln1118_1062_fu_3544_p0.read().is_01() || !ap_const_lv24_FFFFA2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1062_fu_3544_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1063_fu_1986_p0() {
    mul_ln1118_1063_fu_1986_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1063_fu_1986_p2() {
    mul_ln1118_1063_fu_1986_p2 = (!mul_ln1118_1063_fu_1986_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1063_fu_1986_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1064_fu_3546_p0() {
    mul_ln1118_1064_fu_3546_p0 =  (sc_lv<16>) (sext_ln1118_746_fu_10322246_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1064_fu_3546_p2() {
    mul_ln1118_1064_fu_3546_p2 = (!mul_ln1118_1064_fu_3546_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1064_fu_3546_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1065_fu_1988_p0() {
    mul_ln1118_1065_fu_1988_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1065_fu_1988_p2() {
    mul_ln1118_1065_fu_1988_p2 = (!mul_ln1118_1065_fu_1988_p0.read().is_01() || !ap_const_lv25_1FFFF17.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1065_fu_1988_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1066_fu_3058_p0() {
    mul_ln1118_1066_fu_3058_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1066_fu_3058_p2() {
    mul_ln1118_1066_fu_3058_p2 = (!mul_ln1118_1066_fu_3058_p0.read().is_01() || !ap_const_lv25_1FFFF2E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1066_fu_3058_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1067_fu_2480_p0() {
    mul_ln1118_1067_fu_2480_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1067_fu_2480_p2() {
    mul_ln1118_1067_fu_2480_p2 = (!mul_ln1118_1067_fu_2480_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1067_fu_2480_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1068_fu_3550_p0() {
    mul_ln1118_1068_fu_3550_p0 =  (sc_lv<16>) (sext_ln1118_745_fu_10322241_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1068_fu_3550_p2() {
    mul_ln1118_1068_fu_3550_p2 = (!mul_ln1118_1068_fu_3550_p0.read().is_01() || !ap_const_lv21_1FFFF5.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1068_fu_3550_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1069_fu_1992_p0() {
    mul_ln1118_1069_fu_1992_p0 = sext_ln1118_741_fu_10322209_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1069_fu_1992_p2() {
    mul_ln1118_1069_fu_1992_p2 = (!mul_ln1118_1069_fu_1992_p0.read().is_01() || !ap_const_lv23_33.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1069_fu_1992_p0.read()) * sc_biguint<23>(ap_const_lv23_33);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1070_fu_3096_p0() {
    mul_ln1118_1070_fu_3096_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1070_fu_3096_p2() {
    mul_ln1118_1070_fu_3096_p2 = (!mul_ln1118_1070_fu_3096_p0.read().is_01() || !ap_const_lv25_1FFFF69.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1070_fu_3096_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1071_fu_1677_p0() {
    mul_ln1118_1071_fu_1677_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1071_fu_1677_p2() {
    mul_ln1118_1071_fu_1677_p2 = (!mul_ln1118_1071_fu_1677_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1071_fu_1677_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1072_fu_2774_p0() {
    mul_ln1118_1072_fu_2774_p0 =  (sc_lv<16>) (sext_ln1118_742_fu_10322214_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1072_fu_2774_p2() {
    mul_ln1118_1072_fu_2774_p2 = (!mul_ln1118_1072_fu_2774_p0.read().is_01() || !ap_const_lv25_1FFFF58.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1072_fu_2774_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1073_fu_1984_p0() {
    mul_ln1118_1073_fu_1984_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1073_fu_1984_p2() {
    mul_ln1118_1073_fu_1984_p2 = (!mul_ln1118_1073_fu_1984_p0.read().is_01() || !ap_const_lv24_FFFF91.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1073_fu_1984_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1074_fu_3081_p0() {
    mul_ln1118_1074_fu_3081_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1074_fu_3081_p2() {
    mul_ln1118_1074_fu_3081_p2 = (!mul_ln1118_1074_fu_3081_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1074_fu_3081_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1075_fu_3549_p0() {
    mul_ln1118_1075_fu_3549_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1075_fu_3549_p2() {
    mul_ln1118_1075_fu_3549_p2 = (!mul_ln1118_1075_fu_3549_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1075_fu_3549_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1076_fu_2130_p0() {
    mul_ln1118_1076_fu_2130_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1076_fu_2130_p2() {
    mul_ln1118_1076_fu_2130_p2 = (!mul_ln1118_1076_fu_2130_p0.read().is_01() || !ap_const_lv24_FFFFB7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1076_fu_2130_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1077_fu_2598_p0() {
    mul_ln1118_1077_fu_2598_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1077_fu_2598_p2() {
    mul_ln1118_1077_fu_2598_p2 = (!mul_ln1118_1077_fu_2598_p0.read().is_01() || !ap_const_lv24_75.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1077_fu_2598_p0.read()) * sc_biguint<24>(ap_const_lv24_75);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1078_fu_2437_p0() {
    mul_ln1118_1078_fu_2437_p0 =  (sc_lv<16>) (sext_ln1118_743_fu_10322225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1078_fu_2437_p2() {
    mul_ln1118_1078_fu_2437_p2 = (!mul_ln1118_1078_fu_2437_p0.read().is_01() || !ap_const_lv24_61.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1078_fu_2437_p0.read()) * sc_biguint<24>(ap_const_lv24_61);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1079_fu_3534_p0() {
    mul_ln1118_1079_fu_3534_p0 =  (sc_lv<16>) (sext_ln1118_746_fu_10322246_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1079_fu_3534_p2() {
    mul_ln1118_1079_fu_3534_p2 = (!mul_ln1118_1079_fu_3534_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1079_fu_3534_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1080_fu_2580_p0() {
    mul_ln1118_1080_fu_2580_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1080_fu_2580_p2() {
    mul_ln1118_1080_fu_2580_p2 = (!mul_ln1118_1080_fu_2580_p0.read().is_01() || !ap_const_lv25_1FFFF0E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1080_fu_2580_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1081_fu_3212_p0() {
    mul_ln1118_1081_fu_3212_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1081_fu_3212_p2() {
    mul_ln1118_1081_fu_3212_p2 = (!mul_ln1118_1081_fu_3212_p0.read().is_01() || !ap_const_lv24_46.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1081_fu_3212_p0.read()) * sc_biguint<24>(ap_const_lv24_46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1082_fu_2422_p0() {
    mul_ln1118_1082_fu_2422_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1082_fu_2422_p2() {
    mul_ln1118_1082_fu_2422_p2 = (!mul_ln1118_1082_fu_2422_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1082_fu_2422_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1083_fu_3487_p0() {
    mul_ln1118_1083_fu_3487_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1083_fu_3487_p2() {
    mul_ln1118_1083_fu_3487_p2 = (!mul_ln1118_1083_fu_3487_p0.read().is_01() || !ap_const_lv25_BD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1083_fu_3487_p0.read()) * sc_biguint<25>(ap_const_lv25_BD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1084_fu_2068_p0() {
    mul_ln1118_1084_fu_2068_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1084_fu_2068_p2() {
    mul_ln1118_1084_fu_2068_p2 = (!mul_ln1118_1084_fu_2068_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1084_fu_2068_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1085_fu_1907_p0() {
    mul_ln1118_1085_fu_1907_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1085_fu_1907_p2() {
    mul_ln1118_1085_fu_1907_p2 = (!mul_ln1118_1085_fu_1907_p0.read().is_01() || !ap_const_lv25_B3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1085_fu_1907_p0.read()) * sc_biguint<25>(ap_const_lv25_B3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1086_fu_2375_p0() {
    mul_ln1118_1086_fu_2375_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1086_fu_2375_p2() {
    mul_ln1118_1086_fu_2375_p2 = (!mul_ln1118_1086_fu_2375_p0.read().is_01() || !ap_const_lv25_1FFFF0A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1086_fu_2375_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1087_fu_3472_p0() {
    mul_ln1118_1087_fu_3472_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1087_fu_3472_p2() {
    mul_ln1118_1087_fu_3472_p2 = (!mul_ln1118_1087_fu_3472_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1087_fu_3472_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1088_fu_2682_p0() {
    mul_ln1118_1088_fu_2682_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1088_fu_2682_p2() {
    mul_ln1118_1088_fu_2682_p2 = (!mul_ln1118_1088_fu_2682_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1088_fu_2682_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1089_fu_2521_p0() {
    mul_ln1118_1089_fu_2521_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1089_fu_2521_p2() {
    mul_ln1118_1089_fu_2521_p2 = (!mul_ln1118_1089_fu_2521_p0.read().is_01() || !ap_const_lv25_93.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1089_fu_2521_p0.read()) * sc_biguint<25>(ap_const_lv25_93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1090_fu_2989_p0() {
    mul_ln1118_1090_fu_2989_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1090_fu_2989_p2() {
    mul_ln1118_1090_fu_2989_p2 = (!mul_ln1118_1090_fu_2989_p0.read().is_01() || !ap_const_lv24_FFFFB7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1090_fu_2989_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1091_fu_2828_p0() {
    mul_ln1118_1091_fu_2828_p0 = sext_ln1118_758_fu_10322837_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1091_fu_2828_p2() {
    mul_ln1118_1091_fu_2828_p2 = (!mul_ln1118_1091_fu_2828_p0.read().is_01() || !ap_const_lv22_3FFFEA.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1091_fu_2828_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1092_fu_2038_p0() {
    mul_ln1118_1092_fu_2038_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1092_fu_2038_p2() {
    mul_ln1118_1092_fu_2038_p2 = (!mul_ln1118_1092_fu_2038_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1092_fu_2038_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1093_fu_1877_p0() {
    mul_ln1118_1093_fu_1877_p0 = sext_ln1118_759_fu_10322842_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1093_fu_1877_p2() {
    mul_ln1118_1093_fu_1877_p2 = (!mul_ln1118_1093_fu_1877_p0.read().is_01() || !ap_const_lv23_7FFFD5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1093_fu_1877_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1094_fu_2974_p0() {
    mul_ln1118_1094_fu_2974_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1094_fu_2974_p2() {
    mul_ln1118_1094_fu_2974_p2 = (!mul_ln1118_1094_fu_2974_p0.read().is_01() || !ap_const_lv24_5B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1094_fu_2974_p0.read()) * sc_biguint<24>(ap_const_lv24_5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1095_fu_2184_p0() {
    mul_ln1118_1095_fu_2184_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1095_fu_2184_p2() {
    mul_ln1118_1095_fu_2184_p2 = (!mul_ln1118_1095_fu_2184_p0.read().is_01() || !ap_const_lv25_1FFFF4B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1095_fu_2184_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1096_fu_2023_p0() {
    mul_ln1118_1096_fu_2023_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1096_fu_2023_p2() {
    mul_ln1118_1096_fu_2023_p2 = (!mul_ln1118_1096_fu_2023_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1096_fu_2023_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1097_fu_2150_p0() {
    mul_ln1118_1097_fu_2150_p0 =  (sc_lv<16>) (sext_ln1118_755_fu_10322806_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1097_fu_2150_p2() {
    mul_ln1118_1097_fu_2150_p2 = (!mul_ln1118_1097_fu_2150_p0.read().is_01() || !ap_const_lv24_54.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1097_fu_2150_p0.read()) * sc_biguint<24>(ap_const_lv24_54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1098_fu_2552_p0() {
    mul_ln1118_1098_fu_2552_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1098_fu_2552_p2() {
    mul_ln1118_1098_fu_2552_p2 = (!mul_ln1118_1098_fu_2552_p0.read().is_01() || !ap_const_lv25_1FFFF74.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1098_fu_2552_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1099_fu_2642_p0() {
    mul_ln1118_1099_fu_2642_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1099_fu_2642_p2() {
    mul_ln1118_1099_fu_2642_p2 = (!mul_ln1118_1099_fu_2642_p0.read().is_01() || !ap_const_lv25_F2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1099_fu_2642_p0.read()) * sc_biguint<25>(ap_const_lv25_F2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1100_fu_2643_p0() {
    mul_ln1118_1100_fu_2643_p0 =  (sc_lv<16>) (sext_ln1118_756_fu_10322816_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1100_fu_2643_p2() {
    mul_ln1118_1100_fu_2643_p2 = (!mul_ln1118_1100_fu_2643_p0.read().is_01() || !ap_const_lv25_1FFFF22.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1100_fu_2643_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF22);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1101_fu_3134_p0() {
    mul_ln1118_1101_fu_3134_p0 =  (sc_lv<16>) (sext_ln1118_774_fu_10323440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1101_fu_3134_p2() {
    mul_ln1118_1101_fu_3134_p2 = (!mul_ln1118_1101_fu_3134_p0.read().is_01() || !ap_const_lv23_29.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1101_fu_3134_p0.read()) * sc_biguint<23>(ap_const_lv23_29);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1102_fu_3135_p0() {
    mul_ln1118_1102_fu_3135_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1102_fu_3135_p2() {
    mul_ln1118_1102_fu_3135_p2 = (!mul_ln1118_1102_fu_3135_p0.read().is_01() || !ap_const_lv25_1FFFF1E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1102_fu_3135_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1103_fu_2646_p0() {
    mul_ln1118_1103_fu_2646_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1103_fu_2646_p2() {
    mul_ln1118_1103_fu_2646_p2 = (!mul_ln1118_1103_fu_2646_p0.read().is_01() || !ap_const_lv25_D4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1103_fu_2646_p0.read()) * sc_biguint<25>(ap_const_lv25_D4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1104_fu_3137_p0() {
    mul_ln1118_1104_fu_3137_p0 =  (sc_lv<16>) (sext_ln1118_774_fu_10323440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1104_fu_3137_p2() {
    mul_ln1118_1104_fu_3137_p2 = (!mul_ln1118_1104_fu_3137_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1104_fu_3137_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1105_fu_3138_p0() {
    mul_ln1118_1105_fu_3138_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1105_fu_3138_p2() {
    mul_ln1118_1105_fu_3138_p2 = (!mul_ln1118_1105_fu_3138_p0.read().is_01() || !ap_const_lv25_1FFFF45.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1105_fu_3138_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1106_fu_2159_p0() {
    mul_ln1118_1106_fu_2159_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1106_fu_2159_p2() {
    mul_ln1118_1106_fu_2159_p2 = (!mul_ln1118_1106_fu_2159_p0.read().is_01() || !ap_const_lv25_DC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1106_fu_2159_p0.read()) * sc_biguint<25>(ap_const_lv25_DC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1107_fu_2160_p0() {
    mul_ln1118_1107_fu_2160_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1107_fu_2160_p2() {
    mul_ln1118_1107_fu_2160_p2 = (!mul_ln1118_1107_fu_2160_p0.read().is_01() || !ap_const_lv24_53.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1107_fu_2160_p0.read()) * sc_biguint<24>(ap_const_lv24_53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1108_fu_3141_p0() {
    mul_ln1118_1108_fu_3141_p0 =  (sc_lv<16>) (sext_ln1118_774_fu_10323440_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1108_fu_3141_p2() {
    mul_ln1118_1108_fu_3141_p2 = (!mul_ln1118_1108_fu_3141_p0.read().is_01() || !ap_const_lv23_26.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1108_fu_3141_p0.read()) * sc_biguint<23>(ap_const_lv23_26);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1109_fu_2162_p0() {
    mul_ln1118_1109_fu_2162_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1109_fu_2162_p2() {
    mul_ln1118_1109_fu_2162_p2 = (!mul_ln1118_1109_fu_2162_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1109_fu_2162_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1110_fu_2653_p0() {
    mul_ln1118_1110_fu_2653_p0 =  (sc_lv<16>) (sext_ln1118_775_fu_10323447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1110_fu_2653_p2() {
    mul_ln1118_1110_fu_2653_p2 = (!mul_ln1118_1110_fu_2653_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1110_fu_2653_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1111_fu_2654_p0() {
    mul_ln1118_1111_fu_2654_p0 =  (sc_lv<16>) (sext_ln1118_771_fu_10323409_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1111_fu_2654_p2() {
    mul_ln1118_1111_fu_2654_p2 = (!mul_ln1118_1111_fu_2654_p0.read().is_01() || !ap_const_lv26_11A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1111_fu_2654_p0.read()) * sc_biguint<26>(ap_const_lv26_11A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1112_fu_2655_p0() {
    mul_ln1118_1112_fu_2655_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1112_fu_2655_p2() {
    mul_ln1118_1112_fu_2655_p2 = (!mul_ln1118_1112_fu_2655_p0.read().is_01() || !ap_const_lv24_FFFFBA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1112_fu_2655_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1113_fu_2656_p0() {
    mul_ln1118_1113_fu_2656_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1113_fu_2656_p2() {
    mul_ln1118_1113_fu_2656_p2 = (!mul_ln1118_1113_fu_2656_p0.read().is_01() || !ap_const_lv24_71.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1113_fu_2656_p0.read()) * sc_biguint<24>(ap_const_lv24_71);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1114_fu_2657_p0() {
    mul_ln1118_1114_fu_2657_p0 =  (sc_lv<16>) (sext_ln1118_775_fu_10323447_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1114_fu_2657_p2() {
    mul_ln1118_1114_fu_2657_p2 = (!mul_ln1118_1114_fu_2657_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1114_fu_2657_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1115_fu_2658_p0() {
    mul_ln1118_1115_fu_2658_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1115_fu_2658_p2() {
    mul_ln1118_1115_fu_2658_p2 = (!mul_ln1118_1115_fu_2658_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1115_fu_2658_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1116_fu_2659_p0() {
    mul_ln1118_1116_fu_2659_p0 =  (sc_lv<16>) (sext_ln1118_771_fu_10323409_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1116_fu_2659_p2() {
    mul_ln1118_1116_fu_2659_p2 = (!mul_ln1118_1116_fu_2659_p0.read().is_01() || !ap_const_lv26_10D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1116_fu_2659_p0.read()) * sc_biguint<26>(ap_const_lv26_10D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1117_fu_2660_p0() {
    mul_ln1118_1117_fu_2660_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1117_fu_2660_p2() {
    mul_ln1118_1117_fu_2660_p2 = (!mul_ln1118_1117_fu_2660_p0.read().is_01() || !ap_const_lv25_1FFFF53.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1117_fu_2660_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1118_fu_3641_p0() {
    mul_ln1118_1118_fu_3641_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1118_fu_3641_p2() {
    mul_ln1118_1118_fu_3641_p2 = (!mul_ln1118_1118_fu_3641_p0.read().is_01() || !ap_const_lv25_BD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1118_fu_3641_p0.read()) * sc_biguint<25>(ap_const_lv25_BD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1119_fu_2662_p0() {
    mul_ln1118_1119_fu_2662_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1119_fu_2662_p2() {
    mul_ln1118_1119_fu_2662_p2 = (!mul_ln1118_1119_fu_2662_p0.read().is_01() || !ap_const_lv25_1FFFF4D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1119_fu_2662_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1120_fu_2663_p0() {
    mul_ln1118_1120_fu_2663_p0 =  (sc_lv<16>) (sext_ln1118_773_fu_10323427_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1120_fu_2663_p2() {
    mul_ln1118_1120_fu_2663_p2 = (!mul_ln1118_1120_fu_2663_p0.read().is_01() || !ap_const_lv25_E5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1120_fu_2663_p0.read()) * sc_biguint<25>(ap_const_lv25_E5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1121_fu_2664_p0() {
    mul_ln1118_1121_fu_2664_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1121_fu_2664_p2() {
    mul_ln1118_1121_fu_2664_p2 = (!mul_ln1118_1121_fu_2664_p0.read().is_01() || !ap_const_lv24_FFFF92.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1121_fu_2664_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF92);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1122_fu_2175_p0() {
    mul_ln1118_1122_fu_2175_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1122_fu_2175_p2() {
    mul_ln1118_1122_fu_2175_p2 = (!mul_ln1118_1122_fu_2175_p0.read().is_01() || !ap_const_lv24_61.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1122_fu_2175_p0.read()) * sc_biguint<24>(ap_const_lv24_61);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1123_fu_2666_p0() {
    mul_ln1118_1123_fu_2666_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1123_fu_2666_p2() {
    mul_ln1118_1123_fu_2666_p2 = (!mul_ln1118_1123_fu_2666_p0.read().is_01() || !ap_const_lv24_FFFFA3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1123_fu_2666_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1124_fu_3132_p0() {
    mul_ln1118_1124_fu_3132_p0 =  (sc_lv<16>) (sext_ln1118_772_fu_10323415_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1124_fu_3132_p2() {
    mul_ln1118_1124_fu_3132_p2 = (!mul_ln1118_1124_fu_3132_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1124_fu_3132_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1125_fu_2120_p0() {
    mul_ln1118_1125_fu_2120_p0 =  (sc_lv<16>) (sext_ln1118_787_fu_10324022_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1125_fu_2120_p2() {
    mul_ln1118_1125_fu_2120_p2 = (!mul_ln1118_1125_fu_2120_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1125_fu_2120_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1126_fu_2588_p0() {
    mul_ln1118_1126_fu_2588_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1126_fu_2588_p2() {
    mul_ln1118_1126_fu_2588_p2 = (!mul_ln1118_1126_fu_2588_p0.read().is_01() || !ap_const_lv26_3FFFEBB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1126_fu_2588_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1127_fu_3056_p0() {
    mul_ln1118_1127_fu_3056_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1127_fu_3056_p2() {
    mul_ln1118_1127_fu_3056_p2 = (!mul_ln1118_1127_fu_3056_p0.read().is_01() || !ap_const_lv25_FB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1127_fu_3056_p0.read()) * sc_biguint<25>(ap_const_lv25_FB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1128_fu_2266_p0() {
    mul_ln1118_1128_fu_2266_p0 =  (sc_lv<16>) (sext_ln1118_787_fu_10324022_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1128_fu_2266_p2() {
    mul_ln1118_1128_fu_2266_p2 = (!mul_ln1118_1128_fu_2266_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1128_fu_2266_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1129_fu_2734_p0() {
    mul_ln1118_1129_fu_2734_p0 =  (sc_lv<16>) (sext_ln1118_784_fu_10323987_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1129_fu_2734_p2() {
    mul_ln1118_1129_fu_2734_p2 = (!mul_ln1118_1129_fu_2734_p0.read().is_01() || !ap_const_lv24_FFFFA2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1129_fu_2734_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1130_fu_1944_p0() {
    mul_ln1118_1130_fu_1944_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1130_fu_1944_p2() {
    mul_ln1118_1130_fu_1944_p2 = (!mul_ln1118_1130_fu_1944_p0.read().is_01() || !ap_const_lv26_3FFFDF9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1130_fu_1944_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDF9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1131_fu_3670_p0() {
    mul_ln1118_1131_fu_3670_p0 =  (sc_lv<16>) (sext_ln1118_784_fu_10323987_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1131_fu_3670_p2() {
    mul_ln1118_1131_fu_3670_p2 = (!mul_ln1118_1131_fu_3670_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1131_fu_3670_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1132_fu_2880_p0() {
    mul_ln1118_1132_fu_2880_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1132_fu_2880_p2() {
    mul_ln1118_1132_fu_2880_p2 = (!mul_ln1118_1132_fu_2880_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1132_fu_2880_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1133_fu_3348_p0() {
    mul_ln1118_1133_fu_3348_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1133_fu_3348_p2() {
    mul_ln1118_1133_fu_3348_p2 = (!mul_ln1118_1133_fu_3348_p0.read().is_01() || !ap_const_lv26_3FFFED3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1133_fu_3348_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1134_fu_3187_p0() {
    mul_ln1118_1134_fu_3187_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1134_fu_3187_p2() {
    mul_ln1118_1134_fu_3187_p2 = (!mul_ln1118_1134_fu_3187_p0.read().is_01() || !ap_const_lv25_1FFFF62.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1134_fu_3187_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1135_fu_2397_p0() {
    mul_ln1118_1135_fu_2397_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1135_fu_2397_p2() {
    mul_ln1118_1135_fu_2397_p2 = (!mul_ln1118_1135_fu_2397_p0.read().is_01() || !ap_const_lv25_1FFFF42.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1135_fu_2397_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF42);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1136_fu_2154_p0() {
    mul_ln1118_1136_fu_2154_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1136_fu_2154_p2() {
    mul_ln1118_1136_fu_2154_p2 = (!mul_ln1118_1136_fu_2154_p0.read().is_01() || !ap_const_lv26_3FFFEE4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1136_fu_2154_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1137_fu_2075_p0() {
    mul_ln1118_1137_fu_2075_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1137_fu_2075_p2() {
    mul_ln1118_1137_fu_2075_p2 = (!mul_ln1118_1137_fu_2075_p0.read().is_01() || !ap_const_lv25_B3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1137_fu_2075_p0.read()) * sc_biguint<25>(ap_const_lv25_B3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1138_fu_2148_p0() {
    mul_ln1118_1138_fu_2148_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1138_fu_2148_p2() {
    mul_ln1118_1138_fu_2148_p2 = (!mul_ln1118_1138_fu_2148_p0.read().is_01() || !ap_const_lv25_1FFFF65.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1138_fu_2148_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1139_fu_3245_p0() {
    mul_ln1118_1139_fu_3245_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1139_fu_3245_p2() {
    mul_ln1118_1139_fu_3245_p2 = (!mul_ln1118_1139_fu_3245_p0.read().is_01() || !ap_const_lv25_BA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1139_fu_3245_p0.read()) * sc_biguint<25>(ap_const_lv25_BA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1140_fu_2455_p0() {
    mul_ln1118_1140_fu_2455_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1140_fu_2455_p2() {
    mul_ln1118_1140_fu_2455_p2 = (!mul_ln1118_1140_fu_2455_p0.read().is_01() || !ap_const_lv25_8E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1140_fu_2455_p0.read()) * sc_biguint<25>(ap_const_lv25_8E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1141_fu_1665_p0() {
    mul_ln1118_1141_fu_1665_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1141_fu_1665_p2() {
    mul_ln1118_1141_fu_1665_p2 = (!mul_ln1118_1141_fu_1665_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1141_fu_1665_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1142_fu_3391_p0() {
    mul_ln1118_1142_fu_3391_p0 = sext_ln1118_782_fu_10323977_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1142_fu_3391_p2() {
    mul_ln1118_1142_fu_3391_p2 = (!mul_ln1118_1142_fu_3391_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1142_fu_3391_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1143_fu_2744_p0() {
    mul_ln1118_1143_fu_2744_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1143_fu_2744_p2() {
    mul_ln1118_1143_fu_2744_p2 = (!mul_ln1118_1143_fu_2744_p0.read().is_01() || !ap_const_lv26_3FFFEC1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1143_fu_2744_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1144_fu_3069_p0() {
    mul_ln1118_1144_fu_3069_p0 =  (sc_lv<16>) (sext_ln1118_784_fu_10323987_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1144_fu_3069_p2() {
    mul_ln1118_1144_fu_3069_p2 = (!mul_ln1118_1144_fu_3069_p0.read().is_01() || !ap_const_lv24_5A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1144_fu_3069_p0.read()) * sc_biguint<24>(ap_const_lv24_5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1145_fu_2908_p0() {
    mul_ln1118_1145_fu_2908_p0 =  (sc_lv<16>) (sext_ln1118_783_fu_10323982_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1145_fu_2908_p2() {
    mul_ln1118_1145_fu_2908_p2 = (!mul_ln1118_1145_fu_2908_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1145_fu_2908_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1146_fu_2747_p0() {
    mul_ln1118_1146_fu_2747_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1146_fu_2747_p2() {
    mul_ln1118_1146_fu_2747_p2 = (!mul_ln1118_1146_fu_2747_p0.read().is_01() || !ap_const_lv25_B9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1146_fu_2747_p0.read()) * sc_biguint<25>(ap_const_lv25_B9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1147_fu_2729_p0() {
    mul_ln1118_1147_fu_2729_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1147_fu_2729_p2() {
    mul_ln1118_1147_fu_2729_p2 = (!mul_ln1118_1147_fu_2729_p0.read().is_01() || !ap_const_lv25_93.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1147_fu_2729_p0.read()) * sc_biguint<25>(ap_const_lv25_93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1148_fu_2425_p0() {
    mul_ln1118_1148_fu_2425_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1148_fu_2425_p2() {
    mul_ln1118_1148_fu_2425_p2 = (!mul_ln1118_1148_fu_2425_p0.read().is_01() || !ap_const_lv25_C5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1148_fu_2425_p0.read()) * sc_biguint<25>(ap_const_lv25_C5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1149_fu_2386_p0() {
    mul_ln1118_1149_fu_2386_p0 =  (sc_lv<16>) (sext_ln1118_785_fu_10323994_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1149_fu_2386_p2() {
    mul_ln1118_1149_fu_2386_p2 = (!mul_ln1118_1149_fu_2386_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1149_fu_2386_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1150_fu_2103_p0() {
    mul_ln1118_1150_fu_2103_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1150_fu_2103_p2() {
    mul_ln1118_1150_fu_2103_p2 = (!mul_ln1118_1150_fu_2103_p0.read().is_01() || !ap_const_lv26_14D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1150_fu_2103_p0.read()) * sc_biguint<26>(ap_const_lv26_14D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1151_fu_3200_p0() {
    mul_ln1118_1151_fu_3200_p0 =  (sc_lv<16>) (sext_ln1118_786_fu_10324011_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1151_fu_3200_p2() {
    mul_ln1118_1151_fu_3200_p2 = (!mul_ln1118_1151_fu_3200_p0.read().is_01() || !ap_const_lv26_3FFFEA4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1151_fu_3200_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1152_fu_3233_p0() {
    mul_ln1118_1152_fu_3233_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1152_fu_3233_p2() {
    mul_ln1118_1152_fu_3233_p2 = (!mul_ln1118_1152_fu_3233_p0.read().is_01() || !ap_const_lv24_69.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1152_fu_3233_p0.read()) * sc_biguint<24>(ap_const_lv24_69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1153_fu_3316_p0() {
    mul_ln1118_1153_fu_3316_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1153_fu_3316_p2() {
    mul_ln1118_1153_fu_3316_p2 = (!mul_ln1118_1153_fu_3316_p0.read().is_01() || !ap_const_lv25_1FFFF6E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1153_fu_3316_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1154_fu_2738_p0() {
    mul_ln1118_1154_fu_2738_p0 = sext_ln1118_791_fu_10324480_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1154_fu_2738_p2() {
    mul_ln1118_1154_fu_2738_p2 = (!mul_ln1118_1154_fu_2738_p0.read().is_01() || !ap_const_lv26_114.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1154_fu_2738_p0.read()) * sc_biguint<26>(ap_const_lv26_114);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1155_fu_2249_p0() {
    mul_ln1118_1155_fu_2249_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1155_fu_2249_p2() {
    mul_ln1118_1155_fu_2249_p2 = (!mul_ln1118_1155_fu_2249_p0.read().is_01() || !ap_const_lv25_CA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1155_fu_2249_p0.read()) * sc_biguint<25>(ap_const_lv25_CA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1156_fu_1760_p0() {
    mul_ln1118_1156_fu_1760_p0 = sext_ln1118_794_fu_10324508_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1156_fu_1760_p2() {
    mul_ln1118_1156_fu_1760_p2 = (!mul_ln1118_1156_fu_1760_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1156_fu_1760_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1157_fu_1761_p0() {
    mul_ln1118_1157_fu_1761_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1157_fu_1761_p2() {
    mul_ln1118_1157_fu_1761_p2 = (!mul_ln1118_1157_fu_1761_p0.read().is_01() || !ap_const_lv24_FFFF8D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1157_fu_1761_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1158_fu_1762_p0() {
    mul_ln1118_1158_fu_1762_p0 =  (sc_lv<16>) (sext_ln1118_795_fu_10324513_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1158_fu_1762_p2() {
    mul_ln1118_1158_fu_1762_p2 = (!mul_ln1118_1158_fu_1762_p0.read().is_01() || !ap_const_lv23_29.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1158_fu_1762_p0.read()) * sc_biguint<23>(ap_const_lv23_29);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1159_fu_1763_p0() {
    mul_ln1118_1159_fu_1763_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1159_fu_1763_p2() {
    mul_ln1118_1159_fu_1763_p2 = (!mul_ln1118_1159_fu_1763_p0.read().is_01() || !ap_const_lv24_FFFFA6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1159_fu_1763_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1160_fu_2254_p0() {
    mul_ln1118_1160_fu_2254_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1160_fu_2254_p2() {
    mul_ln1118_1160_fu_2254_p2 = (!mul_ln1118_1160_fu_2254_p0.read().is_01() || !ap_const_lv24_63.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1160_fu_2254_p0.read()) * sc_biguint<24>(ap_const_lv24_63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1161_fu_1765_p0() {
    mul_ln1118_1161_fu_1765_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1161_fu_1765_p2() {
    mul_ln1118_1161_fu_1765_p2 = (!mul_ln1118_1161_fu_1765_p0.read().is_01() || !ap_const_lv25_C4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1161_fu_1765_p0.read()) * sc_biguint<25>(ap_const_lv25_C4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1162_fu_1766_p0() {
    mul_ln1118_1162_fu_1766_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1162_fu_1766_p2() {
    mul_ln1118_1162_fu_1766_p2 = (!mul_ln1118_1162_fu_1766_p0.read().is_01() || !ap_const_lv25_1FFFF74.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1162_fu_1766_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1163_fu_1767_p0() {
    mul_ln1118_1163_fu_1767_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1163_fu_1767_p2() {
    mul_ln1118_1163_fu_1767_p2 = (!mul_ln1118_1163_fu_1767_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1163_fu_1767_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1164_fu_1768_p0() {
    mul_ln1118_1164_fu_1768_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1164_fu_1768_p2() {
    mul_ln1118_1164_fu_1768_p2 = (!mul_ln1118_1164_fu_1768_p0.read().is_01() || !ap_const_lv25_C5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1164_fu_1768_p0.read()) * sc_biguint<25>(ap_const_lv25_C5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1165_fu_1769_p0() {
    mul_ln1118_1165_fu_1769_p0 =  (sc_lv<16>) (sext_ln1118_795_fu_10324513_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1165_fu_1769_p2() {
    mul_ln1118_1165_fu_1769_p2 = (!mul_ln1118_1165_fu_1769_p0.read().is_01() || !ap_const_lv23_7FFFDD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1165_fu_1769_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1166_fu_1770_p0() {
    mul_ln1118_1166_fu_1770_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1166_fu_1770_p2() {
    mul_ln1118_1166_fu_1770_p2 = (!mul_ln1118_1166_fu_1770_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1166_fu_1770_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1167_fu_1771_p0() {
    mul_ln1118_1167_fu_1771_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1167_fu_1771_p2() {
    mul_ln1118_1167_fu_1771_p2 = (!mul_ln1118_1167_fu_1771_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1167_fu_1771_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1168_fu_1772_p0() {
    mul_ln1118_1168_fu_1772_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1168_fu_1772_p2() {
    mul_ln1118_1168_fu_1772_p2 = (!mul_ln1118_1168_fu_1772_p0.read().is_01() || !ap_const_lv24_74.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1168_fu_1772_p0.read()) * sc_biguint<24>(ap_const_lv24_74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1169_fu_2263_p0() {
    mul_ln1118_1169_fu_2263_p0 =  (sc_lv<16>) (sext_ln1118_793_fu_10324497_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1169_fu_2263_p2() {
    mul_ln1118_1169_fu_2263_p2 = (!mul_ln1118_1169_fu_2263_p0.read().is_01() || !ap_const_lv24_FFFF95.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1169_fu_2263_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1170_fu_2264_p0() {
    mul_ln1118_1170_fu_2264_p0 =  (sc_lv<16>) (sext_ln1118_792_fu_10324485_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1170_fu_2264_p2() {
    mul_ln1118_1170_fu_2264_p2 = (!mul_ln1118_1170_fu_2264_p0.read().is_01() || !ap_const_lv25_D8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1170_fu_2264_p0.read()) * sc_biguint<25>(ap_const_lv25_D8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1171_fu_1775_p0() {
    mul_ln1118_1171_fu_1775_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1171_fu_1775_p2() {
    mul_ln1118_1171_fu_1775_p2 = (!mul_ln1118_1171_fu_1775_p0.read().is_01() || !ap_const_lv24_FFFF83.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1171_fu_1775_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1172_fu_1776_p0() {
    mul_ln1118_1172_fu_1776_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1172_fu_1776_p2() {
    mul_ln1118_1172_fu_1776_p2 = (!mul_ln1118_1172_fu_1776_p0.read().is_01() || !ap_const_lv24_79.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1172_fu_1776_p0.read()) * sc_biguint<24>(ap_const_lv24_79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1173_fu_3336_p0() {
    mul_ln1118_1173_fu_3336_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1173_fu_3336_p2() {
    mul_ln1118_1173_fu_3336_p2 = (!mul_ln1118_1173_fu_3336_p0.read().is_01() || !ap_const_lv24_53.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1173_fu_3336_p0.read()) * sc_biguint<24>(ap_const_lv24_53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1174_fu_2268_p0() {
    mul_ln1118_1174_fu_2268_p0 =  (sc_lv<16>) (sext_ln1118_811_fu_10325108_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1174_fu_2268_p2() {
    mul_ln1118_1174_fu_2268_p2 = (!mul_ln1118_1174_fu_2268_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1174_fu_2268_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1175_fu_2269_p0() {
    mul_ln1118_1175_fu_2269_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1175_fu_2269_p2() {
    mul_ln1118_1175_fu_2269_p2 = (!mul_ln1118_1175_fu_2269_p0.read().is_01() || !ap_const_lv24_FFFFA9.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1175_fu_2269_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1176_fu_1780_p0() {
    mul_ln1118_1176_fu_1780_p0 =  (sc_lv<16>) (sext_ln1118_811_fu_10325108_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1176_fu_1780_p2() {
    mul_ln1118_1176_fu_1780_p2 = (!mul_ln1118_1176_fu_1780_p0.read().is_01() || !ap_const_lv23_2B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1176_fu_1780_p0.read()) * sc_biguint<23>(ap_const_lv23_2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1177_fu_1781_p0() {
    mul_ln1118_1177_fu_1781_p0 = sext_ln1118_812_fu_10325115_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1177_fu_1781_p2() {
    mul_ln1118_1177_fu_1781_p2 = (!mul_ln1118_1177_fu_1781_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1177_fu_1781_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1178_fu_1782_p0() {
    mul_ln1118_1178_fu_1782_p0 =  (sc_lv<16>) (sext_ln1118_811_fu_10325108_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1178_fu_1782_p2() {
    mul_ln1118_1178_fu_1782_p2 = (!mul_ln1118_1178_fu_1782_p0.read().is_01() || !ap_const_lv23_36.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1178_fu_1782_p0.read()) * sc_biguint<23>(ap_const_lv23_36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1179_fu_1783_p0() {
    mul_ln1118_1179_fu_1783_p0 =  (sc_lv<16>) (sext_ln1118_809_fu_10325095_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1179_fu_1783_p2() {
    mul_ln1118_1179_fu_1783_p2 = (!mul_ln1118_1179_fu_1783_p0.read().is_01() || !ap_const_lv25_BD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1179_fu_1783_p0.read()) * sc_biguint<25>(ap_const_lv25_BD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1180_fu_3660_p0() {
    mul_ln1118_1180_fu_3660_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1180_fu_3660_p2() {
    mul_ln1118_1180_fu_3660_p2 = (!mul_ln1118_1180_fu_3660_p0.read().is_01() || !ap_const_lv24_FFFF98.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1180_fu_3660_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1181_fu_1660_p0() {
    mul_ln1118_1181_fu_1660_p0 =  (sc_lv<16>) (sext_ln1118_808_fu_10325089_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1181_fu_1660_p2() {
    mul_ln1118_1181_fu_1660_p2 = (!mul_ln1118_1181_fu_1660_p0.read().is_01() || !ap_const_lv26_3FFFEF4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1181_fu_1660_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1182_fu_1742_p0() {
    mul_ln1118_1182_fu_1742_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1182_fu_1742_p2() {
    mul_ln1118_1182_fu_1742_p2 = (!mul_ln1118_1182_fu_1742_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1182_fu_1742_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1183_fu_3177_p0() {
    mul_ln1118_1183_fu_3177_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1183_fu_3177_p2() {
    mul_ln1118_1183_fu_3177_p2 = (!mul_ln1118_1183_fu_3177_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1183_fu_3177_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1184_fu_2387_p0() {
    mul_ln1118_1184_fu_2387_p0 =  (sc_lv<16>) (sext_ln1118_809_fu_10325095_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1184_fu_2387_p2() {
    mul_ln1118_1184_fu_2387_p2 = (!mul_ln1118_1184_fu_2387_p0.read().is_01() || !ap_const_lv25_D1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1184_fu_2387_p0.read()) * sc_biguint<25>(ap_const_lv25_D1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1185_fu_3484_p0() {
    mul_ln1118_1185_fu_3484_p0 =  (sc_lv<16>) (sext_ln1118_808_fu_10325089_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1185_fu_3484_p2() {
    mul_ln1118_1185_fu_3484_p2 = (!mul_ln1118_1185_fu_3484_p0.read().is_01() || !ap_const_lv26_118.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1185_fu_3484_p0.read()) * sc_biguint<26>(ap_const_lv26_118);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1186_fu_3323_p0() {
    mul_ln1118_1186_fu_3323_p0 =  (sc_lv<16>) (sext_ln1118_809_fu_10325095_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1186_fu_3323_p2() {
    mul_ln1118_1186_fu_3323_p2 = (!mul_ln1118_1186_fu_3323_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1186_fu_3323_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1187_fu_1904_p0() {
    mul_ln1118_1187_fu_1904_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1187_fu_1904_p2() {
    mul_ln1118_1187_fu_1904_p2 = (!mul_ln1118_1187_fu_1904_p0.read().is_01() || !ap_const_lv24_62.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1187_fu_1904_p0.read()) * sc_biguint<24>(ap_const_lv24_62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1188_fu_3001_p0() {
    mul_ln1118_1188_fu_3001_p0 =  (sc_lv<16>) (sext_ln1118_814_fu_10325124_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1188_fu_3001_p2() {
    mul_ln1118_1188_fu_3001_p2 = (!mul_ln1118_1188_fu_3001_p0.read().is_01() || !ap_const_lv24_73.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1188_fu_3001_p0.read()) * sc_biguint<24>(ap_const_lv24_73);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1189_fu_3469_p0() {
    mul_ln1118_1189_fu_3469_p0 =  (sc_lv<16>) (sext_ln1118_809_fu_10325095_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1189_fu_3469_p2() {
    mul_ln1118_1189_fu_3469_p2 = (!mul_ln1118_1189_fu_3469_p0.read().is_01() || !ap_const_lv25_1FFFF5A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1189_fu_3469_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1190_fu_2050_p0() {
    mul_ln1118_1190_fu_2050_p0 =  (sc_lv<16>) (sext_ln1118_809_fu_10325095_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1190_fu_2050_p2() {
    mul_ln1118_1190_fu_2050_p2 = (!mul_ln1118_1190_fu_2050_p0.read().is_01() || !ap_const_lv25_1FFFF5B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1190_fu_2050_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1191_fu_3147_p0() {
    mul_ln1118_1191_fu_3147_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1191_fu_3147_p2() {
    mul_ln1118_1191_fu_3147_p2 = (!mul_ln1118_1191_fu_3147_p0.read().is_01() || !ap_const_lv25_1FFFF5C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1191_fu_3147_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1192_fu_2357_p0() {
    mul_ln1118_1192_fu_2357_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1192_fu_2357_p2() {
    mul_ln1118_1192_fu_2357_p2 = (!mul_ln1118_1192_fu_2357_p0.read().is_01() || !ap_const_lv25_1FFFF77.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1192_fu_2357_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1193_fu_3468_p0() {
    mul_ln1118_1193_fu_3468_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1193_fu_3468_p2() {
    mul_ln1118_1193_fu_3468_p2 = (!mul_ln1118_1193_fu_3468_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1193_fu_3468_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1194_fu_3307_p0() {
    mul_ln1118_1194_fu_3307_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1194_fu_3307_p2() {
    mul_ln1118_1194_fu_3307_p2 = (!mul_ln1118_1194_fu_3307_p0.read().is_01() || !ap_const_lv24_FFFFBB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1194_fu_3307_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1195_fu_2517_p0() {
    mul_ln1118_1195_fu_2517_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1195_fu_2517_p2() {
    mul_ln1118_1195_fu_2517_p2 = (!mul_ln1118_1195_fu_2517_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1195_fu_2517_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1196_fu_1727_p0() {
    mul_ln1118_1196_fu_1727_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1196_fu_1727_p2() {
    mul_ln1118_1196_fu_1727_p2 = (!mul_ln1118_1196_fu_1727_p0.read().is_01() || !ap_const_lv25_1FFFF2C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1196_fu_1727_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1197_fu_2824_p0() {
    mul_ln1118_1197_fu_2824_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1197_fu_2824_p2() {
    mul_ln1118_1197_fu_2824_p2 = (!mul_ln1118_1197_fu_2824_p0.read().is_01() || !ap_const_lv24_FFFFA1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1197_fu_2824_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1198_fu_3292_p0() {
    mul_ln1118_1198_fu_3292_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1198_fu_3292_p2() {
    mul_ln1118_1198_fu_3292_p2 = (!mul_ln1118_1198_fu_3292_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1198_fu_3292_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1199_fu_3131_p0() {
    mul_ln1118_1199_fu_3131_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1199_fu_3131_p2() {
    mul_ln1118_1199_fu_3131_p2 = (!mul_ln1118_1199_fu_3131_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1199_fu_3131_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1200_fu_2970_p0() {
    mul_ln1118_1200_fu_2970_p0 =  (sc_lv<16>) (sext_ln1118_832_fu_10325772_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1200_fu_2970_p2() {
    mul_ln1118_1200_fu_2970_p2 = (!mul_ln1118_1200_fu_2970_p0.read().is_01() || !ap_const_lv22_3FFFE7.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1200_fu_2970_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1201_fu_3438_p0() {
    mul_ln1118_1201_fu_3438_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1201_fu_3438_p2() {
    mul_ln1118_1201_fu_3438_p2 = (!mul_ln1118_1201_fu_3438_p0.read().is_01() || !ap_const_lv25_EC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1201_fu_3438_p0.read()) * sc_biguint<25>(ap_const_lv25_EC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1202_fu_2648_p0() {
    mul_ln1118_1202_fu_2648_p0 =  (sc_lv<16>) (sext_ln1118_832_fu_10325772_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1202_fu_2648_p2() {
    mul_ln1118_1202_fu_2648_p2 = (!mul_ln1118_1202_fu_2648_p0.read().is_01() || !ap_const_lv22_3FFFE6.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1202_fu_2648_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1203_fu_1858_p0() {
    mul_ln1118_1203_fu_1858_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1203_fu_1858_p2() {
    mul_ln1118_1203_fu_1858_p2 = (!mul_ln1118_1203_fu_1858_p0.read().is_01() || !ap_const_lv25_A8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1203_fu_1858_p0.read()) * sc_biguint<25>(ap_const_lv25_A8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1204_fu_1697_p0() {
    mul_ln1118_1204_fu_1697_p0 = sext_ln1118_826_fu_10325729_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1204_fu_1697_p2() {
    mul_ln1118_1204_fu_1697_p2 = (!mul_ln1118_1204_fu_1697_p0.read().is_01() || !ap_const_lv26_121.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1204_fu_1697_p0.read()) * sc_biguint<26>(ap_const_lv26_121);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1205_fu_2165_p0() {
    mul_ln1118_1205_fu_2165_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1205_fu_2165_p2() {
    mul_ln1118_1205_fu_2165_p2 = (!mul_ln1118_1205_fu_2165_p0.read().is_01() || !ap_const_lv25_1FFFF35.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1205_fu_2165_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1206_fu_2633_p0() {
    mul_ln1118_1206_fu_2633_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1206_fu_2633_p2() {
    mul_ln1118_1206_fu_2633_p2 = (!mul_ln1118_1206_fu_2633_p0.read().is_01() || !ap_const_lv25_E2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1206_fu_2633_p0.read()) * sc_biguint<25>(ap_const_lv25_E2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1207_fu_3444_p0() {
    mul_ln1118_1207_fu_3444_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1207_fu_3444_p2() {
    mul_ln1118_1207_fu_3444_p2 = (!mul_ln1118_1207_fu_3444_p0.read().is_01() || !ap_const_lv24_76.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1207_fu_3444_p0.read()) * sc_biguint<24>(ap_const_lv24_76);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1208_fu_1853_p0() {
    mul_ln1118_1208_fu_1853_p0 =  (sc_lv<16>) (sext_ln1118_831_fu_10325766_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1208_fu_1853_p2() {
    mul_ln1118_1208_fu_1853_p2 = (!mul_ln1118_1208_fu_1853_p0.read().is_01() || !ap_const_lv23_7FFFDD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1208_fu_1853_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1209_fu_2923_p0() {
    mul_ln1118_1209_fu_2923_p0 =  (sc_lv<16>) (sext_ln1118_828_fu_10325744_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1209_fu_2923_p2() {
    mul_ln1118_1209_fu_2923_p2 = (!mul_ln1118_1209_fu_2923_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1209_fu_2923_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1210_fu_2924_p0() {
    mul_ln1118_1210_fu_2924_p0 =  (sc_lv<16>) (sext_ln1118_831_fu_10325766_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1210_fu_2924_p2() {
    mul_ln1118_1210_fu_2924_p2 = (!mul_ln1118_1210_fu_2924_p0.read().is_01() || !ap_const_lv23_25.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1210_fu_2924_p0.read()) * sc_biguint<23>(ap_const_lv23_25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1211_fu_2925_p0() {
    mul_ln1118_1211_fu_2925_p0 =  (sc_lv<16>) (sext_ln1118_827_fu_10325734_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1211_fu_2925_p2() {
    mul_ln1118_1211_fu_2925_p2 = (!mul_ln1118_1211_fu_2925_p0.read().is_01() || !ap_const_lv24_FFFF91.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1211_fu_2925_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1212_fu_3416_p0() {
    mul_ln1118_1212_fu_3416_p0 =  (sc_lv<16>) (sext_ln1118_847_fu_10326410_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1212_fu_3416_p2() {
    mul_ln1118_1212_fu_3416_p2 = (!mul_ln1118_1212_fu_3416_p0.read().is_01() || !ap_const_lv23_7FFFD2.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1212_fu_3416_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1213_fu_2927_p0() {
    mul_ln1118_1213_fu_2927_p0 =  (sc_lv<16>) (sext_ln1118_847_fu_10326410_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1213_fu_2927_p2() {
    mul_ln1118_1213_fu_2927_p2 = (!mul_ln1118_1213_fu_2927_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1213_fu_2927_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1214_fu_2928_p0() {
    mul_ln1118_1214_fu_2928_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1214_fu_2928_p2() {
    mul_ln1118_1214_fu_2928_p2 = (!mul_ln1118_1214_fu_2928_p0.read().is_01() || !ap_const_lv26_105.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1214_fu_2928_p0.read()) * sc_biguint<26>(ap_const_lv26_105);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1215_fu_2439_p0() {
    mul_ln1118_1215_fu_2439_p0 =  (sc_lv<16>) (sext_ln1118_845_fu_10326394_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1215_fu_2439_p2() {
    mul_ln1118_1215_fu_2439_p2 = (!mul_ln1118_1215_fu_2439_p0.read().is_01() || !ap_const_lv22_3FFFE7.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1215_fu_2439_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1216_fu_2930_p0() {
    mul_ln1118_1216_fu_2930_p0 =  (sc_lv<16>) (sext_ln1118_849_fu_10326421_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1216_fu_2930_p2() {
    mul_ln1118_1216_fu_2930_p2 = (!mul_ln1118_1216_fu_2930_p0.read().is_01() || !ap_const_lv24_4E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1216_fu_2930_p0.read()) * sc_biguint<24>(ap_const_lv24_4E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1217_fu_2931_p0() {
    mul_ln1118_1217_fu_2931_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1217_fu_2931_p2() {
    mul_ln1118_1217_fu_2931_p2 = (!mul_ln1118_1217_fu_2931_p0.read().is_01() || !ap_const_lv25_CA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1217_fu_2931_p0.read()) * sc_biguint<25>(ap_const_lv25_CA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1218_fu_2932_p0() {
    mul_ln1118_1218_fu_2932_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1218_fu_2932_p2() {
    mul_ln1118_1218_fu_2932_p2 = (!mul_ln1118_1218_fu_2932_p0.read().is_01() || !ap_const_lv26_3FFFE60.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1218_fu_2932_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE60);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1219_fu_2933_p0() {
    mul_ln1118_1219_fu_2933_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1219_fu_2933_p2() {
    mul_ln1118_1219_fu_2933_p2 = (!mul_ln1118_1219_fu_2933_p0.read().is_01() || !ap_const_lv26_3FFFE9B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1219_fu_2933_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1220_fu_3424_p0() {
    mul_ln1118_1220_fu_3424_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1220_fu_3424_p2() {
    mul_ln1118_1220_fu_3424_p2 = (!mul_ln1118_1220_fu_3424_p0.read().is_01() || !ap_const_lv25_1FFFF5A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1220_fu_3424_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1221_fu_2935_p0() {
    mul_ln1118_1221_fu_2935_p0 =  (sc_lv<16>) (sext_ln1118_849_fu_10326421_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1221_fu_2935_p2() {
    mul_ln1118_1221_fu_2935_p2 = (!mul_ln1118_1221_fu_2935_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1221_fu_2935_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1222_fu_2936_p0() {
    mul_ln1118_1222_fu_2936_p0 =  (sc_lv<16>) (sext_ln1118_849_fu_10326421_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1222_fu_2936_p2() {
    mul_ln1118_1222_fu_2936_p2 = (!mul_ln1118_1222_fu_2936_p0.read().is_01() || !ap_const_lv24_73.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1222_fu_2936_p0.read()) * sc_biguint<24>(ap_const_lv24_73);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1223_fu_2937_p0() {
    mul_ln1118_1223_fu_2937_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1223_fu_2937_p2() {
    mul_ln1118_1223_fu_2937_p2 = (!mul_ln1118_1223_fu_2937_p0.read().is_01() || !ap_const_lv25_1FFFF57.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1223_fu_2937_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1224_fu_2938_p0() {
    mul_ln1118_1224_fu_2938_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1224_fu_2938_p2() {
    mul_ln1118_1224_fu_2938_p2 = (!mul_ln1118_1224_fu_2938_p0.read().is_01() || !ap_const_lv26_3FFFE7B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1224_fu_2938_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE7B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1225_fu_2939_p0() {
    mul_ln1118_1225_fu_2939_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1225_fu_2939_p2() {
    mul_ln1118_1225_fu_2939_p2 = (!mul_ln1118_1225_fu_2939_p0.read().is_01() || !ap_const_lv25_BC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1225_fu_2939_p0.read()) * sc_biguint<25>(ap_const_lv25_BC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1226_fu_2940_p0() {
    mul_ln1118_1226_fu_2940_p0 =  (sc_lv<16>) (sext_ln1118_847_fu_10326410_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1226_fu_2940_p2() {
    mul_ln1118_1226_fu_2940_p2 = (!mul_ln1118_1226_fu_2940_p0.read().is_01() || !ap_const_lv23_25.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1226_fu_2940_p0.read()) * sc_biguint<23>(ap_const_lv23_25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1227_fu_3431_p0() {
    mul_ln1118_1227_fu_3431_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1227_fu_3431_p2() {
    mul_ln1118_1227_fu_3431_p2 = (!mul_ln1118_1227_fu_3431_p0.read().is_01() || !ap_const_lv25_1FFFF0C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1227_fu_3431_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1228_fu_2452_p0() {
    mul_ln1118_1228_fu_2452_p0 =  (sc_lv<16>) (sext_ln1118_849_fu_10326421_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1228_fu_2452_p2() {
    mul_ln1118_1228_fu_2452_p2 = (!mul_ln1118_1228_fu_2452_p0.read().is_01() || !ap_const_lv24_FFFF96.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1228_fu_2452_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1229_fu_2943_p0() {
    mul_ln1118_1229_fu_2943_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1229_fu_2943_p2() {
    mul_ln1118_1229_fu_2943_p2 = (!mul_ln1118_1229_fu_2943_p0.read().is_01() || !ap_const_lv25_A7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1229_fu_2943_p0.read()) * sc_biguint<25>(ap_const_lv25_A7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1230_fu_3434_p0() {
    mul_ln1118_1230_fu_3434_p0 =  (sc_lv<16>) (sext_ln1118_845_fu_10326394_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1230_fu_3434_p2() {
    mul_ln1118_1230_fu_3434_p2 = (!mul_ln1118_1230_fu_3434_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1230_fu_3434_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1231_fu_3435_p0() {
    mul_ln1118_1231_fu_3435_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1231_fu_3435_p2() {
    mul_ln1118_1231_fu_3435_p2 = (!mul_ln1118_1231_fu_3435_p0.read().is_01() || !ap_const_lv25_1FFFF1A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1231_fu_3435_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1232_fu_1788_p0() {
    mul_ln1118_1232_fu_1788_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1232_fu_1788_p2() {
    mul_ln1118_1232_fu_1788_p2 = (!mul_ln1118_1232_fu_1788_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1232_fu_1788_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1233_fu_3437_p0() {
    mul_ln1118_1233_fu_3437_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1233_fu_3437_p2() {
    mul_ln1118_1233_fu_3437_p2 = (!mul_ln1118_1233_fu_3437_p0.read().is_01() || !ap_const_lv25_1FFFF21.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1233_fu_3437_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF21);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1234_fu_2458_p0() {
    mul_ln1118_1234_fu_2458_p0 =  (sc_lv<16>) (sext_ln1118_849_fu_10326421_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1234_fu_2458_p2() {
    mul_ln1118_1234_fu_2458_p2 = (!mul_ln1118_1234_fu_2458_p0.read().is_01() || !ap_const_lv24_4A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1234_fu_2458_p0.read()) * sc_biguint<24>(ap_const_lv24_4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1235_fu_1880_p0() {
    mul_ln1118_1235_fu_1880_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1235_fu_1880_p2() {
    mul_ln1118_1235_fu_1880_p2 = (!mul_ln1118_1235_fu_1880_p0.read().is_01() || !ap_const_lv26_3FFFEDF.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1235_fu_1880_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1236_fu_3152_p0() {
    mul_ln1118_1236_fu_3152_p0 =  (sc_lv<16>) (sext_ln1118_846_fu_10326400_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1236_fu_3152_p2() {
    mul_ln1118_1236_fu_3152_p2 = (!mul_ln1118_1236_fu_3152_p0.read().is_01() || !ap_const_lv26_3FFFE8F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1236_fu_3152_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1237_fu_2362_p0() {
    mul_ln1118_1237_fu_2362_p0 =  (sc_lv<16>) (sext_ln1118_844_fu_10326380_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1237_fu_2362_p2() {
    mul_ln1118_1237_fu_2362_p2 = (!mul_ln1118_1237_fu_2362_p0.read().is_01() || !ap_const_lv25_98.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1237_fu_2362_p0.read()) * sc_biguint<25>(ap_const_lv25_98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1238_fu_2830_p0() {
    mul_ln1118_1238_fu_2830_p0 =  (sc_lv<16>) (sext_ln1118_857_fu_10326926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1238_fu_2830_p2() {
    mul_ln1118_1238_fu_2830_p2 = (!mul_ln1118_1238_fu_2830_p0.read().is_01() || !ap_const_lv25_1FFFF06.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1238_fu_2830_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF06);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1239_fu_2669_p0() {
    mul_ln1118_1239_fu_2669_p0 =  (sc_lv<16>) (sext_ln1118_858_fu_10326935_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1239_fu_2669_p2() {
    mul_ln1118_1239_fu_2669_p2 = (!mul_ln1118_1239_fu_2669_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1239_fu_2669_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1240_fu_2672_p0() {
    mul_ln1118_1240_fu_2672_p0 =  (sc_lv<16>) (sext_ln1118_858_fu_10326935_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1240_fu_2672_p2() {
    mul_ln1118_1240_fu_2672_p2 = (!mul_ln1118_1240_fu_2672_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1240_fu_2672_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1241_fu_3605_p0() {
    mul_ln1118_1241_fu_3605_p0 =  (sc_lv<16>) (sext_ln1118_857_fu_10326926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1241_fu_3605_p2() {
    mul_ln1118_1241_fu_3605_p2 = (!mul_ln1118_1241_fu_3605_p0.read().is_01() || !ap_const_lv25_1FFFF2C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1241_fu_3605_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1242_fu_2815_p0() {
    mul_ln1118_1242_fu_2815_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1242_fu_2815_p2() {
    mul_ln1118_1242_fu_2815_p2 = (!mul_ln1118_1242_fu_2815_p0.read().is_01() || !ap_const_lv24_FFFFA5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1242_fu_2815_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1243_fu_3283_p0() {
    mul_ln1118_1243_fu_3283_p0 =  (sc_lv<16>) (sext_ln1118_857_fu_10326926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1243_fu_3283_p2() {
    mul_ln1118_1243_fu_3283_p2 = (!mul_ln1118_1243_fu_3283_p0.read().is_01() || !ap_const_lv25_1FFFF30.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1243_fu_3283_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF30);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1244_fu_1864_p0() {
    mul_ln1118_1244_fu_1864_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1244_fu_1864_p2() {
    mul_ln1118_1244_fu_1864_p2 = (!mul_ln1118_1244_fu_1864_p0.read().is_01() || !ap_const_lv24_6C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1244_fu_1864_p0.read()) * sc_biguint<24>(ap_const_lv24_6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1245_fu_1703_p0() {
    mul_ln1118_1245_fu_1703_p0 =  (sc_lv<16>) (sext_ln1118_857_fu_10326926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1245_fu_1703_p2() {
    mul_ln1118_1245_fu_1703_p2 = (!mul_ln1118_1245_fu_1703_p0.read().is_01() || !ap_const_lv25_1FFFF3B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1245_fu_1703_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1246_fu_2718_p0() {
    mul_ln1118_1246_fu_2718_p0 =  (sc_lv<16>) (sext_ln1118_855_fu_10326908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1246_fu_2718_p2() {
    mul_ln1118_1246_fu_2718_p2 = (!mul_ln1118_1246_fu_2718_p0.read().is_01() || !ap_const_lv26_3FFFEBC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1246_fu_2718_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1247_fu_2639_p0() {
    mul_ln1118_1247_fu_2639_p0 =  (sc_lv<16>) (sext_ln1118_855_fu_10326908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1247_fu_2639_p2() {
    mul_ln1118_1247_fu_2639_p2 = (!mul_ln1118_1247_fu_2639_p0.read().is_01() || !ap_const_lv26_126.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1247_fu_2639_p0.read()) * sc_biguint<26>(ap_const_lv26_126);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1248_fu_2478_p0() {
    mul_ln1118_1248_fu_2478_p0 =  (sc_lv<16>) (sext_ln1118_857_fu_10326926_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1248_fu_2478_p2() {
    mul_ln1118_1248_fu_2478_p2 = (!mul_ln1118_1248_fu_2478_p0.read().is_01() || !ap_const_lv25_1FFFF5E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1248_fu_2478_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1249_fu_3226_p0() {
    mul_ln1118_1249_fu_3226_p0 =  (sc_lv<16>) (sext_ln1118_855_fu_10326908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1249_fu_3226_p2() {
    mul_ln1118_1249_fu_3226_p2 = (!mul_ln1118_1249_fu_3226_p0.read().is_01() || !ap_const_lv26_166.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1249_fu_3226_p0.read()) * sc_biguint<26>(ap_const_lv26_166);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1250_fu_2436_p0() {
    mul_ln1118_1250_fu_2436_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1250_fu_2436_p2() {
    mul_ln1118_1250_fu_2436_p2 = (!mul_ln1118_1250_fu_2436_p0.read().is_01() || !ap_const_lv24_4F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1250_fu_2436_p0.read()) * sc_biguint<24>(ap_const_lv24_4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1251_fu_1646_p0() {
    mul_ln1118_1251_fu_1646_p0 =  (sc_lv<16>) (sext_ln1118_858_fu_10326935_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1251_fu_1646_p2() {
    mul_ln1118_1251_fu_1646_p2 = (!mul_ln1118_1251_fu_1646_p0.read().is_01() || !ap_const_lv23_33.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1251_fu_1646_p0.read()) * sc_biguint<23>(ap_const_lv23_33);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1252_fu_2743_p0() {
    mul_ln1118_1252_fu_2743_p0 =  (sc_lv<16>) (sext_ln1118_858_fu_10326935_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1252_fu_2743_p2() {
    mul_ln1118_1252_fu_2743_p2 = (!mul_ln1118_1252_fu_2743_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1252_fu_2743_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1253_fu_1953_p0() {
    mul_ln1118_1253_fu_1953_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1253_fu_1953_p2() {
    mul_ln1118_1253_fu_1953_p2 = (!mul_ln1118_1253_fu_1953_p0.read().is_01() || !ap_const_lv24_5B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1253_fu_1953_p0.read()) * sc_biguint<24>(ap_const_lv24_5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1254_fu_2421_p0() {
    mul_ln1118_1254_fu_2421_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1254_fu_2421_p2() {
    mul_ln1118_1254_fu_2421_p2 = (!mul_ln1118_1254_fu_2421_p0.read().is_01() || !ap_const_lv24_FFFFA6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1254_fu_2421_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1255_fu_2260_p0() {
    mul_ln1118_1255_fu_2260_p0 =  (sc_lv<16>) (sext_ln1118_855_fu_10326908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1255_fu_2260_p2() {
    mul_ln1118_1255_fu_2260_p2 = (!mul_ln1118_1255_fu_2260_p0.read().is_01() || !ap_const_lv26_3FFFED8.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1255_fu_2260_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1256_fu_3357_p0() {
    mul_ln1118_1256_fu_3357_p0 =  (sc_lv<16>) (sext_ln1118_856_fu_10326916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1256_fu_3357_p2() {
    mul_ln1118_1256_fu_3357_p2 = (!mul_ln1118_1256_fu_3357_p0.read().is_01() || !ap_const_lv24_FFFF98.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1256_fu_3357_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1257_fu_1938_p0() {
    mul_ln1118_1257_fu_1938_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1257_fu_1938_p2() {
    mul_ln1118_1257_fu_1938_p2 = (!mul_ln1118_1257_fu_1938_p0.read().is_01() || !ap_const_lv25_B1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1257_fu_1938_p0.read()) * sc_biguint<25>(ap_const_lv25_B1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1258_fu_3035_p0() {
    mul_ln1118_1258_fu_3035_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1258_fu_3035_p2() {
    mul_ln1118_1258_fu_3035_p2 = (!mul_ln1118_1258_fu_3035_p0.read().is_01() || !ap_const_lv25_CF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1258_fu_3035_p0.read()) * sc_biguint<25>(ap_const_lv25_CF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1259_fu_3503_p0() {
    mul_ln1118_1259_fu_3503_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1259_fu_3503_p2() {
    mul_ln1118_1259_fu_3503_p2 = (!mul_ln1118_1259_fu_3503_p0.read().is_01() || !ap_const_lv24_FFFF8B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1259_fu_3503_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1260_fu_1741_p0() {
    mul_ln1118_1260_fu_1741_p0 =  (sc_lv<16>) (sext_ln1118_870_fu_10327399_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1260_fu_1741_p2() {
    mul_ln1118_1260_fu_1741_p2 = (!mul_ln1118_1260_fu_1741_p0.read().is_01() || !ap_const_lv22_3FFFE9.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1260_fu_1741_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1261_fu_1923_p0() {
    mul_ln1118_1261_fu_1923_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1261_fu_1923_p2() {
    mul_ln1118_1261_fu_1923_p2 = (!mul_ln1118_1261_fu_1923_p0.read().is_01() || !ap_const_lv25_1FFFF17.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1261_fu_1923_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1262_fu_2391_p0() {
    mul_ln1118_1262_fu_2391_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1262_fu_2391_p2() {
    mul_ln1118_1262_fu_2391_p2 = (!mul_ln1118_1262_fu_2391_p0.read().is_01() || !ap_const_lv25_1FFFF4A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1262_fu_2391_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1263_fu_2528_p0() {
    mul_ln1118_1263_fu_2528_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1263_fu_2528_p2() {
    mul_ln1118_1263_fu_2528_p2 = (!mul_ln1118_1263_fu_2528_p0.read().is_01() || !ap_const_lv25_A4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1263_fu_2528_p0.read()) * sc_biguint<25>(ap_const_lv25_A4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1264_fu_2039_p0() {
    mul_ln1118_1264_fu_2039_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1264_fu_2039_p2() {
    mul_ln1118_1264_fu_2039_p2 = (!mul_ln1118_1264_fu_2039_p0.read().is_01() || !ap_const_lv25_C5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1264_fu_2039_p0.read()) * sc_biguint<25>(ap_const_lv25_C5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1265_fu_2040_p0() {
    mul_ln1118_1265_fu_2040_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1265_fu_2040_p2() {
    mul_ln1118_1265_fu_2040_p2 = (!mul_ln1118_1265_fu_2040_p0.read().is_01() || !ap_const_lv25_92.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1265_fu_2040_p0.read()) * sc_biguint<25>(ap_const_lv25_92);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1266_fu_3600_p0() {
    mul_ln1118_1266_fu_3600_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1266_fu_3600_p2() {
    mul_ln1118_1266_fu_3600_p2 = (!mul_ln1118_1266_fu_3600_p0.read().is_01() || !ap_const_lv25_1FFFF4F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1266_fu_3600_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1267_fu_2042_p0() {
    mul_ln1118_1267_fu_2042_p0 =  (sc_lv<16>) (sext_ln1118_869_fu_10327394_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1267_fu_2042_p2() {
    mul_ln1118_1267_fu_2042_p2 = (!mul_ln1118_1267_fu_2042_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1267_fu_2042_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1268_fu_2533_p0() {
    mul_ln1118_1268_fu_2533_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1268_fu_2533_p2() {
    mul_ln1118_1268_fu_2533_p2 = (!mul_ln1118_1268_fu_2533_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1268_fu_2533_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1269_fu_2044_p0() {
    mul_ln1118_1269_fu_2044_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1269_fu_2044_p2() {
    mul_ln1118_1269_fu_2044_p2 = (!mul_ln1118_1269_fu_2044_p0.read().is_01() || !ap_const_lv24_FFFF87.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1269_fu_2044_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1270_fu_2535_p0() {
    mul_ln1118_1270_fu_2535_p0 =  (sc_lv<16>) (sext_ln1118_866_fu_10327365_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1270_fu_2535_p2() {
    mul_ln1118_1270_fu_2535_p2 = (!mul_ln1118_1270_fu_2535_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1270_fu_2535_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1271_fu_2046_p0() {
    mul_ln1118_1271_fu_2046_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1271_fu_2046_p2() {
    mul_ln1118_1271_fu_2046_p2 = (!mul_ln1118_1271_fu_2046_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1271_fu_2046_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1272_fu_3606_p0() {
    mul_ln1118_1272_fu_3606_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1272_fu_3606_p2() {
    mul_ln1118_1272_fu_3606_p2 = (!mul_ln1118_1272_fu_3606_p0.read().is_01() || !ap_const_lv24_FFFF93.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1272_fu_3606_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1273_fu_3607_p0() {
    mul_ln1118_1273_fu_3607_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1273_fu_3607_p2() {
    mul_ln1118_1273_fu_3607_p2 = (!mul_ln1118_1273_fu_3607_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1273_fu_3607_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1274_fu_3029_p0() {
    mul_ln1118_1274_fu_3029_p0 =  (sc_lv<16>) (sext_ln1118_867_fu_10327370_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1274_fu_3029_p2() {
    mul_ln1118_1274_fu_3029_p2 = (!mul_ln1118_1274_fu_3029_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1274_fu_3029_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1275_fu_3520_p0() {
    mul_ln1118_1275_fu_3520_p0 =  (sc_lv<16>) (sext_ln1118_868_fu_10327381_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1275_fu_3520_p2() {
    mul_ln1118_1275_fu_3520_p2 = (!mul_ln1118_1275_fu_3520_p0.read().is_01() || !ap_const_lv25_1FFFF03.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1275_fu_3520_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF03);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1276_fu_2051_p0() {
    mul_ln1118_1276_fu_2051_p0 =  (sc_lv<16>) (sext_ln1118_881_fu_10327953_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1276_fu_2051_p2() {
    mul_ln1118_1276_fu_2051_p2 = (!mul_ln1118_1276_fu_2051_p0.read().is_01() || !ap_const_lv24_FFFFBD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1276_fu_2051_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1277_fu_2542_p0() {
    mul_ln1118_1277_fu_2542_p0 = sext_ln1118_882_fu_10327961_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1277_fu_2542_p2() {
    mul_ln1118_1277_fu_2542_p2 = (!mul_ln1118_1277_fu_2542_p0.read().is_01() || !ap_const_lv22_3FFFE7.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1277_fu_2542_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1278_fu_2053_p0() {
    mul_ln1118_1278_fu_2053_p0 = sext_ln1118_884_fu_10327970_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1278_fu_2053_p2() {
    mul_ln1118_1278_fu_2053_p2 = (!mul_ln1118_1278_fu_2053_p0.read().is_01() || !ap_const_lv23_7FFFD1.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1278_fu_2053_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1279_fu_2054_p0() {
    mul_ln1118_1279_fu_2054_p0 =  (sc_lv<16>) (sext_ln1118_881_fu_10327953_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1279_fu_2054_p2() {
    mul_ln1118_1279_fu_2054_p2 = (!mul_ln1118_1279_fu_2054_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1279_fu_2054_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1280_fu_2055_p0() {
    mul_ln1118_1280_fu_2055_p0 =  (sc_lv<16>) (sext_ln1118_880_fu_10327946_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1280_fu_2055_p2() {
    mul_ln1118_1280_fu_2055_p2 = (!mul_ln1118_1280_fu_2055_p0.read().is_01() || !ap_const_lv25_1FFFF39.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1280_fu_2055_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1281_fu_2056_p0() {
    mul_ln1118_1281_fu_2056_p0 =  (sc_lv<16>) (sext_ln1118_881_fu_10327953_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1281_fu_2056_p2() {
    mul_ln1118_1281_fu_2056_p2 = (!mul_ln1118_1281_fu_2056_p0.read().is_01() || !ap_const_lv24_FFFF94.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1281_fu_2056_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1282_fu_2547_p0() {
    mul_ln1118_1282_fu_2547_p0 =  (sc_lv<16>) (sext_ln1118_881_fu_10327953_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1282_fu_2547_p2() {
    mul_ln1118_1282_fu_2547_p2 = (!mul_ln1118_1282_fu_2547_p0.read().is_01() || !ap_const_lv24_FFFFB2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1282_fu_2547_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1283_fu_2548_p0() {
    mul_ln1118_1283_fu_2548_p0 =  (sc_lv<16>) (sext_ln1118_880_fu_10327946_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1283_fu_2548_p2() {
    mul_ln1118_1283_fu_2548_p2 = (!mul_ln1118_1283_fu_2548_p0.read().is_01() || !ap_const_lv25_D4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1283_fu_2548_p0.read()) * sc_biguint<25>(ap_const_lv25_D4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1284_fu_2549_p0() {
    mul_ln1118_1284_fu_2549_p0 =  (sc_lv<16>) (sext_ln1118_880_fu_10327946_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1284_fu_2549_p2() {
    mul_ln1118_1284_fu_2549_p2 = (!mul_ln1118_1284_fu_2549_p0.read().is_01() || !ap_const_lv25_BE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1284_fu_2549_p0.read()) * sc_biguint<25>(ap_const_lv25_BE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1285_fu_2060_p0() {
    mul_ln1118_1285_fu_2060_p0 = sext_ln1118_900_fu_10328481_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1285_fu_2060_p2() {
    mul_ln1118_1285_fu_2060_p2 = (!mul_ln1118_1285_fu_2060_p0.read().is_01() || !ap_const_lv21_1FFFF5.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1285_fu_2060_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1286_fu_2061_p0() {
    mul_ln1118_1286_fu_2061_p0 =  (sc_lv<16>) (sext_ln1118_899_fu_10328473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1286_fu_2061_p2() {
    mul_ln1118_1286_fu_2061_p2 = (!mul_ln1118_1286_fu_2061_p0.read().is_01() || !ap_const_lv26_3FFFEEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1286_fu_2061_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1287_fu_3621_p0() {
    mul_ln1118_1287_fu_3621_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1287_fu_3621_p2() {
    mul_ln1118_1287_fu_3621_p2 = (!mul_ln1118_1287_fu_3621_p0.read().is_01() || !ap_const_lv25_1FFFF0C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1287_fu_3621_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1288_fu_2553_p0() {
    mul_ln1118_1288_fu_2553_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1288_fu_2553_p2() {
    mul_ln1118_1288_fu_2553_p2 = (!mul_ln1118_1288_fu_2553_p0.read().is_01() || !ap_const_lv25_95.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1288_fu_2553_p0.read()) * sc_biguint<25>(ap_const_lv25_95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1289_fu_2064_p0() {
    mul_ln1118_1289_fu_2064_p0 =  (sc_lv<16>) (sext_ln1118_902_fu_10328490_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1289_fu_2064_p2() {
    mul_ln1118_1289_fu_2064_p2 = (!mul_ln1118_1289_fu_2064_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1289_fu_2064_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1290_fu_2065_p0() {
    mul_ln1118_1290_fu_2065_p0 =  (sc_lv<16>) (sext_ln1118_896_fu_10328453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1290_fu_2065_p2() {
    mul_ln1118_1290_fu_2065_p2 = (!mul_ln1118_1290_fu_2065_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1290_fu_2065_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1291_fu_2805_p0() {
    mul_ln1118_1291_fu_2805_p0 =  (sc_lv<16>) (sext_ln1118_902_fu_10328490_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1291_fu_2805_p2() {
    mul_ln1118_1291_fu_2805_p2 = (!mul_ln1118_1291_fu_2805_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1291_fu_2805_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1292_fu_2644_p0() {
    mul_ln1118_1292_fu_2644_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1292_fu_2644_p2() {
    mul_ln1118_1292_fu_2644_p2 = (!mul_ln1118_1292_fu_2644_p0.read().is_01() || !ap_const_lv25_1FFFF69.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1292_fu_2644_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1293_fu_3030_p0() {
    mul_ln1118_1293_fu_3030_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1293_fu_3030_p2() {
    mul_ln1118_1293_fu_3030_p2 = (!mul_ln1118_1293_fu_3030_p0.read().is_01() || !ap_const_lv25_1FFFF54.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1293_fu_3030_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1294_fu_1693_p0() {
    mul_ln1118_1294_fu_1693_p0 =  (sc_lv<16>) (sext_ln1118_899_fu_10328473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1294_fu_1693_p2() {
    mul_ln1118_1294_fu_1693_p2 = (!mul_ln1118_1294_fu_1693_p0.read().is_01() || !ap_const_lv26_172.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1294_fu_1693_p0.read()) * sc_biguint<26>(ap_const_lv26_172);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1295_fu_2161_p0() {
    mul_ln1118_1295_fu_2161_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1295_fu_2161_p2() {
    mul_ln1118_1295_fu_2161_p2 = (!mul_ln1118_1295_fu_2161_p0.read().is_01() || !ap_const_lv25_1FFFF48.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1295_fu_2161_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF48);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1296_fu_2000_p0() {
    mul_ln1118_1296_fu_2000_p0 =  (sc_lv<16>) (sext_ln1118_897_fu_10328459_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1296_fu_2000_p2() {
    mul_ln1118_1296_fu_2000_p2 = (!mul_ln1118_1296_fu_2000_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1296_fu_2000_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1297_fu_1839_p0() {
    mul_ln1118_1297_fu_1839_p0 =  (sc_lv<16>) (sext_ln1118_896_fu_10328453_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1297_fu_1839_p2() {
    mul_ln1118_1297_fu_1839_p2 = (!mul_ln1118_1297_fu_1839_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1297_fu_1839_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1298_fu_3483_p0() {
    mul_ln1118_1298_fu_3483_p0 =  (sc_lv<16>) (sext_ln1118_899_fu_10328473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1298_fu_3483_p2() {
    mul_ln1118_1298_fu_3483_p2 = (!mul_ln1118_1298_fu_3483_p0.read().is_01() || !ap_const_lv26_125.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1298_fu_3483_p0.read()) * sc_biguint<26>(ap_const_lv26_125);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1299_fu_3404_p0() {
    mul_ln1118_1299_fu_3404_p0 =  (sc_lv<16>) (sext_ln1118_902_fu_10328490_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1299_fu_3404_p2() {
    mul_ln1118_1299_fu_3404_p2 = (!mul_ln1118_1299_fu_3404_p0.read().is_01() || !ap_const_lv24_4A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1299_fu_3404_p0.read()) * sc_biguint<24>(ap_const_lv24_4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1300_fu_1985_p0() {
    mul_ln1118_1300_fu_1985_p0 =  (sc_lv<16>) (sext_ln1118_902_fu_10328490_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1300_fu_1985_p2() {
    mul_ln1118_1300_fu_1985_p2 = (!mul_ln1118_1300_fu_1985_p0.read().is_01() || !ap_const_lv24_FFFF98.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1300_fu_1985_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1301_fu_2453_p0() {
    mul_ln1118_1301_fu_2453_p0 =  (sc_lv<16>) (sext_ln1118_902_fu_10328490_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1301_fu_2453_p2() {
    mul_ln1118_1301_fu_2453_p2 = (!mul_ln1118_1301_fu_2453_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1301_fu_2453_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1302_fu_2921_p0() {
    mul_ln1118_1302_fu_2921_p0 =  (sc_lv<16>) (sext_ln1118_899_fu_10328473_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1302_fu_2921_p2() {
    mul_ln1118_1302_fu_2921_p2 = (!mul_ln1118_1302_fu_2921_p0.read().is_01() || !ap_const_lv26_17F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1302_fu_2921_p0.read()) * sc_biguint<26>(ap_const_lv26_17F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1303_fu_2131_p0() {
    mul_ln1118_1303_fu_2131_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1303_fu_2131_p2() {
    mul_ln1118_1303_fu_2131_p2 = (!mul_ln1118_1303_fu_2131_p0.read().is_01() || !ap_const_lv25_92.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1303_fu_2131_p0.read()) * sc_biguint<25>(ap_const_lv25_92);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1304_fu_2030_p0() {
    mul_ln1118_1304_fu_2030_p0 =  (sc_lv<16>) (sext_ln1118_916_fu_10329013_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1304_fu_2030_p2() {
    mul_ln1118_1304_fu_2030_p2 = (!mul_ln1118_1304_fu_2030_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1304_fu_2030_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1305_fu_2615_p0() {
    mul_ln1118_1305_fu_2615_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1305_fu_2615_p2() {
    mul_ln1118_1305_fu_2615_p2 = (!mul_ln1118_1305_fu_2615_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1305_fu_2615_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1306_fu_3595_p0() {
    mul_ln1118_1306_fu_3595_p0 =  (sc_lv<16>) (sext_ln1118_913_fu_10328980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1306_fu_3595_p2() {
    mul_ln1118_1306_fu_3595_p2 = (!mul_ln1118_1306_fu_3595_p0.read().is_01() || !ap_const_lv24_FFFFBB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1306_fu_3595_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1307_fu_2176_p0() {
    mul_ln1118_1307_fu_2176_p0 =  (sc_lv<16>) (sext_ln1118_913_fu_10328980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1307_fu_2176_p2() {
    mul_ln1118_1307_fu_2176_p2 = (!mul_ln1118_1307_fu_2176_p0.read().is_01() || !ap_const_lv24_63.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1307_fu_2176_p0.read()) * sc_biguint<24>(ap_const_lv24_63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1308_fu_2015_p0() {
    mul_ln1118_1308_fu_2015_p0 =  (sc_lv<16>) (sext_ln1118_915_fu_10329005_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1308_fu_2015_p2() {
    mul_ln1118_1308_fu_2015_p2 = (!mul_ln1118_1308_fu_2015_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1308_fu_2015_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1309_fu_1854_p0() {
    mul_ln1118_1309_fu_1854_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1309_fu_1854_p2() {
    mul_ln1118_1309_fu_1854_p2 = (!mul_ln1118_1309_fu_1854_p0.read().is_01() || !ap_const_lv25_1FFFF5B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1309_fu_1854_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1310_fu_2951_p0() {
    mul_ln1118_1310_fu_2951_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1310_fu_2951_p2() {
    mul_ln1118_1310_fu_2951_p2 = (!mul_ln1118_1310_fu_2951_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1310_fu_2951_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1311_fu_2790_p0() {
    mul_ln1118_1311_fu_2790_p0 =  (sc_lv<16>) (sext_ln1118_915_fu_10329005_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1311_fu_2790_p2() {
    mul_ln1118_1311_fu_2790_p2 = (!mul_ln1118_1311_fu_2790_p0.read().is_01() || !ap_const_lv23_2C.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1311_fu_2790_p0.read()) * sc_biguint<23>(ap_const_lv23_2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1312_fu_2629_p0() {
    mul_ln1118_1312_fu_2629_p0 =  (sc_lv<16>) (sext_ln1118_913_fu_10328980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1312_fu_2629_p2() {
    mul_ln1118_1312_fu_2629_p2 = (!mul_ln1118_1312_fu_2629_p0.read().is_01() || !ap_const_lv24_53.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1312_fu_2629_p0.read()) * sc_biguint<24>(ap_const_lv24_53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1313_fu_2468_p0() {
    mul_ln1118_1313_fu_2468_p0 =  (sc_lv<16>) (sext_ln1118_913_fu_10328980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1313_fu_2468_p2() {
    mul_ln1118_1313_fu_2468_p2 = (!mul_ln1118_1313_fu_2468_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1313_fu_2468_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1314_fu_1678_p0() {
    mul_ln1118_1314_fu_1678_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1314_fu_1678_p2() {
    mul_ln1118_1314_fu_1678_p2 = (!mul_ln1118_1314_fu_1678_p0.read().is_01() || !ap_const_lv25_EB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1314_fu_1678_p0.read()) * sc_biguint<25>(ap_const_lv25_EB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1315_fu_2775_p0() {
    mul_ln1118_1315_fu_2775_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1315_fu_2775_p2() {
    mul_ln1118_1315_fu_2775_p2 = (!mul_ln1118_1315_fu_2775_p0.read().is_01() || !ap_const_lv25_1FFFF03.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1315_fu_2775_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF03);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1316_fu_3243_p0() {
    mul_ln1118_1316_fu_3243_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1316_fu_3243_p2() {
    mul_ln1118_1316_fu_3243_p2 = (!mul_ln1118_1316_fu_3243_p0.read().is_01() || !ap_const_lv25_1FFFF2E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1316_fu_3243_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1317_fu_3082_p0() {
    mul_ln1118_1317_fu_3082_p0 =  (sc_lv<16>) (sext_ln1118_913_fu_10328980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1317_fu_3082_p2() {
    mul_ln1118_1317_fu_3082_p2 = (!mul_ln1118_1317_fu_3082_p0.read().is_01() || !ap_const_lv24_55.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1317_fu_3082_p0.read()) * sc_biguint<24>(ap_const_lv24_55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1318_fu_2292_p0() {
    mul_ln1118_1318_fu_2292_p0 =  (sc_lv<16>) (sext_ln1118_915_fu_10329005_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1318_fu_2292_p2() {
    mul_ln1118_1318_fu_2292_p2 = (!mul_ln1118_1318_fu_2292_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1318_fu_2292_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1319_fu_1645_p0() {
    mul_ln1118_1319_fu_1645_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1319_fu_1645_p2() {
    mul_ln1118_1319_fu_1645_p2 = (!mul_ln1118_1319_fu_1645_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1319_fu_1645_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1320_fu_3205_p0() {
    mul_ln1118_1320_fu_3205_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1320_fu_3205_p2() {
    mul_ln1118_1320_fu_3205_p2 = (!mul_ln1118_1320_fu_3205_p0.read().is_01() || !ap_const_lv25_9B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1320_fu_3205_p0.read()) * sc_biguint<25>(ap_const_lv25_9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1321_fu_3206_p0() {
    mul_ln1118_1321_fu_3206_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1321_fu_3206_p2() {
    mul_ln1118_1321_fu_3206_p2 = (!mul_ln1118_1321_fu_3206_p0.read().is_01() || !ap_const_lv25_97.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1321_fu_3206_p0.read()) * sc_biguint<25>(ap_const_lv25_97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1322_fu_1648_p0() {
    mul_ln1118_1322_fu_1648_p0 =  (sc_lv<16>) (sext_ln1118_915_fu_10329005_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1322_fu_1648_p2() {
    mul_ln1118_1322_fu_1648_p2 = (!mul_ln1118_1322_fu_1648_p0.read().is_01() || !ap_const_lv23_7FFFC6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1322_fu_1648_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1323_fu_3208_p0() {
    mul_ln1118_1323_fu_3208_p0 = sext_ln1118_912_fu_10328975_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1323_fu_3208_p2() {
    mul_ln1118_1323_fu_3208_p2 = (!mul_ln1118_1323_fu_3208_p0.read().is_01() || !ap_const_lv26_3FFFEFB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1323_fu_3208_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEFB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1324_fu_3209_p0() {
    mul_ln1118_1324_fu_3209_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1324_fu_3209_p2() {
    mul_ln1118_1324_fu_3209_p2 = (!mul_ln1118_1324_fu_3209_p0.read().is_01() || !ap_const_lv25_1FFFF72.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1324_fu_3209_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1325_fu_1651_p0() {
    mul_ln1118_1325_fu_1651_p0 =  (sc_lv<16>) (sext_ln1118_914_fu_10328989_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1325_fu_1651_p2() {
    mul_ln1118_1325_fu_1651_p2 = (!mul_ln1118_1325_fu_1651_p0.read().is_01() || !ap_const_lv25_B6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1325_fu_1651_p0.read()) * sc_biguint<25>(ap_const_lv25_B6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1326_fu_2721_p0() {
    mul_ln1118_1326_fu_2721_p0 =  (sc_lv<16>) (sext_ln708_593_fu_10329622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1326_fu_2721_p2() {
    mul_ln1118_1326_fu_2721_p2 = (!mul_ln1118_1326_fu_2721_p0.read().is_01() || !ap_const_lv24_FFFFB4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1326_fu_2721_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1327_fu_2722_p0() {
    mul_ln1118_1327_fu_2722_p0 =  (sc_lv<16>) (sext_ln708_592_fu_10329614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1327_fu_2722_p2() {
    mul_ln1118_1327_fu_2722_p2 = (!mul_ln1118_1327_fu_2722_p0.read().is_01() || !ap_const_lv25_E3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1327_fu_2722_p0.read()) * sc_biguint<25>(ap_const_lv25_E3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1328_fu_3213_p0() {
    mul_ln1118_1328_fu_3213_p0 = sext_ln708_594_fu_10329631_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1328_fu_3213_p2() {
    mul_ln1118_1328_fu_3213_p2 = (!mul_ln1118_1328_fu_3213_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1328_fu_3213_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1329_fu_3214_p0() {
    mul_ln1118_1329_fu_3214_p0 =  (sc_lv<16>) (sext_ln708_593_fu_10329622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1329_fu_3214_p2() {
    mul_ln1118_1329_fu_3214_p2 = (!mul_ln1118_1329_fu_3214_p0.read().is_01() || !ap_const_lv24_FFFF99.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1329_fu_3214_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF99);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1330_fu_3215_p0() {
    mul_ln1118_1330_fu_3215_p0 =  (sc_lv<16>) (sext_ln708_597_fu_10329645_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1330_fu_3215_p2() {
    mul_ln1118_1330_fu_3215_p2 = (!mul_ln1118_1330_fu_3215_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1330_fu_3215_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1331_fu_1657_p0() {
    mul_ln1118_1331_fu_1657_p0 =  (sc_lv<16>) (sext_ln708_597_fu_10329645_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1331_fu_1657_p2() {
    mul_ln1118_1331_fu_1657_p2 = (!mul_ln1118_1331_fu_1657_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1331_fu_1657_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1332_fu_2727_p0() {
    mul_ln1118_1332_fu_2727_p0 =  (sc_lv<16>) (sext_ln708_593_fu_10329622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1332_fu_2727_p2() {
    mul_ln1118_1332_fu_2727_p2 = (!mul_ln1118_1332_fu_2727_p0.read().is_01() || !ap_const_lv24_4D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1332_fu_2727_p0.read()) * sc_biguint<24>(ap_const_lv24_4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1333_fu_3218_p0() {
    mul_ln1118_1333_fu_3218_p0 =  (sc_lv<16>) (sext_ln708_592_fu_10329614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1333_fu_3218_p2() {
    mul_ln1118_1333_fu_3218_p2 = (!mul_ln1118_1333_fu_3218_p0.read().is_01() || !ap_const_lv25_A9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1333_fu_3218_p0.read()) * sc_biguint<25>(ap_const_lv25_A9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1334_fu_3219_p0() {
    mul_ln1118_1334_fu_3219_p0 =  (sc_lv<16>) (sext_ln708_592_fu_10329614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1334_fu_3219_p2() {
    mul_ln1118_1334_fu_3219_p2 = (!mul_ln1118_1334_fu_3219_p0.read().is_01() || !ap_const_lv25_1FFFF51.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1334_fu_3219_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1335_fu_2151_p0() {
    mul_ln1118_1335_fu_2151_p0 =  (sc_lv<16>) (sext_ln708_592_fu_10329614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1335_fu_2151_p2() {
    mul_ln1118_1335_fu_2151_p2 = (!mul_ln1118_1335_fu_2151_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1335_fu_2151_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1336_fu_3221_p0() {
    mul_ln1118_1336_fu_3221_p0 =  (sc_lv<16>) (sext_ln708_593_fu_10329622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1336_fu_3221_p2() {
    mul_ln1118_1336_fu_3221_p2 = (!mul_ln1118_1336_fu_3221_p0.read().is_01() || !ap_const_lv24_FFFF9F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1336_fu_3221_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1337_fu_1663_p0() {
    mul_ln1118_1337_fu_1663_p0 =  (sc_lv<16>) (sext_ln708_593_fu_10329622_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1337_fu_1663_p2() {
    mul_ln1118_1337_fu_1663_p2 = (!mul_ln1118_1337_fu_1663_p0.read().is_01() || !ap_const_lv24_FFFFAA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1337_fu_1663_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1338_fu_3223_p0() {
    mul_ln1118_1338_fu_3223_p0 =  (sc_lv<16>) (sext_ln708_596_fu_10329640_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1338_fu_3223_p2() {
    mul_ln1118_1338_fu_3223_p2 = (!mul_ln1118_1338_fu_3223_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1338_fu_3223_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1339_fu_2645_p0() {
    mul_ln1118_1339_fu_2645_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1339_fu_2645_p2() {
    mul_ln1118_1339_fu_2645_p2 = (!mul_ln1118_1339_fu_2645_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1339_fu_2645_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1340_fu_1666_p0() {
    mul_ln1118_1340_fu_1666_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1340_fu_1666_p2() {
    mul_ln1118_1340_fu_1666_p2 = (!mul_ln1118_1340_fu_1666_p0.read().is_01() || !ap_const_lv25_89.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1340_fu_1666_p0.read()) * sc_biguint<25>(ap_const_lv25_89);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1341_fu_2157_p0() {
    mul_ln1118_1341_fu_2157_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1341_fu_2157_p2() {
    mul_ln1118_1341_fu_2157_p2 = (!mul_ln1118_1341_fu_2157_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1341_fu_2157_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1342_fu_3227_p0() {
    mul_ln1118_1342_fu_3227_p0 =  (sc_lv<16>) (sext_ln708_618_fu_10330230_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1342_fu_3227_p2() {
    mul_ln1118_1342_fu_3227_p2 = (!mul_ln1118_1342_fu_3227_p0.read().is_01() || !ap_const_lv23_34.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1342_fu_3227_p0.read()) * sc_biguint<23>(ap_const_lv23_34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1343_fu_3228_p0() {
    mul_ln1118_1343_fu_3228_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1343_fu_3228_p2() {
    mul_ln1118_1343_fu_3228_p2 = (!mul_ln1118_1343_fu_3228_p0.read().is_01() || !ap_const_lv25_1FFFF59.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1343_fu_3228_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1344_fu_3229_p0() {
    mul_ln1118_1344_fu_3229_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1344_fu_3229_p2() {
    mul_ln1118_1344_fu_3229_p2 = (!mul_ln1118_1344_fu_3229_p0.read().is_01() || !ap_const_lv25_EF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1344_fu_3229_p0.read()) * sc_biguint<25>(ap_const_lv25_EF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1345_fu_3230_p0() {
    mul_ln1118_1345_fu_3230_p0 =  (sc_lv<16>) (sext_ln708_618_fu_10330230_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1345_fu_3230_p2() {
    mul_ln1118_1345_fu_3230_p2 = (!mul_ln1118_1345_fu_3230_p0.read().is_01() || !ap_const_lv23_7FFFDB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1345_fu_3230_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1346_fu_3087_p0() {
    mul_ln1118_1346_fu_3087_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1346_fu_3087_p2() {
    mul_ln1118_1346_fu_3087_p2 = (!mul_ln1118_1346_fu_3087_p0.read().is_01() || !ap_const_lv25_1FFFF64.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1346_fu_3087_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1347_fu_1668_p0() {
    mul_ln1118_1347_fu_1668_p0 = sext_ln708_614_fu_10330197_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1347_fu_1668_p2() {
    mul_ln1118_1347_fu_1668_p2 = (!mul_ln1118_1347_fu_1668_p0.read().is_01() || !ap_const_lv26_3FFFEEA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1347_fu_1668_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1348_fu_2136_p0() {
    mul_ln1118_1348_fu_2136_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1348_fu_2136_p2() {
    mul_ln1118_1348_fu_2136_p2 = (!mul_ln1118_1348_fu_2136_p0.read().is_01() || !ap_const_lv25_1FFFF5C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1348_fu_2136_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1349_fu_2604_p0() {
    mul_ln1118_1349_fu_2604_p0 = sext_ln708_619_fu_10330236_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1349_fu_2604_p2() {
    mul_ln1118_1349_fu_2604_p2 = (!mul_ln1118_1349_fu_2604_p0.read().is_01() || !ap_const_lv22_3FFFEA.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1349_fu_2604_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1350_fu_2443_p0() {
    mul_ln1118_1350_fu_2443_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1350_fu_2443_p2() {
    mul_ln1118_1350_fu_2443_p2 = (!mul_ln1118_1350_fu_2443_p0.read().is_01() || !ap_const_lv25_C6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1350_fu_2443_p0.read()) * sc_biguint<25>(ap_const_lv25_C6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1351_fu_2282_p0() {
    mul_ln1118_1351_fu_2282_p0 =  (sc_lv<16>) (sext_ln708_617_fu_10330221_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1351_fu_2282_p2() {
    mul_ln1118_1351_fu_2282_p2 = (!mul_ln1118_1351_fu_2282_p0.read().is_01() || !ap_const_lv24_5C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1351_fu_2282_p0.read()) * sc_biguint<24>(ap_const_lv24_5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1352_fu_2750_p0() {
    mul_ln1118_1352_fu_2750_p0 =  (sc_lv<16>) (sext_ln708_617_fu_10330221_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1352_fu_2750_p2() {
    mul_ln1118_1352_fu_2750_p2 = (!mul_ln1118_1352_fu_2750_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1352_fu_2750_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1353_fu_1960_p0() {
    mul_ln1118_1353_fu_1960_p0 =  (sc_lv<16>) (sext_ln708_617_fu_10330221_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1353_fu_1960_p2() {
    mul_ln1118_1353_fu_1960_p2 = (!mul_ln1118_1353_fu_1960_p0.read().is_01() || !ap_const_lv24_4F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1353_fu_1960_p0.read()) * sc_biguint<24>(ap_const_lv24_4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1354_fu_3057_p0() {
    mul_ln1118_1354_fu_3057_p0 =  (sc_lv<16>) (sext_ln708_617_fu_10330221_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1354_fu_3057_p2() {
    mul_ln1118_1354_fu_3057_p2 = (!mul_ln1118_1354_fu_3057_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1354_fu_3057_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1355_fu_3525_p0() {
    mul_ln1118_1355_fu_3525_p0 = sext_ln708_616_fu_10330216_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1355_fu_3525_p2() {
    mul_ln1118_1355_fu_3525_p2 = (!mul_ln1118_1355_fu_3525_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1355_fu_3525_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1356_fu_3282_p0() {
    mul_ln1118_1356_fu_3282_p0 =  (sc_lv<16>) (sext_ln708_617_fu_10330221_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1356_fu_3282_p2() {
    mul_ln1118_1356_fu_3282_p2 = (!mul_ln1118_1356_fu_3282_p0.read().is_01() || !ap_const_lv24_FFFF85.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1356_fu_3282_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1357_fu_2574_p0() {
    mul_ln1118_1357_fu_2574_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1357_fu_2574_p2() {
    mul_ln1118_1357_fu_2574_p2 = (!mul_ln1118_1357_fu_2574_p0.read().is_01() || !ap_const_lv25_1FFFF2C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1357_fu_2574_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1358_fu_3589_p0() {
    mul_ln1118_1358_fu_3589_p0 =  (sc_lv<16>) (sext_ln708_615_fu_10330202_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1358_fu_3589_p2() {
    mul_ln1118_1358_fu_3589_p2 = (!mul_ln1118_1358_fu_3589_p0.read().is_01() || !ap_const_lv25_DD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1358_fu_3589_p0.read()) * sc_biguint<25>(ap_const_lv25_DD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1359_fu_3207_p0() {
    mul_ln1118_1359_fu_3207_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1359_fu_3207_p2() {
    mul_ln1118_1359_fu_3207_p2 = (!mul_ln1118_1359_fu_3207_p0.read().is_01() || !ap_const_lv25_1FFFF26.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1359_fu_3207_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF26);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1360_fu_3675_p0() {
    mul_ln1118_1360_fu_3675_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1360_fu_3675_p2() {
    mul_ln1118_1360_fu_3675_p2 = (!mul_ln1118_1360_fu_3675_p0.read().is_01() || !ap_const_lv25_1FFFF52.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1360_fu_3675_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1361_fu_3514_p0() {
    mul_ln1118_1361_fu_3514_p0 =  (sc_lv<16>) (sext_ln1118_949_fu_10330825_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1361_fu_3514_p2() {
    mul_ln1118_1361_fu_3514_p2 = (!mul_ln1118_1361_fu_3514_p0.read().is_01() || !ap_const_lv24_FFFFA3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1361_fu_3514_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1362_fu_2724_p0() {
    mul_ln1118_1362_fu_2724_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1362_fu_2724_p2() {
    mul_ln1118_1362_fu_2724_p2 = (!mul_ln1118_1362_fu_2724_p0.read().is_01() || !ap_const_lv25_1FFFF4F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1362_fu_2724_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1363_fu_1934_p0() {
    mul_ln1118_1363_fu_1934_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1363_fu_1934_p2() {
    mul_ln1118_1363_fu_1934_p2 = (!mul_ln1118_1363_fu_1934_p0.read().is_01() || !ap_const_lv25_1FFFF64.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1363_fu_1934_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1364_fu_1916_p0() {
    mul_ln1118_1364_fu_1916_p0 =  (sc_lv<16>) (sext_ln1118_947_fu_10330805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1364_fu_1916_p2() {
    mul_ln1118_1364_fu_1916_p2 = (!mul_ln1118_1364_fu_1916_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1364_fu_1916_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1365_fu_2241_p0() {
    mul_ln1118_1365_fu_2241_p0 =  (sc_lv<16>) (sext_ln1118_947_fu_10330805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1365_fu_2241_p2() {
    mul_ln1118_1365_fu_2241_p2 = (!mul_ln1118_1365_fu_2241_p0.read().is_01() || !ap_const_lv23_2B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1365_fu_2241_p0.read()) * sc_biguint<23>(ap_const_lv23_2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1366_fu_2080_p0() {
    mul_ln1118_1366_fu_2080_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1366_fu_2080_p2() {
    mul_ln1118_1366_fu_2080_p2 = (!mul_ln1118_1366_fu_2080_p0.read().is_01() || !ap_const_lv25_1FFFF6C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1366_fu_2080_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1367_fu_1919_p0() {
    mul_ln1118_1367_fu_1919_p0 =  (sc_lv<16>) (sext_ln1118_949_fu_10330825_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1367_fu_1919_p2() {
    mul_ln1118_1367_fu_1919_p2 = (!mul_ln1118_1367_fu_1919_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1367_fu_1919_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1368_fu_3016_p0() {
    mul_ln1118_1368_fu_3016_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1368_fu_3016_p2() {
    mul_ln1118_1368_fu_3016_p2 = (!mul_ln1118_1368_fu_3016_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1368_fu_3016_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1369_fu_2855_p0() {
    mul_ln1118_1369_fu_2855_p0 =  (sc_lv<16>) (sext_ln1118_949_fu_10330825_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1369_fu_2855_p2() {
    mul_ln1118_1369_fu_2855_p2 = (!mul_ln1118_1369_fu_2855_p0.read().is_01() || !ap_const_lv24_58.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1369_fu_2855_p0.read()) * sc_biguint<24>(ap_const_lv24_58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1370_fu_2694_p0() {
    mul_ln1118_1370_fu_2694_p0 =  (sc_lv<16>) (sext_ln1118_947_fu_10330805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1370_fu_2694_p2() {
    mul_ln1118_1370_fu_2694_p2 = (!mul_ln1118_1370_fu_2694_p0.read().is_01() || !ap_const_lv23_27.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1370_fu_2694_p0.read()) * sc_biguint<23>(ap_const_lv23_27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1371_fu_3162_p0() {
    mul_ln1118_1371_fu_3162_p0 =  (sc_lv<16>) (sext_ln1118_947_fu_10330805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1371_fu_3162_p2() {
    mul_ln1118_1371_fu_3162_p2 = (!mul_ln1118_1371_fu_3162_p0.read().is_01() || !ap_const_lv23_7FFFCE.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1371_fu_3162_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1372_fu_1886_p0() {
    mul_ln1118_1372_fu_1886_p0 =  (sc_lv<16>) (sext_ln1118_948_fu_10330814_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1372_fu_1886_p2() {
    mul_ln1118_1372_fu_1886_p2 = (!mul_ln1118_1372_fu_1886_p0.read().is_01() || !ap_const_lv25_B8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1372_fu_1886_p0.read()) * sc_biguint<25>(ap_const_lv25_B8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1373_fu_2840_p0() {
    mul_ln1118_1373_fu_2840_p0 =  (sc_lv<16>) (sext_ln1118_947_fu_10330805_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1373_fu_2840_p2() {
    mul_ln1118_1373_fu_2840_p2 = (!mul_ln1118_1373_fu_2840_p0.read().is_01() || !ap_const_lv23_7FFFC9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1373_fu_2840_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1374_fu_2320_p0() {
    mul_ln1118_1374_fu_2320_p0 =  (sc_lv<16>) (sext_ln1118_949_fu_10330825_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1374_fu_2320_p2() {
    mul_ln1118_1374_fu_2320_p2 = (!mul_ln1118_1374_fu_2320_p0.read().is_01() || !ap_const_lv24_6E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1374_fu_2320_p0.read()) * sc_biguint<24>(ap_const_lv24_6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1375_fu_2811_p0() {
    mul_ln1118_1375_fu_2811_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1375_fu_2811_p2() {
    mul_ln1118_1375_fu_2811_p2 = (!mul_ln1118_1375_fu_2811_p0.read().is_01() || !ap_const_lv25_1FFFF34.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1375_fu_2811_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1376_fu_2322_p0() {
    mul_ln1118_1376_fu_2322_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1376_fu_2322_p2() {
    mul_ln1118_1376_fu_2322_p2 = (!mul_ln1118_1376_fu_2322_p0.read().is_01() || !ap_const_lv25_1FFFF3F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1376_fu_2322_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1377_fu_2813_p0() {
    mul_ln1118_1377_fu_2813_p0 =  (sc_lv<16>) (sext_ln1118_959_fu_10331310_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1377_fu_2813_p2() {
    mul_ln1118_1377_fu_2813_p2 = (!mul_ln1118_1377_fu_2813_p0.read().is_01() || !ap_const_lv24_58.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1377_fu_2813_p0.read()) * sc_biguint<24>(ap_const_lv24_58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1378_fu_1834_p0() {
    mul_ln1118_1378_fu_1834_p0 =  (sc_lv<16>) (sext_ln1118_957_fu_10331297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1378_fu_1834_p2() {
    mul_ln1118_1378_fu_1834_p2 = (!mul_ln1118_1378_fu_1834_p0.read().is_01() || !ap_const_lv26_3FFFED5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1378_fu_1834_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1379_fu_2325_p0() {
    mul_ln1118_1379_fu_2325_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1379_fu_2325_p2() {
    mul_ln1118_1379_fu_2325_p2 = (!mul_ln1118_1379_fu_2325_p0.read().is_01() || !ap_const_lv25_A5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1379_fu_2325_p0.read()) * sc_biguint<25>(ap_const_lv25_A5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1380_fu_2326_p0() {
    mul_ln1118_1380_fu_2326_p0 =  (sc_lv<16>) (sext_ln1118_959_fu_10331310_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1380_fu_2326_p2() {
    mul_ln1118_1380_fu_2326_p2 = (!mul_ln1118_1380_fu_2326_p0.read().is_01() || !ap_const_lv24_FFFFA8.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1380_fu_2326_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1381_fu_2327_p0() {
    mul_ln1118_1381_fu_2327_p0 =  (sc_lv<16>) (sext_ln1118_961_fu_10331333_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1381_fu_2327_p2() {
    mul_ln1118_1381_fu_2327_p2 = (!mul_ln1118_1381_fu_2327_p0.read().is_01() || !ap_const_lv23_37.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1381_fu_2327_p0.read()) * sc_biguint<23>(ap_const_lv23_37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1382_fu_2328_p0() {
    mul_ln1118_1382_fu_2328_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1382_fu_2328_p2() {
    mul_ln1118_1382_fu_2328_p2 = (!mul_ln1118_1382_fu_2328_p0.read().is_01() || !ap_const_lv25_1FFFF57.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1382_fu_2328_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1383_fu_2329_p0() {
    mul_ln1118_1383_fu_2329_p0 =  (sc_lv<16>) (sext_ln1118_957_fu_10331297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1383_fu_2329_p2() {
    mul_ln1118_1383_fu_2329_p2 = (!mul_ln1118_1383_fu_2329_p0.read().is_01() || !ap_const_lv26_3FFFEE5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1383_fu_2329_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1384_fu_2820_p0() {
    mul_ln1118_1384_fu_2820_p0 =  (sc_lv<16>) (sext_ln1118_959_fu_10331310_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1384_fu_2820_p2() {
    mul_ln1118_1384_fu_2820_p2 = (!mul_ln1118_1384_fu_2820_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1384_fu_2820_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1385_fu_2331_p0() {
    mul_ln1118_1385_fu_2331_p0 =  (sc_lv<16>) (sext_ln1118_957_fu_10331297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1385_fu_2331_p2() {
    mul_ln1118_1385_fu_2331_p2 = (!mul_ln1118_1385_fu_2331_p0.read().is_01() || !ap_const_lv26_135.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1385_fu_2331_p0.read()) * sc_biguint<26>(ap_const_lv26_135);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1386_fu_2332_p0() {
    mul_ln1118_1386_fu_2332_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1386_fu_2332_p2() {
    mul_ln1118_1386_fu_2332_p2 = (!mul_ln1118_1386_fu_2332_p0.read().is_01() || !ap_const_lv25_BE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1386_fu_2332_p0.read()) * sc_biguint<25>(ap_const_lv25_BE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1387_fu_2333_p0() {
    mul_ln1118_1387_fu_2333_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1387_fu_2333_p2() {
    mul_ln1118_1387_fu_2333_p2 = (!mul_ln1118_1387_fu_2333_p0.read().is_01() || !ap_const_lv25_A8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1387_fu_2333_p0.read()) * sc_biguint<25>(ap_const_lv25_A8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1388_fu_1755_p0() {
    mul_ln1118_1388_fu_1755_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1388_fu_1755_p2() {
    mul_ln1118_1388_fu_1755_p2 = (!mul_ln1118_1388_fu_1755_p0.read().is_01() || !ap_const_lv25_A1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1388_fu_1755_p0.read()) * sc_biguint<25>(ap_const_lv25_A1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1389_fu_2825_p0() {
    mul_ln1118_1389_fu_2825_p0 =  (sc_lv<16>) (sext_ln1118_957_fu_10331297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1389_fu_2825_p2() {
    mul_ln1118_1389_fu_2825_p2 = (!mul_ln1118_1389_fu_2825_p0.read().is_01() || !ap_const_lv26_10B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1389_fu_2825_p0.read()) * sc_biguint<26>(ap_const_lv26_10B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1390_fu_1846_p0() {
    mul_ln1118_1390_fu_1846_p0 = sext_ln1118_962_fu_10331339_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1390_fu_1846_p2() {
    mul_ln1118_1390_fu_1846_p2 = (!mul_ln1118_1390_fu_1846_p0.read().is_01() || !ap_const_lv22_3FFFE9.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1390_fu_1846_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1391_fu_2827_p0() {
    mul_ln1118_1391_fu_2827_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1391_fu_2827_p2() {
    mul_ln1118_1391_fu_2827_p2 = (!mul_ln1118_1391_fu_2827_p0.read().is_01() || !ap_const_lv25_8D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1391_fu_2827_p0.read()) * sc_biguint<25>(ap_const_lv25_8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1392_fu_2338_p0() {
    mul_ln1118_1392_fu_2338_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1392_fu_2338_p2() {
    mul_ln1118_1392_fu_2338_p2 = (!mul_ln1118_1392_fu_2338_p0.read().is_01() || !ap_const_lv25_F4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1392_fu_2338_p0.read()) * sc_biguint<25>(ap_const_lv25_F4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1393_fu_2829_p0() {
    mul_ln1118_1393_fu_2829_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1393_fu_2829_p2() {
    mul_ln1118_1393_fu_2829_p2 = (!mul_ln1118_1393_fu_2829_p0.read().is_01() || !ap_const_lv25_B2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1393_fu_2829_p0.read()) * sc_biguint<25>(ap_const_lv25_B2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1394_fu_1850_p0() {
    mul_ln1118_1394_fu_1850_p0 =  (sc_lv<16>) (sext_ln1118_959_fu_10331310_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1394_fu_1850_p2() {
    mul_ln1118_1394_fu_1850_p2 = (!mul_ln1118_1394_fu_1850_p0.read().is_01() || !ap_const_lv24_4E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1394_fu_1850_p0.read()) * sc_biguint<24>(ap_const_lv24_4E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1395_fu_2341_p0() {
    mul_ln1118_1395_fu_2341_p0 =  (sc_lv<16>) (sext_ln1118_961_fu_10331333_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1395_fu_2341_p2() {
    mul_ln1118_1395_fu_2341_p2 = (!mul_ln1118_1395_fu_2341_p0.read().is_01() || !ap_const_lv23_7FFFC9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1395_fu_2341_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1396_fu_2342_p0() {
    mul_ln1118_1396_fu_2342_p0 =  (sc_lv<16>) (sext_ln1118_957_fu_10331297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1396_fu_2342_p2() {
    mul_ln1118_1396_fu_2342_p2 = (!mul_ln1118_1396_fu_2342_p0.read().is_01() || !ap_const_lv26_149.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1396_fu_2342_p0.read()) * sc_biguint<26>(ap_const_lv26_149);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1397_fu_2833_p0() {
    mul_ln1118_1397_fu_2833_p0 =  (sc_lv<16>) (sext_ln1118_960_fu_10331318_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1397_fu_2833_p2() {
    mul_ln1118_1397_fu_2833_p2 = (!mul_ln1118_1397_fu_2833_p0.read().is_01() || !ap_const_lv25_1FFFF36.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1397_fu_2833_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1398_fu_2834_p0() {
    mul_ln1118_1398_fu_2834_p0 =  (sc_lv<16>) (sext_ln1118_974_fu_10331882_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1398_fu_2834_p2() {
    mul_ln1118_1398_fu_2834_p2 = (!mul_ln1118_1398_fu_2834_p0.read().is_01() || !ap_const_lv26_188.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1398_fu_2834_p0.read()) * sc_biguint<26>(ap_const_lv26_188);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1399_fu_1855_p0() {
    mul_ln1118_1399_fu_1855_p0 =  (sc_lv<16>) (sext_ln1118_974_fu_10331882_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1399_fu_1855_p2() {
    mul_ln1118_1399_fu_1855_p2 = (!mul_ln1118_1399_fu_1855_p0.read().is_01() || !ap_const_lv26_3FFFEDA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1399_fu_1855_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1400_fu_2836_p0() {
    mul_ln1118_1400_fu_2836_p0 =  (sc_lv<16>) (sext_ln1118_973_fu_10331876_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1400_fu_2836_p2() {
    mul_ln1118_1400_fu_2836_p2 = (!mul_ln1118_1400_fu_2836_p0.read().is_01() || !ap_const_lv24_FFFF98.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1400_fu_2836_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1401_fu_1857_p0() {
    mul_ln1118_1401_fu_1857_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1401_fu_1857_p2() {
    mul_ln1118_1401_fu_1857_p2 = (!mul_ln1118_1401_fu_1857_p0.read().is_01() || !ap_const_lv25_1FFFF6F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1401_fu_1857_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1402_fu_1950_p0() {
    mul_ln1118_1402_fu_1950_p0 =  (sc_lv<16>) (sext_ln1118_973_fu_10331876_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1402_fu_1950_p2() {
    mul_ln1118_1402_fu_1950_p2 = (!mul_ln1118_1402_fu_1950_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1402_fu_1950_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1403_fu_3676_p0() {
    mul_ln1118_1403_fu_3676_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1403_fu_3676_p2() {
    mul_ln1118_1403_fu_3676_p2 = (!mul_ln1118_1403_fu_3676_p0.read().is_01() || !ap_const_lv25_98.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1403_fu_3676_p0.read()) * sc_biguint<25>(ap_const_lv25_98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1404_fu_2257_p0() {
    mul_ln1118_1404_fu_2257_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1404_fu_2257_p2() {
    mul_ln1118_1404_fu_2257_p2 = (!mul_ln1118_1404_fu_2257_p0.read().is_01() || !ap_const_lv25_1FFFF32.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1404_fu_2257_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1405_fu_2096_p0() {
    mul_ln1118_1405_fu_2096_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1405_fu_2096_p2() {
    mul_ln1118_1405_fu_2096_p2 = (!mul_ln1118_1405_fu_2096_p0.read().is_01() || !ap_const_lv25_1FFFF48.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1405_fu_2096_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF48);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1406_fu_3193_p0() {
    mul_ln1118_1406_fu_3193_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1406_fu_3193_p2() {
    mul_ln1118_1406_fu_3193_p2 = (!mul_ln1118_1406_fu_3193_p0.read().is_01() || !ap_const_lv25_1FFFF7D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1406_fu_3193_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1407_fu_1774_p0() {
    mul_ln1118_1407_fu_1774_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1407_fu_1774_p2() {
    mul_ln1118_1407_fu_1774_p2 = (!mul_ln1118_1407_fu_1774_p0.read().is_01() || !ap_const_lv25_D0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1407_fu_1774_p0.read()) * sc_biguint<25>(ap_const_lv25_D0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1408_fu_3500_p0() {
    mul_ln1118_1408_fu_3500_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1408_fu_3500_p2() {
    mul_ln1118_1408_fu_3500_p2 = (!mul_ln1118_1408_fu_3500_p0.read().is_01() || !ap_const_lv25_91.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1408_fu_3500_p0.read()) * sc_biguint<25>(ap_const_lv25_91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1409_fu_3339_p0() {
    mul_ln1118_1409_fu_3339_p0 =  (sc_lv<16>) (sext_ln1118_972_fu_10331864_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1409_fu_3339_p2() {
    mul_ln1118_1409_fu_3339_p2 = (!mul_ln1118_1409_fu_3339_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1409_fu_3339_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1410_fu_3178_p0() {
    mul_ln1118_1410_fu_3178_p0 = sext_ln1118_975_fu_10331890_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1410_fu_3178_p2() {
    mul_ln1118_1410_fu_3178_p2 = (!mul_ln1118_1410_fu_3178_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1410_fu_3178_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1411_fu_1759_p0() {
    mul_ln1118_1411_fu_1759_p0 =  (sc_lv<16>) (sext_ln1118_974_fu_10331882_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1411_fu_1759_p2() {
    mul_ln1118_1411_fu_1759_p2 = (!mul_ln1118_1411_fu_1759_p0.read().is_01() || !ap_const_lv26_10B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1411_fu_1759_p0.read()) * sc_biguint<26>(ap_const_lv26_10B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1412_fu_2856_p0() {
    mul_ln1118_1412_fu_2856_p0 =  (sc_lv<16>) (sext_ln1118_974_fu_10331882_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1412_fu_2856_p2() {
    mul_ln1118_1412_fu_2856_p2 = (!mul_ln1118_1412_fu_2856_p0.read().is_01() || !ap_const_lv26_14C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1412_fu_2856_p0.read()) * sc_biguint<26>(ap_const_lv26_14C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1413_fu_3324_p0() {
    mul_ln1118_1413_fu_3324_p0 =  (sc_lv<16>) (sext_ln708_691_fu_10332430_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1413_fu_3324_p2() {
    mul_ln1118_1413_fu_3324_p2 = (!mul_ln1118_1413_fu_3324_p0.read().is_01() || !ap_const_lv24_6F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1413_fu_3324_p0.read()) * sc_biguint<24>(ap_const_lv24_6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1414_fu_3163_p0() {
    mul_ln1118_1414_fu_3163_p0 =  (sc_lv<16>) (sext_ln708_689_fu_10332419_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1414_fu_3163_p2() {
    mul_ln1118_1414_fu_3163_p2 = (!mul_ln1118_1414_fu_3163_p0.read().is_01() || !ap_const_lv23_7FFFDD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1414_fu_3163_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1415_fu_2622_p0() {
    mul_ln1118_1415_fu_2622_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1415_fu_2622_p2() {
    mul_ln1118_1415_fu_2622_p2 = (!mul_ln1118_1415_fu_2622_p0.read().is_01() || !ap_const_lv25_C8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1415_fu_2622_p0.read()) * sc_biguint<25>(ap_const_lv25_C8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1416_fu_2947_p0() {
    mul_ln1118_1416_fu_2947_p0 = sext_ln708_686_fu_10332397_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1416_fu_2947_p2() {
    mul_ln1118_1416_fu_2947_p2 = (!mul_ln1118_1416_fu_2947_p0.read().is_01() || !ap_const_lv26_10A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1416_fu_2947_p0.read()) * sc_biguint<26>(ap_const_lv26_10A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1417_fu_2186_p0() {
    mul_ln1118_1417_fu_2186_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1417_fu_2186_p2() {
    mul_ln1118_1417_fu_2186_p2 = (!mul_ln1118_1417_fu_2186_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1417_fu_2186_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1418_fu_3254_p0() {
    mul_ln1118_1418_fu_3254_p0 =  (sc_lv<16>) (sext_ln708_689_fu_10332419_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1418_fu_3254_p2() {
    mul_ln1118_1418_fu_3254_p2 = (!mul_ln1118_1418_fu_3254_p0.read().is_01() || !ap_const_lv23_34.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1418_fu_3254_p0.read()) * sc_biguint<23>(ap_const_lv23_34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1419_fu_3093_p0() {
    mul_ln1118_1419_fu_3093_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1419_fu_3093_p2() {
    mul_ln1118_1419_fu_3093_p2 = (!mul_ln1118_1419_fu_3093_p0.read().is_01() || !ap_const_lv25_CD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1419_fu_3093_p0.read()) * sc_biguint<25>(ap_const_lv25_CD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1420_fu_1674_p0() {
    mul_ln1118_1420_fu_1674_p0 =  (sc_lv<16>) (sext_ln708_688_fu_10332414_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1420_fu_1674_p2() {
    mul_ln1118_1420_fu_1674_p2 = (!mul_ln1118_1420_fu_1674_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_1420_fu_1674_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1421_fu_3400_p0() {
    mul_ln1118_1421_fu_3400_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1421_fu_3400_p2() {
    mul_ln1118_1421_fu_3400_p2 = (!mul_ln1118_1421_fu_3400_p0.read().is_01() || !ap_const_lv25_1FFFF48.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1421_fu_3400_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF48);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1422_fu_3239_p0() {
    mul_ln1118_1422_fu_3239_p0 =  (sc_lv<16>) (sext_ln708_691_fu_10332430_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1422_fu_3239_p2() {
    mul_ln1118_1422_fu_3239_p2 = (!mul_ln1118_1422_fu_3239_p0.read().is_01() || !ap_const_lv24_FFFFBA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1422_fu_3239_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1423_fu_2449_p0() {
    mul_ln1118_1423_fu_2449_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1423_fu_2449_p2() {
    mul_ln1118_1423_fu_2449_p2 = (!mul_ln1118_1423_fu_2449_p0.read().is_01() || !ap_const_lv25_B1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1423_fu_2449_p0.read()) * sc_biguint<25>(ap_const_lv25_B1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1424_fu_1659_p0() {
    mul_ln1118_1424_fu_1659_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1424_fu_1659_p2() {
    mul_ln1118_1424_fu_1659_p2 = (!mul_ln1118_1424_fu_1659_p0.read().is_01() || !ap_const_lv25_DA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1424_fu_1659_p0.read()) * sc_biguint<25>(ap_const_lv25_DA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1425_fu_2756_p0() {
    mul_ln1118_1425_fu_2756_p0 =  (sc_lv<16>) (sext_ln708_691_fu_10332430_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1425_fu_2756_p2() {
    mul_ln1118_1425_fu_2756_p2 = (!mul_ln1118_1425_fu_2756_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1425_fu_2756_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1426_fu_3224_p0() {
    mul_ln1118_1426_fu_3224_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1426_fu_3224_p2() {
    mul_ln1118_1426_fu_3224_p2 = (!mul_ln1118_1426_fu_3224_p0.read().is_01() || !ap_const_lv25_B5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1426_fu_3224_p0.read()) * sc_biguint<25>(ap_const_lv25_B5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1427_fu_3063_p0() {
    mul_ln1118_1427_fu_3063_p0 =  (sc_lv<16>) (sext_ln708_687_fu_10332402_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1427_fu_3063_p2() {
    mul_ln1118_1427_fu_3063_p2 = (!mul_ln1118_1427_fu_3063_p0.read().is_01() || !ap_const_lv25_B9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1427_fu_3063_p0.read()) * sc_biguint<25>(ap_const_lv25_B9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1428_fu_2273_p0() {
    mul_ln1118_1428_fu_2273_p0 =  (sc_lv<16>) (sext_ln708_691_fu_10332430_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1428_fu_2273_p2() {
    mul_ln1118_1428_fu_2273_p2 = (!mul_ln1118_1428_fu_2273_p0.read().is_01() || !ap_const_lv24_67.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1428_fu_2273_p0.read()) * sc_biguint<24>(ap_const_lv24_67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1429_fu_2995_p0() {
    mul_ln1118_1429_fu_2995_p0 =  (sc_lv<16>) (sext_ln708_689_fu_10332419_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1429_fu_2995_p2() {
    mul_ln1118_1429_fu_2995_p2 = (!mul_ln1118_1429_fu_2995_p0.read().is_01() || !ap_const_lv23_7FFFD7.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1429_fu_2995_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1430_fu_3486_p0() {
    mul_ln1118_1430_fu_3486_p0 =  (sc_lv<16>) (sext_ln1118_1004_fu_10333044_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1430_fu_3486_p2() {
    mul_ln1118_1430_fu_3486_p2 = (!mul_ln1118_1430_fu_3486_p0.read().is_01() || !ap_const_lv24_FFFF93.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1430_fu_3486_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1431_fu_2997_p0() {
    mul_ln1118_1431_fu_2997_p0 =  (sc_lv<16>) (sext_ln1118_1004_fu_10333044_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1431_fu_2997_p2() {
    mul_ln1118_1431_fu_2997_p2 = (!mul_ln1118_1431_fu_2997_p0.read().is_01() || !ap_const_lv24_FFFFBB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1431_fu_2997_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1432_fu_1929_p0() {
    mul_ln1118_1432_fu_1929_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1432_fu_1929_p2() {
    mul_ln1118_1432_fu_1929_p2 = (!mul_ln1118_1432_fu_1929_p0.read().is_01() || !ap_const_lv25_1FFFF69.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1432_fu_1929_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1433_fu_3489_p0() {
    mul_ln1118_1433_fu_3489_p0 =  (sc_lv<16>) (sext_ln1118_1005_fu_10333050_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1433_fu_3489_p2() {
    mul_ln1118_1433_fu_3489_p2 = (!mul_ln1118_1433_fu_3489_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1433_fu_3489_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1434_fu_3490_p0() {
    mul_ln1118_1434_fu_3490_p0 =  (sc_lv<16>) (sext_ln1118_1002_fu_10333026_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1434_fu_3490_p2() {
    mul_ln1118_1434_fu_3490_p2 = (!mul_ln1118_1434_fu_3490_p0.read().is_01() || !ap_const_lv26_3FFFEDC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1434_fu_3490_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1435_fu_3491_p0() {
    mul_ln1118_1435_fu_3491_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1435_fu_3491_p2() {
    mul_ln1118_1435_fu_3491_p2 = (!mul_ln1118_1435_fu_3491_p0.read().is_01() || !ap_const_lv25_8F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1435_fu_3491_p0.read()) * sc_biguint<25>(ap_const_lv25_8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1436_fu_3492_p0() {
    mul_ln1118_1436_fu_3492_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1436_fu_3492_p2() {
    mul_ln1118_1436_fu_3492_p2 = (!mul_ln1118_1436_fu_3492_p0.read().is_01() || !ap_const_lv25_EE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1436_fu_3492_p0.read()) * sc_biguint<25>(ap_const_lv25_EE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1437_fu_2424_p0() {
    mul_ln1118_1437_fu_2424_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1437_fu_2424_p2() {
    mul_ln1118_1437_fu_2424_p2 = (!mul_ln1118_1437_fu_2424_p0.read().is_01() || !ap_const_lv25_AD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1437_fu_2424_p0.read()) * sc_biguint<25>(ap_const_lv25_AD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1438_fu_3494_p0() {
    mul_ln1118_1438_fu_3494_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1438_fu_3494_p2() {
    mul_ln1118_1438_fu_3494_p2 = (!mul_ln1118_1438_fu_3494_p0.read().is_01() || !ap_const_lv25_1FFFF06.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1438_fu_3494_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF06);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1439_fu_2895_p0() {
    mul_ln1118_1439_fu_2895_p0 =  (sc_lv<16>) (sext_ln1118_1002_fu_10333026_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1439_fu_2895_p2() {
    mul_ln1118_1439_fu_2895_p2 = (!mul_ln1118_1439_fu_2895_p0.read().is_01() || !ap_const_lv26_199.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1439_fu_2895_p0.read()) * sc_biguint<26>(ap_const_lv26_199);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1440_fu_1937_p0() {
    mul_ln1118_1440_fu_1937_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1440_fu_1937_p2() {
    mul_ln1118_1440_fu_1937_p2 = (!mul_ln1118_1440_fu_1937_p0.read().is_01() || !ap_const_lv25_95.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1440_fu_1937_p0.read()) * sc_biguint<25>(ap_const_lv25_95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1441_fu_3497_p0() {
    mul_ln1118_1441_fu_3497_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1441_fu_3497_p2() {
    mul_ln1118_1441_fu_3497_p2 = (!mul_ln1118_1441_fu_3497_p0.read().is_01() || !ap_const_lv25_93.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1441_fu_3497_p0.read()) * sc_biguint<25>(ap_const_lv25_93);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1442_fu_3498_p0() {
    mul_ln1118_1442_fu_3498_p0 =  (sc_lv<16>) (sext_ln1118_1005_fu_10333050_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1442_fu_3498_p2() {
    mul_ln1118_1442_fu_3498_p2 = (!mul_ln1118_1442_fu_3498_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1442_fu_3498_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1443_fu_3009_p0() {
    mul_ln1118_1443_fu_3009_p0 =  (sc_lv<16>) (sext_ln1118_1003_fu_10333032_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1443_fu_3009_p2() {
    mul_ln1118_1443_fu_3009_p2 = (!mul_ln1118_1443_fu_3009_p0.read().is_01() || !ap_const_lv25_1FFFF77.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1443_fu_3009_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1444_fu_1941_p0() {
    mul_ln1118_1444_fu_1941_p0 =  (sc_lv<16>) (sext_ln1118_1023_fu_10333635_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1444_fu_1941_p2() {
    mul_ln1118_1444_fu_1941_p2 = (!mul_ln1118_1444_fu_1941_p0.read().is_01() || !ap_const_lv22_3FFFEB.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1444_fu_1941_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1445_fu_3501_p0() {
    mul_ln1118_1445_fu_3501_p0 =  (sc_lv<16>) (sext_ln1118_1022_fu_10333626_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1445_fu_3501_p2() {
    mul_ln1118_1445_fu_3501_p2 = (!mul_ln1118_1445_fu_3501_p0.read().is_01() || !ap_const_lv24_FFFFA5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1445_fu_3501_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1446_fu_3502_p0() {
    mul_ln1118_1446_fu_3502_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1446_fu_3502_p2() {
    mul_ln1118_1446_fu_3502_p2 = (!mul_ln1118_1446_fu_3502_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1446_fu_3502_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1447_fu_3013_p0() {
    mul_ln1118_1447_fu_3013_p0 =  (sc_lv<16>) (sext_ln1118_1022_fu_10333626_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1447_fu_3013_p2() {
    mul_ln1118_1447_fu_3013_p2 = (!mul_ln1118_1447_fu_3013_p0.read().is_01() || !ap_const_lv24_FFFF91.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1447_fu_3013_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1448_fu_3504_p0() {
    mul_ln1118_1448_fu_3504_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1448_fu_3504_p2() {
    mul_ln1118_1448_fu_3504_p2 = (!mul_ln1118_1448_fu_3504_p0.read().is_01() || !ap_const_lv25_1FFFF79.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1448_fu_3504_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF79);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1449_fu_3505_p0() {
    mul_ln1118_1449_fu_3505_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1449_fu_3505_p2() {
    mul_ln1118_1449_fu_3505_p2 = (!mul_ln1118_1449_fu_3505_p0.read().is_01() || !ap_const_lv25_CE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1449_fu_3505_p0.read()) * sc_biguint<25>(ap_const_lv25_CE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1450_fu_1947_p0() {
    mul_ln1118_1450_fu_1947_p0 =  (sc_lv<16>) (sext_ln1118_1022_fu_10333626_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1450_fu_1947_p2() {
    mul_ln1118_1450_fu_1947_p2 = (!mul_ln1118_1450_fu_1947_p0.read().is_01() || !ap_const_lv24_69.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1450_fu_1947_p0.read()) * sc_biguint<24>(ap_const_lv24_69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1451_fu_1948_p0() {
    mul_ln1118_1451_fu_1948_p0 =  (sc_lv<16>) (sext_ln1118_1022_fu_10333626_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1451_fu_1948_p2() {
    mul_ln1118_1451_fu_1948_p2 = (!mul_ln1118_1451_fu_1948_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1451_fu_1948_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1452_fu_1949_p0() {
    mul_ln1118_1452_fu_1949_p0 =  (sc_lv<16>) (sext_ln1118_1025_fu_10333645_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1452_fu_1949_p2() {
    mul_ln1118_1452_fu_1949_p2 = (!mul_ln1118_1452_fu_1949_p0.read().is_01() || !ap_const_lv23_34.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1452_fu_1949_p0.read()) * sc_biguint<23>(ap_const_lv23_34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1453_fu_3019_p0() {
    mul_ln1118_1453_fu_3019_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1453_fu_3019_p2() {
    mul_ln1118_1453_fu_3019_p2 = (!mul_ln1118_1453_fu_3019_p0.read().is_01() || !ap_const_lv25_1FFFF7D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1453_fu_3019_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1454_fu_3510_p0() {
    mul_ln1118_1454_fu_3510_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1454_fu_3510_p2() {
    mul_ln1118_1454_fu_3510_p2 = (!mul_ln1118_1454_fu_3510_p0.read().is_01() || !ap_const_lv25_1FFFF50.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1454_fu_3510_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF50);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1455_fu_1952_p0() {
    mul_ln1118_1455_fu_1952_p0 =  (sc_lv<16>) (sext_ln1118_1023_fu_10333635_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1455_fu_1952_p2() {
    mul_ln1118_1455_fu_1952_p2 = (!mul_ln1118_1455_fu_1952_p0.read().is_01() || !ap_const_lv22_3FFFEA.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1455_fu_1952_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1456_fu_3651_p0() {
    mul_ln1118_1456_fu_3651_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1456_fu_3651_p2() {
    mul_ln1118_1456_fu_3651_p2 = (!mul_ln1118_1456_fu_3651_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1456_fu_3651_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1457_fu_2861_p0() {
    mul_ln1118_1457_fu_2861_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1457_fu_2861_p2() {
    mul_ln1118_1457_fu_2861_p2 = (!mul_ln1118_1457_fu_2861_p0.read().is_01() || !ap_const_lv25_1FFFF3F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1457_fu_2861_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1458_fu_2071_p0() {
    mul_ln1118_1458_fu_2071_p0 =  (sc_lv<16>) (sext_ln1118_1025_fu_10333645_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1458_fu_2071_p2() {
    mul_ln1118_1458_fu_2071_p2 = (!mul_ln1118_1458_fu_2071_p0.read().is_01() || !ap_const_lv23_2D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_1458_fu_2071_p0.read()) * sc_biguint<23>(ap_const_lv23_2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1459_fu_2539_p0() {
    mul_ln1118_1459_fu_2539_p0 =  (sc_lv<16>) (sext_ln1118_1022_fu_10333626_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1459_fu_2539_p2() {
    mul_ln1118_1459_fu_2539_p2 = (!mul_ln1118_1459_fu_2539_p0.read().is_01() || !ap_const_lv24_45.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1459_fu_2539_p0.read()) * sc_biguint<24>(ap_const_lv24_45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1460_fu_1749_p0() {
    mul_ln1118_1460_fu_1749_p0 =  (sc_lv<16>) (sext_ln1118_1021_fu_10333614_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1460_fu_1749_p2() {
    mul_ln1118_1460_fu_1749_p2 = (!mul_ln1118_1460_fu_1749_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_1460_fu_1749_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1461_fu_2846_p0() {
    mul_ln1118_1461_fu_2846_p0 = sext_ln1118_1035_fu_10334111_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1461_fu_2846_p2() {
    mul_ln1118_1461_fu_2846_p2 = (!mul_ln1118_1461_fu_2846_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_1461_fu_2846_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1462_fu_3314_p0() {
    mul_ln1118_1462_fu_3314_p0 =  (sc_lv<16>) (sext_ln1118_1034_fu_10334105_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1462_fu_3314_p2() {
    mul_ln1118_1462_fu_3314_p2 = (!mul_ln1118_1462_fu_3314_p0.read().is_01() || !ap_const_lv26_3FFFE8D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_1462_fu_3314_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1463_fu_3153_p0() {
    mul_ln1118_1463_fu_3153_p0 =  (sc_lv<16>) (sext_ln1118_1033_fu_10334094_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_1::thread_mul_ln1118_1463_fu_3153_p2() {
    mul_ln1118_1463_fu_3153_p2 = (!mul_ln1118_1463_fu_3153_p0.read().is_01() || !ap_const_lv24_6D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_1463_fu_3153_p0.read()) * sc_biguint<24>(ap_const_lv24_6D);
}

}

