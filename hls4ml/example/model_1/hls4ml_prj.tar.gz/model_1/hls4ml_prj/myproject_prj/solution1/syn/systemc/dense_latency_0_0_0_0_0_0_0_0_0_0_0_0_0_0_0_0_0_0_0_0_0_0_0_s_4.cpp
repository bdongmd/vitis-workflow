#include "dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_0() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_0 = ap_return_0_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_0 = add_ln703_2883_fu_2639097_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_1() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_1 = ap_return_1_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_1 = acc_1_V_fu_2639106_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_10() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_10 = ap_return_10_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_10 = acc_10_V_fu_2639207_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_11() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_11 = ap_return_11_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_11 = acc_11_V_reg_2639832.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_12() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_12 = ap_return_12_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_12 = acc_12_V_fu_2639216_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_13() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_13 = ap_return_13_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_13 = acc_13_V_fu_2639234_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_14() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_14 = ap_return_14_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_14 = acc_14_V_fu_2639253_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_15() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_15 = ap_return_15_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_15 = acc_15_V_fu_2639263_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_16() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_16 = ap_return_16_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_16 = acc_16_V_fu_2639281_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_17() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_17 = ap_return_17_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_17 = acc_17_V_fu_2639300_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_18() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_18 = ap_return_18_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_18 = acc_18_V_fu_2639310_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_19() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_19 = ap_return_19_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_19 = acc_19_V_fu_2639328_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_2() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_2 = ap_return_2_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_2 = acc_2_V_fu_2639115_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_20() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_20 = ap_return_20_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_20 = acc_20_V_fu_2639347_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_21() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_21 = ap_return_21_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_21 = acc_21_V_fu_2639357_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_22() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_22 = ap_return_22_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_22 = acc_22_V_fu_2639366_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_23() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_23 = ap_return_23_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_23 = sext_ln703_635_fu_2639371_p1.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_24() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_24 = ap_return_24_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_24 = acc_24_V_fu_2639378_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_25() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_25 = ap_return_25_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_25 = acc_25_V_fu_2639387_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_26() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_26 = ap_return_26_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_26 = acc_26_V_fu_2639396_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_27() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_27 = ap_return_27_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_27 = acc_27_V_fu_2639405_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_28() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_28 = ap_return_28_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_28 = acc_28_V_fu_2639423_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_29() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_29 = ap_return_29_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_29 = acc_29_V_fu_2639433_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_3() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_3 = ap_return_3_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_3 = acc_3_V_fu_2639124_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_30() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_30 = ap_return_30_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_30 = acc_30_V_fu_2639442_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_31() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_31 = ap_return_31_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_31 = acc_31_V_fu_2639451_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_4() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_4 = ap_return_4_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_4 = acc_4_V_fu_2639133_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_5() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_5 = ap_return_5_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_5 = acc_5_V_fu_2639142_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_6() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_6 = ap_return_6_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_6 = acc_6_V_fu_2639151_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_7() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_7 = ap_return_7_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_7 = acc_7_V_fu_2639169_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_8() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_8 = ap_return_8_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_8 = acc_8_V_fu_2639188_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_ap_return_9() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_ce_reg.read())) {
        ap_return_9 = ap_return_9_int_reg.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_ce_reg.read())) {
        ap_return_9 = acc_9_V_fu_2639198_p2.read();
    }
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_100_fu_1609_p0() {
    mul_ln1118_100_fu_1609_p0 =  (sc_lv<16>) (sext_ln1118_59_fu_2618140_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_100_fu_1609_p2() {
    mul_ln1118_100_fu_1609_p2 = (!mul_ln1118_100_fu_1609_p0.read().is_01() || !ap_const_lv25_A6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_100_fu_1609_p0.read()) * sc_biguint<25>(ap_const_lv25_A6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_101_fu_2323_p0() {
    mul_ln1118_101_fu_2323_p0 =  (sc_lv<16>) (sext_ln1118_59_fu_2618140_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_101_fu_2323_p2() {
    mul_ln1118_101_fu_2323_p2 = (!mul_ln1118_101_fu_2323_p0.read().is_01() || !ap_const_lv25_AA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_101_fu_2323_p0.read()) * sc_biguint<25>(ap_const_lv25_AA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_102_fu_2196_p0() {
    mul_ln1118_102_fu_2196_p0 =  (sc_lv<16>) (sext_ln1118_59_fu_2618140_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_102_fu_2196_p2() {
    mul_ln1118_102_fu_2196_p2 = (!mul_ln1118_102_fu_2196_p0.read().is_01() || !ap_const_lv25_C9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_102_fu_2196_p0.read()) * sc_biguint<25>(ap_const_lv25_C9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_103_fu_1921_p0() {
    mul_ln1118_103_fu_1921_p0 =  (sc_lv<16>) (sext_ln1118_80_fu_2618786_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_103_fu_1921_p2() {
    mul_ln1118_103_fu_1921_p2 = (!mul_ln1118_103_fu_1921_p0.read().is_01() || !ap_const_lv24_FFFF95.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_103_fu_1921_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_104_fu_1951_p0() {
    mul_ln1118_104_fu_1951_p0 = sext_ln1118_79_fu_2618781_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_104_fu_1951_p2() {
    mul_ln1118_104_fu_1951_p2 = (!mul_ln1118_104_fu_1951_p0.read().is_01() || !ap_const_lv22_3FFFE5.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_104_fu_1951_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_105_fu_1884_p0() {
    mul_ln1118_105_fu_1884_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_105_fu_1884_p2() {
    mul_ln1118_105_fu_1884_p2 = (!mul_ln1118_105_fu_1884_p0.read().is_01() || !ap_const_lv26_3FFFDF2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_105_fu_1884_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDF2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_106_fu_1817_p0() {
    mul_ln1118_106_fu_1817_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_106_fu_1817_p2() {
    mul_ln1118_106_fu_1817_p2 = (!mul_ln1118_106_fu_1817_p0.read().is_01() || !ap_const_lv25_1FFFF14.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_106_fu_1817_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF14);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_107_fu_1653_p0() {
    mul_ln1118_107_fu_1653_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_107_fu_1653_p2() {
    mul_ln1118_107_fu_1653_p2 = (!mul_ln1118_107_fu_1653_p0.read().is_01() || !ap_const_lv25_91.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_107_fu_1653_p0.read()) * sc_biguint<25>(ap_const_lv25_91);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_108_fu_2321_p0() {
    mul_ln1118_108_fu_2321_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_108_fu_2321_p2() {
    mul_ln1118_108_fu_2321_p2 = (!mul_ln1118_108_fu_2321_p0.read().is_01() || !ap_const_lv25_1FFFF0B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_108_fu_2321_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_109_fu_1935_p0() {
    mul_ln1118_109_fu_1935_p0 =  (sc_lv<16>) (sext_ln1118_76_fu_2618752_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_109_fu_1935_p2() {
    mul_ln1118_109_fu_1935_p2 = (!mul_ln1118_109_fu_1935_p0.read().is_01() || !ap_const_lv23_7FFFCE.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_109_fu_1935_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_10_fu_2023_p0() {
    mul_ln1118_10_fu_2023_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_10_fu_2023_p2() {
    mul_ln1118_10_fu_2023_p2 = (!mul_ln1118_10_fu_2023_p0.read().is_01() || !ap_const_lv26_10F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_10_fu_2023_p0.read()) * sc_biguint<26>(ap_const_lv26_10F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_110_fu_1549_p0() {
    mul_ln1118_110_fu_1549_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_110_fu_1549_p2() {
    mul_ln1118_110_fu_1549_p2 = (!mul_ln1118_110_fu_1549_p0.read().is_01() || !ap_const_lv26_19B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_110_fu_1549_p0.read()) * sc_biguint<26>(ap_const_lv26_19B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_111_fu_2120_p0() {
    mul_ln1118_111_fu_2120_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_111_fu_2120_p2() {
    mul_ln1118_111_fu_2120_p2 = (!mul_ln1118_111_fu_2120_p0.read().is_01() || !ap_const_lv25_1FFFF45.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_111_fu_2120_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_112_fu_1415_p0() {
    mul_ln1118_112_fu_1415_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_112_fu_1415_p2() {
    mul_ln1118_112_fu_1415_p2 = (!mul_ln1118_112_fu_1415_p0.read().is_01() || !ap_const_lv25_BB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_112_fu_1415_p0.read()) * sc_biguint<25>(ap_const_lv25_BB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_113_fu_2305_p0() {
    mul_ln1118_113_fu_2305_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_113_fu_2305_p2() {
    mul_ln1118_113_fu_2305_p2 = (!mul_ln1118_113_fu_2305_p0.read().is_01() || !ap_const_lv26_14D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_113_fu_2305_p0.read()) * sc_biguint<26>(ap_const_lv26_14D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_114_fu_2238_p0() {
    mul_ln1118_114_fu_2238_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_114_fu_2238_p2() {
    mul_ln1118_114_fu_2238_p2 = (!mul_ln1118_114_fu_2238_p0.read().is_01() || !ap_const_lv26_3FFFEBA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_114_fu_2238_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_115_fu_1852_p0() {
    mul_ln1118_115_fu_1852_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_115_fu_1852_p2() {
    mul_ln1118_115_fu_1852_p2 = (!mul_ln1118_115_fu_1852_p0.read().is_01() || !ap_const_lv26_185.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_115_fu_1852_p0.read()) * sc_biguint<26>(ap_const_lv26_185);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_116_fu_1915_p0() {
    mul_ln1118_116_fu_1915_p0 =  (sc_lv<16>) (sext_ln1118_80_fu_2618786_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_116_fu_1915_p2() {
    mul_ln1118_116_fu_1915_p2 = (!mul_ln1118_116_fu_1915_p0.read().is_01() || !ap_const_lv24_FFFF85.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_116_fu_1915_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_117_fu_1553_p0() {
    mul_ln1118_117_fu_1553_p0 =  (sc_lv<16>) (sext_ln1118_76_fu_2618752_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_117_fu_1553_p2() {
    mul_ln1118_117_fu_1553_p2 = (!mul_ln1118_117_fu_1553_p0.read().is_01() || !ap_const_lv23_7FFFC7.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_117_fu_1553_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_118_fu_2069_p0() {
    mul_ln1118_118_fu_2069_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_118_fu_2069_p2() {
    mul_ln1118_118_fu_2069_p2 = (!mul_ln1118_118_fu_2069_p0.read().is_01() || !ap_const_lv26_3FFFE88.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_118_fu_2069_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE88);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_119_fu_2070_p0() {
    mul_ln1118_119_fu_2070_p0 =  (sc_lv<16>) (sext_ln1118_76_fu_2618752_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_119_fu_2070_p2() {
    mul_ln1118_119_fu_2070_p2 = (!mul_ln1118_119_fu_2070_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_119_fu_2070_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_11_fu_2180_p0() {
    mul_ln1118_11_fu_2180_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_11_fu_2180_p2() {
    mul_ln1118_11_fu_2180_p2 = (!mul_ln1118_11_fu_2180_p0.read().is_01() || !ap_const_lv26_3FFFEBE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_11_fu_2180_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_120_fu_1358_p0() {
    mul_ln1118_120_fu_1358_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_120_fu_1358_p2() {
    mul_ln1118_120_fu_1358_p2 = (!mul_ln1118_120_fu_1358_p0.read().is_01() || !ap_const_lv25_E3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_120_fu_1358_p0.read()) * sc_biguint<25>(ap_const_lv25_E3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_121_fu_2072_p0() {
    mul_ln1118_121_fu_2072_p0 =  (sc_lv<16>) (sext_ln1118_78_fu_2618770_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_121_fu_2072_p2() {
    mul_ln1118_121_fu_2072_p2 = (!mul_ln1118_121_fu_2072_p0.read().is_01() || !ap_const_lv26_3FFFEF1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_121_fu_2072_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_122_fu_1672_p0() {
    mul_ln1118_122_fu_1672_p0 =  (sc_lv<16>) (sext_ln1118_80_fu_2618786_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_122_fu_1672_p2() {
    mul_ln1118_122_fu_1672_p2 = (!mul_ln1118_122_fu_1672_p0.read().is_01() || !ap_const_lv24_FFFF83.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_122_fu_1672_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_123_fu_1361_p0() {
    mul_ln1118_123_fu_1361_p0 =  (sc_lv<16>) (sext_ln1118_77_fu_2618759_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_123_fu_1361_p2() {
    mul_ln1118_123_fu_1361_p2 = (!mul_ln1118_123_fu_1361_p0.read().is_01() || !ap_const_lv25_1FFFF4D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_123_fu_1361_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_124_fu_1919_p0() {
    mul_ln1118_124_fu_1919_p0 = sext_ln1118_92_fu_2619230_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_124_fu_1919_p2() {
    mul_ln1118_124_fu_1919_p2 = (!mul_ln1118_124_fu_1919_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_124_fu_1919_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_125_fu_2232_p0() {
    mul_ln1118_125_fu_2232_p0 =  (sc_lv<16>) (sext_ln1118_87_fu_2619198_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_125_fu_2232_p2() {
    mul_ln1118_125_fu_2232_p2 = (!mul_ln1118_125_fu_2232_p0.read().is_01() || !ap_const_lv25_8F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_125_fu_2232_p0.read()) * sc_biguint<25>(ap_const_lv25_8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_126_fu_2077_p0() {
    mul_ln1118_126_fu_2077_p0 =  (sc_lv<16>) (sext_ln1118_88_fu_2619207_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_126_fu_2077_p2() {
    mul_ln1118_126_fu_2077_p2 = (!mul_ln1118_126_fu_2077_p0.read().is_01() || !ap_const_lv24_55.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_126_fu_2077_p0.read()) * sc_biguint<24>(ap_const_lv24_55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_127_fu_1928_p0() {
    mul_ln1118_127_fu_1928_p0 =  (sc_lv<16>) (sext_ln1118_88_fu_2619207_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_127_fu_1928_p2() {
    mul_ln1118_127_fu_1928_p2 = (!mul_ln1118_127_fu_1928_p0.read().is_01() || !ap_const_lv24_56.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_127_fu_1928_p0.read()) * sc_biguint<24>(ap_const_lv24_56);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_128_fu_2235_p0() {
    mul_ln1118_128_fu_2235_p0 =  (sc_lv<16>) (sext_ln1118_91_fu_2619225_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_128_fu_2235_p2() {
    mul_ln1118_128_fu_2235_p2 = (!mul_ln1118_128_fu_2235_p0.read().is_01() || !ap_const_lv23_26.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_128_fu_2235_p0.read()) * sc_biguint<23>(ap_const_lv23_26);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_129_fu_2080_p0() {
    mul_ln1118_129_fu_2080_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_129_fu_2080_p2() {
    mul_ln1118_129_fu_2080_p2 = (!mul_ln1118_129_fu_2080_p0.read().is_01() || !ap_const_lv26_3FFFECE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_129_fu_2080_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_130_fu_1420_p0() {
    mul_ln1118_130_fu_1420_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_130_fu_1420_p2() {
    mul_ln1118_130_fu_1420_p2 = (!mul_ln1118_130_fu_1420_p0.read().is_01() || !ap_const_lv26_3FFFEE6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_130_fu_1420_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_131_fu_2310_p0() {
    mul_ln1118_131_fu_2310_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_131_fu_2310_p2() {
    mul_ln1118_131_fu_2310_p2 = (!mul_ln1118_131_fu_2310_p0.read().is_01() || !ap_const_lv26_3FFFD89.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_131_fu_2310_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD89);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_132_fu_1605_p0() {
    mul_ln1118_132_fu_1605_p0 =  (sc_lv<16>) (sext_ln1118_88_fu_2619207_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_132_fu_1605_p2() {
    mul_ln1118_132_fu_1605_p2 = (!mul_ln1118_132_fu_1605_p0.read().is_01() || !ap_const_lv24_69.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_132_fu_1605_p0.read()) * sc_biguint<24>(ap_const_lv24_69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_133_fu_1538_p0() {
    mul_ln1118_133_fu_1538_p0 =  (sc_lv<16>) (sext_ln1118_87_fu_2619198_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_133_fu_1538_p2() {
    mul_ln1118_133_fu_1538_p2 = (!mul_ln1118_133_fu_1538_p0.read().is_01() || !ap_const_lv25_1FFFF34.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_133_fu_1538_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_134_fu_1897_p0() {
    mul_ln1118_134_fu_1897_p0 = sext_ln1118_89_fu_2619216_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_134_fu_1897_p2() {
    mul_ln1118_134_fu_1897_p2 = (!mul_ln1118_134_fu_1897_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_134_fu_1897_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_135_fu_2264_p0() {
    mul_ln1118_135_fu_2264_p0 =  (sc_lv<16>) (sext_ln1118_87_fu_2619198_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_135_fu_2264_p2() {
    mul_ln1118_135_fu_2264_p2 = (!mul_ln1118_135_fu_2264_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_135_fu_2264_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_136_fu_1337_p0() {
    mul_ln1118_136_fu_1337_p0 =  (sc_lv<16>) (sext_ln1118_87_fu_2619198_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_136_fu_1337_p2() {
    mul_ln1118_136_fu_1337_p2 = (!mul_ln1118_136_fu_1337_p0.read().is_01() || !ap_const_lv25_D8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_136_fu_1337_p0.read()) * sc_biguint<25>(ap_const_lv25_D8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_137_fu_1908_p0() {
    mul_ln1118_137_fu_1908_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_137_fu_1908_p2() {
    mul_ln1118_137_fu_1908_p2 = (!mul_ln1118_137_fu_1908_p0.read().is_01() || !ap_const_lv26_3FFFCFA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_137_fu_1908_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCFA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_138_fu_2160_p0() {
    mul_ln1118_138_fu_2160_p0 =  (sc_lv<16>) (sext_ln1118_88_fu_2619207_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_138_fu_2160_p2() {
    mul_ln1118_138_fu_2160_p2 = (!mul_ln1118_138_fu_2160_p0.read().is_01() || !ap_const_lv24_77.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_138_fu_2160_p0.read()) * sc_biguint<24>(ap_const_lv24_77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_139_fu_1455_p0() {
    mul_ln1118_139_fu_1455_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_139_fu_1455_p2() {
    mul_ln1118_139_fu_1455_p2 = (!mul_ln1118_139_fu_1455_p0.read().is_01() || !ap_const_lv26_3FFFEF1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_139_fu_1455_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_13_fu_1869_p0() {
    mul_ln1118_13_fu_1869_p0 = sext_ln1118_10_fu_2616005_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_13_fu_1869_p2() {
    mul_ln1118_13_fu_1869_p2 = (!mul_ln1118_13_fu_1869_p0.read().is_01() || !ap_const_lv24_45.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_13_fu_1869_p0.read()) * sc_biguint<24>(ap_const_lv24_45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_140_fu_1707_p0() {
    mul_ln1118_140_fu_1707_p0 =  (sc_lv<16>) (sext_ln1118_88_fu_2619207_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_140_fu_1707_p2() {
    mul_ln1118_140_fu_1707_p2 = (!mul_ln1118_140_fu_1707_p0.read().is_01() || !ap_const_lv24_43.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_140_fu_1707_p0.read()) * sc_biguint<24>(ap_const_lv24_43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_141_fu_1959_p0() {
    mul_ln1118_141_fu_1959_p0 =  (sc_lv<16>) (sext_ln1118_87_fu_2619198_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_141_fu_1959_p2() {
    mul_ln1118_141_fu_1959_p2 = (!mul_ln1118_141_fu_1959_p0.read().is_01() || !ap_const_lv25_1FFFF0C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_141_fu_1959_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_142_fu_1365_p0() {
    mul_ln1118_142_fu_1365_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_142_fu_1365_p2() {
    mul_ln1118_142_fu_1365_p2 = (!mul_ln1118_142_fu_1365_p0.read().is_01() || !ap_const_lv26_3FFFD44.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_142_fu_1365_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD44);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_143_fu_1506_p0() {
    mul_ln1118_143_fu_1506_p0 =  (sc_lv<16>) (sext_ln1118_86_fu_2619187_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_143_fu_1506_p2() {
    mul_ln1118_143_fu_1506_p2 = (!mul_ln1118_143_fu_1506_p0.read().is_01() || !ap_const_lv26_3FFFE77.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_143_fu_1506_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_144_fu_1711_p0() {
    mul_ln1118_144_fu_1711_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_144_fu_1711_p2() {
    mul_ln1118_144_fu_1711_p2 = (!mul_ln1118_144_fu_1711_p0.read().is_01() || !ap_const_lv26_3FFFD20.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_144_fu_1711_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD20);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_145_fu_1349_p0() {
    mul_ln1118_145_fu_1349_p0 =  (sc_lv<16>) (sext_ln1118_104_fu_2619761_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_145_fu_1349_p2() {
    mul_ln1118_145_fu_1349_p2 = (!mul_ln1118_145_fu_1349_p0.read().is_01() || !ap_const_lv25_B4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_145_fu_1349_p0.read()) * sc_biguint<25>(ap_const_lv25_B4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_146_fu_2138_p0() {
    mul_ln1118_146_fu_2138_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_146_fu_2138_p2() {
    mul_ln1118_146_fu_2138_p2 = (!mul_ln1118_146_fu_2138_p0.read().is_01() || !ap_const_lv26_3FFFEAB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_146_fu_2138_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_147_fu_2295_p0() {
    mul_ln1118_147_fu_2295_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_147_fu_2295_p2() {
    mul_ln1118_147_fu_2295_p2 = (!mul_ln1118_147_fu_2295_p0.read().is_01() || !ap_const_lv26_3FFFD70.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_147_fu_2295_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD70);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_148_fu_2140_p0() {
    mul_ln1118_148_fu_2140_p0 =  (sc_lv<16>) (sext_ln1118_107_fu_2619791_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_148_fu_2140_p2() {
    mul_ln1118_148_fu_2140_p2 = (!mul_ln1118_148_fu_2140_p0.read().is_01() || !ap_const_lv23_36.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_148_fu_2140_p0.read()) * sc_biguint<23>(ap_const_lv23_36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_149_fu_1428_p0() {
    mul_ln1118_149_fu_1428_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_149_fu_1428_p2() {
    mul_ln1118_149_fu_1428_p2 = (!mul_ln1118_149_fu_1428_p0.read().is_01() || !ap_const_lv26_3FFFEEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_149_fu_1428_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_14_fu_2026_p0() {
    mul_ln1118_14_fu_2026_p0 = sext_ln1118_fu_2615966_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_14_fu_2026_p2() {
    mul_ln1118_14_fu_2026_p2 = (!mul_ln1118_14_fu_2026_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_14_fu_2026_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_150_fu_2298_p0() {
    mul_ln1118_150_fu_2298_p0 =  (sc_lv<16>) (sext_ln1118_107_fu_2619791_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_150_fu_2298_p2() {
    mul_ln1118_150_fu_2298_p2 = (!mul_ln1118_150_fu_2298_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_150_fu_2298_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_151_fu_2299_p0() {
    mul_ln1118_151_fu_2299_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_151_fu_2299_p2() {
    mul_ln1118_151_fu_2299_p2 = (!mul_ln1118_151_fu_2299_p0.read().is_01() || !ap_const_lv26_3FFFCD9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_151_fu_2299_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_152_fu_2144_p0() {
    mul_ln1118_152_fu_2144_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_152_fu_2144_p2() {
    mul_ln1118_152_fu_2144_p2 = (!mul_ln1118_152_fu_2144_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_152_fu_2144_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_153_fu_2301_p0() {
    mul_ln1118_153_fu_2301_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_153_fu_2301_p2() {
    mul_ln1118_153_fu_2301_p2 = (!mul_ln1118_153_fu_2301_p0.read().is_01() || !ap_const_lv24_46.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_153_fu_2301_p0.read()) * sc_biguint<24>(ap_const_lv24_46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_154_fu_2146_p0() {
    mul_ln1118_154_fu_2146_p0 =  (sc_lv<16>) (sext_ln1118_104_fu_2619761_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_154_fu_2146_p2() {
    mul_ln1118_154_fu_2146_p2 = (!mul_ln1118_154_fu_2146_p0.read().is_01() || !ap_const_lv25_FA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_154_fu_2146_p0.read()) * sc_biguint<25>(ap_const_lv25_FA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_155_fu_1434_p0() {
    mul_ln1118_155_fu_1434_p0 =  (sc_lv<16>) (sext_ln1118_104_fu_2619761_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_155_fu_1434_p2() {
    mul_ln1118_155_fu_1434_p2 = (!mul_ln1118_155_fu_1434_p0.read().is_01() || !ap_const_lv25_1FFFF7D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_155_fu_1434_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_156_fu_2148_p0() {
    mul_ln1118_156_fu_2148_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_156_fu_2148_p2() {
    mul_ln1118_156_fu_2148_p2 = (!mul_ln1118_156_fu_2148_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_156_fu_2148_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_157_fu_1592_p0() {
    mul_ln1118_157_fu_1592_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_157_fu_1592_p2() {
    mul_ln1118_157_fu_1592_p2 = (!mul_ln1118_157_fu_1592_p0.read().is_01() || !ap_const_lv26_3FFFDE6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_157_fu_1592_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_158_fu_2142_p0() {
    mul_ln1118_158_fu_2142_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_158_fu_2142_p2() {
    mul_ln1118_158_fu_2142_p2 = (!mul_ln1118_158_fu_2142_p0.read().is_01() || !ap_const_lv24_57.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_158_fu_2142_p0.read()) * sc_biguint<24>(ap_const_lv24_57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_159_fu_2075_p0() {
    mul_ln1118_159_fu_2075_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_159_fu_2075_p2() {
    mul_ln1118_159_fu_2075_p2 = (!mul_ln1118_159_fu_2075_p0.read().is_01() || !ap_const_lv26_3FFFE6C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_159_fu_2075_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE6C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_15_fu_2027_p0() {
    mul_ln1118_15_fu_2027_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_15_fu_2027_p2() {
    mul_ln1118_15_fu_2027_p2 = (!mul_ln1118_15_fu_2027_p0.read().is_01() || !ap_const_lv26_1D4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_15_fu_2027_p0.read()) * sc_biguint<26>(ap_const_lv26_1D4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_160_fu_1689_p0() {
    mul_ln1118_160_fu_1689_p0 =  (sc_lv<16>) (sext_ln1118_104_fu_2619761_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_160_fu_1689_p2() {
    mul_ln1118_160_fu_1689_p2 = (!mul_ln1118_160_fu_1689_p0.read().is_01() || !ap_const_lv25_1FFFF6A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_160_fu_1689_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_161_fu_1622_p0() {
    mul_ln1118_161_fu_1622_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_161_fu_1622_p2() {
    mul_ln1118_161_fu_1622_p2 = (!mul_ln1118_161_fu_1622_p0.read().is_01() || !ap_const_lv24_62.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_161_fu_1622_p0.read()) * sc_biguint<24>(ap_const_lv24_62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_162_fu_2193_p0() {
    mul_ln1118_162_fu_2193_p0 =  (sc_lv<16>) (sext_ln1118_107_fu_2619791_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_162_fu_2193_p2() {
    mul_ln1118_162_fu_2193_p2 = (!mul_ln1118_162_fu_2193_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_162_fu_2193_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_163_fu_2126_p0() {
    mul_ln1118_163_fu_2126_p0 =  (sc_lv<16>) (sext_ln1118_106_fu_2619781_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_163_fu_2126_p2() {
    mul_ln1118_163_fu_2126_p2 = (!mul_ln1118_163_fu_2126_p0.read().is_01() || !ap_const_lv24_74.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_163_fu_2126_p0.read()) * sc_biguint<24>(ap_const_lv24_74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_164_fu_2059_p0() {
    mul_ln1118_164_fu_2059_p0 =  (sc_lv<16>) (sext_ln1118_105_fu_2619769_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_164_fu_2059_p2() {
    mul_ln1118_164_fu_2059_p2 = (!mul_ln1118_164_fu_2059_p0.read().is_01() || !ap_const_lv26_166.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_164_fu_2059_p0.read()) * sc_biguint<26>(ap_const_lv26_166);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_165_fu_2103_p0() {
    mul_ln1118_165_fu_2103_p0 =  (sc_lv<16>) (sext_ln708_130_fu_2620397_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_165_fu_2103_p2() {
    mul_ln1118_165_fu_2103_p2 = (!mul_ln1118_165_fu_2103_p0.read().is_01() || !ap_const_lv24_FFFF8A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_165_fu_2103_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_166_fu_1925_p0() {
    mul_ln1118_166_fu_1925_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_166_fu_1925_p2() {
    mul_ln1118_166_fu_1925_p2 = (!mul_ln1118_166_fu_1925_p0.read().is_01() || !ap_const_lv25_1FFFF3F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_166_fu_1925_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_167_fu_2177_p0() {
    mul_ln1118_167_fu_2177_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_167_fu_2177_p2() {
    mul_ln1118_167_fu_2177_p2 = (!mul_ln1118_167_fu_2177_p0.read().is_01() || !ap_const_lv26_129.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_167_fu_2177_p0.read()) * sc_biguint<26>(ap_const_lv26_129);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_168_fu_2221_p0() {
    mul_ln1118_168_fu_2221_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_168_fu_2221_p2() {
    mul_ln1118_168_fu_2221_p2 = (!mul_ln1118_168_fu_2221_p0.read().is_01() || !ap_const_lv25_1FFFF55.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_168_fu_2221_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_169_fu_1724_p0() {
    mul_ln1118_169_fu_1724_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_169_fu_1724_p2() {
    mul_ln1118_169_fu_1724_p2 = (!mul_ln1118_169_fu_1724_p0.read().is_01() || !ap_const_lv25_8C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_169_fu_1724_p0.read()) * sc_biguint<25>(ap_const_lv25_8C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_16_fu_2184_p0() {
    mul_ln1118_16_fu_2184_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_16_fu_2184_p2() {
    mul_ln1118_16_fu_2184_p2 = (!mul_ln1118_16_fu_2184_p0.read().is_01() || !ap_const_lv26_18E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_16_fu_2184_p0.read()) * sc_biguint<26>(ap_const_lv26_18E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_170_fu_1657_p0() {
    mul_ln1118_170_fu_1657_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_170_fu_1657_p2() {
    mul_ln1118_170_fu_1657_p2 = (!mul_ln1118_170_fu_1657_p0.read().is_01() || !ap_const_lv25_F9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_170_fu_1657_p0.read()) * sc_biguint<25>(ap_const_lv25_F9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_171_fu_2168_p0() {
    mul_ln1118_171_fu_2168_p0 =  (sc_lv<16>) (sext_ln708_132_fu_2620409_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_171_fu_2168_p2() {
    mul_ln1118_171_fu_2168_p2 = (!mul_ln1118_171_fu_2168_p0.read().is_01() || !ap_const_lv23_7FFFCE.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_171_fu_2168_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_172_fu_1379_p0() {
    mul_ln1118_172_fu_1379_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_172_fu_1379_p2() {
    mul_ln1118_172_fu_1379_p2 = (!mul_ln1118_172_fu_1379_p0.read().is_01() || !ap_const_lv26_3FFFEA8.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_172_fu_1379_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_173_fu_1444_p0() {
    mul_ln1118_173_fu_1444_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_173_fu_1444_p2() {
    mul_ln1118_173_fu_1444_p2 = (!mul_ln1118_173_fu_1444_p0.read().is_01() || !ap_const_lv25_8F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_173_fu_1444_p0.read()) * sc_biguint<25>(ap_const_lv25_8F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_174_fu_2207_p0() {
    mul_ln1118_174_fu_2207_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_174_fu_2207_p2() {
    mul_ln1118_174_fu_2207_p2 = (!mul_ln1118_174_fu_2207_p0.read().is_01() || !ap_const_lv26_3FFFEEC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_174_fu_2207_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_175_fu_2208_p0() {
    mul_ln1118_175_fu_2208_p0 =  (sc_lv<16>) (sext_ln708_127_fu_2620366_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_175_fu_2208_p2() {
    mul_ln1118_175_fu_2208_p2 = (!mul_ln1118_175_fu_2208_p0.read().is_01() || !ap_const_lv22_19.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_175_fu_2208_p0.read()) * sc_biguint<22>(ap_const_lv22_19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_176_fu_1340_p0() {
    mul_ln1118_176_fu_1340_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_176_fu_1340_p2() {
    mul_ln1118_176_fu_1340_p2 = (!mul_ln1118_176_fu_1340_p0.read().is_01() || !ap_const_lv26_14D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_176_fu_1340_p0.read()) * sc_biguint<26>(ap_const_lv26_14D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_177_fu_2054_p0() {
    mul_ln1118_177_fu_2054_p0 =  (sc_lv<16>) (sext_ln708_127_fu_2620366_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_177_fu_2054_p2() {
    mul_ln1118_177_fu_2054_p2 = (!mul_ln1118_177_fu_2054_p0.read().is_01() || !ap_const_lv22_1A.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_177_fu_2054_p0.read()) * sc_biguint<22>(ap_const_lv22_1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_178_fu_2211_p0() {
    mul_ln1118_178_fu_2211_p0 =  (sc_lv<16>) (sext_ln708_130_fu_2620397_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_178_fu_2211_p2() {
    mul_ln1118_178_fu_2211_p2 = (!mul_ln1118_178_fu_2211_p0.read().is_01() || !ap_const_lv24_FFFF86.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_178_fu_2211_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_179_fu_2212_p0() {
    mul_ln1118_179_fu_2212_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_179_fu_2212_p2() {
    mul_ln1118_179_fu_2212_p2 = (!mul_ln1118_179_fu_2212_p0.read().is_01() || !ap_const_lv25_1FFFF64.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_179_fu_2212_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_17_fu_2210_p0() {
    mul_ln1118_17_fu_2210_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_17_fu_2210_p2() {
    mul_ln1118_17_fu_2210_p2 = (!mul_ln1118_17_fu_2210_p0.read().is_01() || !ap_const_lv26_11C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_17_fu_2210_p0.read()) * sc_biguint<26>(ap_const_lv26_11C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_180_fu_1500_p0() {
    mul_ln1118_180_fu_1500_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_180_fu_1500_p2() {
    mul_ln1118_180_fu_1500_p2 = (!mul_ln1118_180_fu_1500_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_180_fu_1500_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_181_fu_1501_p0() {
    mul_ln1118_181_fu_1501_p0 =  (sc_lv<16>) (sext_ln708_132_fu_2620409_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_181_fu_1501_p2() {
    mul_ln1118_181_fu_1501_p2 = (!mul_ln1118_181_fu_1501_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_181_fu_1501_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_182_fu_2215_p0() {
    mul_ln1118_182_fu_2215_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_182_fu_2215_p2() {
    mul_ln1118_182_fu_2215_p2 = (!mul_ln1118_182_fu_2215_p0.read().is_01() || !ap_const_lv26_3FFFEC1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_182_fu_2215_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_183_fu_2216_p0() {
    mul_ln1118_183_fu_2216_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_183_fu_2216_p2() {
    mul_ln1118_183_fu_2216_p2 = (!mul_ln1118_183_fu_2216_p0.read().is_01() || !ap_const_lv26_3FFFECB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_183_fu_2216_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_184_fu_2217_p0() {
    mul_ln1118_184_fu_2217_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_184_fu_2217_p2() {
    mul_ln1118_184_fu_2217_p2 = (!mul_ln1118_184_fu_2217_p0.read().is_01() || !ap_const_lv25_1FFFF03.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_184_fu_2217_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF03);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_185_fu_1655_p0() {
    mul_ln1118_185_fu_1655_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_185_fu_1655_p2() {
    mul_ln1118_185_fu_1655_p2 = (!mul_ln1118_185_fu_1655_p0.read().is_01() || !ap_const_lv26_177.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_185_fu_1655_p0.read()) * sc_biguint<26>(ap_const_lv26_177);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_186_fu_1907_p0() {
    mul_ln1118_186_fu_1907_p0 =  (sc_lv<16>) (sext_ln708_130_fu_2620397_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_186_fu_1907_p2() {
    mul_ln1118_186_fu_1907_p2 = (!mul_ln1118_186_fu_1907_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_186_fu_1907_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_187_fu_2159_p0() {
    mul_ln1118_187_fu_2159_p0 =  (sc_lv<16>) (sext_ln708_129_fu_2620384_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_187_fu_2159_p2() {
    mul_ln1118_187_fu_2159_p2 = (!mul_ln1118_187_fu_2159_p0.read().is_01() || !ap_const_lv25_1FFFF19.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_187_fu_2159_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF19);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_188_fu_1773_p0() {
    mul_ln1118_188_fu_1773_p0 = sext_ln708_131_fu_2620404_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_188_fu_1773_p2() {
    mul_ln1118_188_fu_1773_p2 = (!mul_ln1118_188_fu_1773_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_188_fu_1773_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_189_fu_1498_p0() {
    mul_ln1118_189_fu_1498_p0 =  (sc_lv<16>) (sext_ln708_128_fu_2620372_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_189_fu_1498_p2() {
    mul_ln1118_189_fu_1498_p2 = (!mul_ln1118_189_fu_1498_p0.read().is_01() || !ap_const_lv26_3FFFEAA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_189_fu_1498_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_18_fu_1713_p0() {
    mul_ln1118_18_fu_1713_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_18_fu_1713_p2() {
    mul_ln1118_18_fu_1713_p2 = (!mul_ln1118_18_fu_1713_p0.read().is_01() || !ap_const_lv26_3FFFED0.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_18_fu_1713_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_190_fu_1958_p0() {
    mul_ln1118_190_fu_1958_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_190_fu_1958_p2() {
    mul_ln1118_190_fu_1958_p2 = (!mul_ln1118_190_fu_1958_p0.read().is_01() || !ap_const_lv26_11B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_190_fu_1958_p0.read()) * sc_biguint<26>(ap_const_lv26_11B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_191_fu_1683_p0() {
    mul_ln1118_191_fu_1683_p0 = sext_ln1118_128_fu_2620922_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_191_fu_1683_p2() {
    mul_ln1118_191_fu_1683_p2 = (!mul_ln1118_191_fu_1683_p0.read().is_01() || !ap_const_lv23_7FFFCE.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_191_fu_1683_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_192_fu_2143_p0() {
    mul_ln1118_192_fu_2143_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_192_fu_2143_p2() {
    mul_ln1118_192_fu_2143_p2 = (!mul_ln1118_192_fu_2143_p0.read().is_01() || !ap_const_lv26_3FFFD65.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_192_fu_2143_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_193_fu_1868_p0() {
    mul_ln1118_193_fu_1868_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_193_fu_1868_p2() {
    mul_ln1118_193_fu_1868_p2 = (!mul_ln1118_193_fu_1868_p0.read().is_01() || !ap_const_lv26_3FFFEE3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_193_fu_1868_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_194_fu_1690_p0() {
    mul_ln1118_194_fu_1690_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_194_fu_1690_p2() {
    mul_ln1118_194_fu_1690_p2 = (!mul_ln1118_194_fu_1690_p0.read().is_01() || !ap_const_lv26_3FFFEF2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_194_fu_1690_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_195_fu_2261_p0() {
    mul_ln1118_195_fu_2261_p0 =  (sc_lv<16>) (sext_ln1118_130_fu_2620932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_195_fu_2261_p2() {
    mul_ln1118_195_fu_2261_p2 = (!mul_ln1118_195_fu_2261_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_195_fu_2261_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_196_fu_1986_p0() {
    mul_ln1118_196_fu_1986_p0 = sext_ln1118_129_fu_2620927_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_196_fu_1986_p2() {
    mul_ln1118_196_fu_1986_p2 = (!mul_ln1118_196_fu_1986_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_196_fu_1986_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_197_fu_1489_p0() {
    mul_ln1118_197_fu_1489_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_197_fu_1489_p2() {
    mul_ln1118_197_fu_1489_p2 = (!mul_ln1118_197_fu_1489_p0.read().is_01() || !ap_const_lv26_3FFFEB8.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_197_fu_1489_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_198_fu_1741_p0() {
    mul_ln1118_198_fu_1741_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_198_fu_1741_p2() {
    mul_ln1118_198_fu_1741_p2 = (!mul_ln1118_198_fu_1741_p0.read().is_01() || !ap_const_lv26_3FFFD25.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_198_fu_1741_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_199_fu_1355_p0() {
    mul_ln1118_199_fu_1355_p0 =  (sc_lv<16>) (sext_ln1118_130_fu_2620932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_199_fu_1355_p2() {
    mul_ln1118_199_fu_1355_p2 = (!mul_ln1118_199_fu_1355_p0.read().is_01() || !ap_const_lv25_B5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_199_fu_1355_p0.read()) * sc_biguint<25>(ap_const_lv25_B5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_19_fu_1438_p0() {
    mul_ln1118_19_fu_1438_p0 =  (sc_lv<16>) (sext_ln1118_8_fu_2615992_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_19_fu_1438_p2() {
    mul_ln1118_19_fu_1438_p2 = (!mul_ln1118_19_fu_1438_p0.read().is_01() || !ap_const_lv25_C4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_19_fu_1438_p0.read()) * sc_biguint<25>(ap_const_lv25_C4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_200_fu_2200_p0() {
    mul_ln1118_200_fu_2200_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_200_fu_2200_p2() {
    mul_ln1118_200_fu_2200_p2 = (!mul_ln1118_200_fu_2200_p0.read().is_01() || !ap_const_lv26_136.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_200_fu_2200_p0.read()) * sc_biguint<26>(ap_const_lv26_136);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_201_fu_1562_p0() {
    mul_ln1118_201_fu_1562_p0 =  (sc_lv<16>) (sext_ln1118_127_fu_2620916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_201_fu_1562_p2() {
    mul_ln1118_201_fu_1562_p2 = (!mul_ln1118_201_fu_1562_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_201_fu_1562_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_202_fu_2276_p0() {
    mul_ln1118_202_fu_2276_p0 =  (sc_lv<16>) (sext_ln1118_130_fu_2620932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_202_fu_2276_p2() {
    mul_ln1118_202_fu_2276_p2 = (!mul_ln1118_202_fu_2276_p0.read().is_01() || !ap_const_lv25_1FFFF2B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_202_fu_2276_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_203_fu_1408_p0() {
    mul_ln1118_203_fu_1408_p0 =  (sc_lv<16>) (sext_ln1118_127_fu_2620916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_203_fu_1408_p2() {
    mul_ln1118_203_fu_1408_p2 = (!mul_ln1118_203_fu_1408_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_203_fu_1408_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_204_fu_2278_p0() {
    mul_ln1118_204_fu_2278_p0 =  (sc_lv<16>) (sext_ln1118_130_fu_2620932_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_204_fu_2278_p2() {
    mul_ln1118_204_fu_2278_p2 = (!mul_ln1118_204_fu_2278_p0.read().is_01() || !ap_const_lv25_1FFFF5A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_204_fu_2278_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_205_fu_2279_p0() {
    mul_ln1118_205_fu_2279_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_205_fu_2279_p2() {
    mul_ln1118_205_fu_2279_p2 = (!mul_ln1118_205_fu_2279_p0.read().is_01() || !ap_const_lv26_3FFFEEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_205_fu_2279_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_206_fu_1411_p0() {
    mul_ln1118_206_fu_1411_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_206_fu_1411_p2() {
    mul_ln1118_206_fu_1411_p2 = (!mul_ln1118_206_fu_1411_p0.read().is_01() || !ap_const_lv26_3FFFE9D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_206_fu_1411_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_207_fu_1412_p0() {
    mul_ln1118_207_fu_1412_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_207_fu_1412_p2() {
    mul_ln1118_207_fu_1412_p2 = (!mul_ln1118_207_fu_1412_p0.read().is_01() || !ap_const_lv26_3FFFEBD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_207_fu_1412_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_208_fu_2282_p0() {
    mul_ln1118_208_fu_2282_p0 =  (sc_lv<16>) (sext_ln1118_126_fu_2620901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_208_fu_2282_p2() {
    mul_ln1118_208_fu_2282_p2 = (!mul_ln1118_208_fu_2282_p0.read().is_01() || !ap_const_lv26_172.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_208_fu_2282_p0.read()) * sc_biguint<26>(ap_const_lv26_172);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_209_fu_1570_p0() {
    mul_ln1118_209_fu_1570_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_209_fu_1570_p2() {
    mul_ln1118_209_fu_1570_p2 = (!mul_ln1118_209_fu_1570_p0.read().is_01() || !ap_const_lv25_C8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_209_fu_1570_p0.read()) * sc_biguint<25>(ap_const_lv25_C8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_20_fu_1898_p0() {
    mul_ln1118_20_fu_1898_p0 =  (sc_lv<16>) (sext_ln1118_7_fu_2615980_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_20_fu_1898_p2() {
    mul_ln1118_20_fu_1898_p2 = (!mul_ln1118_20_fu_1898_p0.read().is_01() || !ap_const_lv26_158.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_20_fu_1898_p0.read()) * sc_biguint<26>(ap_const_lv26_158);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_210_fu_2284_p0() {
    mul_ln1118_210_fu_2284_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_210_fu_2284_p2() {
    mul_ln1118_210_fu_2284_p2 = (!mul_ln1118_210_fu_2284_p0.read().is_01() || !ap_const_lv26_11B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_210_fu_2284_p0.read()) * sc_biguint<26>(ap_const_lv26_11B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_211_fu_2285_p0() {
    mul_ln1118_211_fu_2285_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_211_fu_2285_p2() {
    mul_ln1118_211_fu_2285_p2 = (!mul_ln1118_211_fu_2285_p0.read().is_01() || !ap_const_lv26_1FB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_211_fu_2285_p0.read()) * sc_biguint<26>(ap_const_lv26_1FB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_212_fu_2041_p0() {
    mul_ln1118_212_fu_2041_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_212_fu_2041_p2() {
    mul_ln1118_212_fu_2041_p2 = (!mul_ln1118_212_fu_2041_p0.read().is_01() || !ap_const_lv26_109.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_212_fu_2041_p0.read()) * sc_biguint<26>(ap_const_lv26_109);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_213_fu_2058_p0() {
    mul_ln1118_213_fu_2058_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_213_fu_2058_p2() {
    mul_ln1118_213_fu_2058_p2 = (!mul_ln1118_213_fu_2058_p0.read().is_01() || !ap_const_lv25_AE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_213_fu_2058_p0.read()) * sc_biguint<25>(ap_const_lv25_AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_214_fu_1731_p0() {
    mul_ln1118_214_fu_1731_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_214_fu_1731_p2() {
    mul_ln1118_214_fu_1731_p2 = (!mul_ln1118_214_fu_1731_p0.read().is_01() || !ap_const_lv24_6E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_214_fu_1731_p0.read()) * sc_biguint<24>(ap_const_lv24_6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_215_fu_1342_p0() {
    mul_ln1118_215_fu_1342_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_215_fu_1342_p2() {
    mul_ln1118_215_fu_1342_p2 = (!mul_ln1118_215_fu_1342_p0.read().is_01() || !ap_const_lv25_94.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_215_fu_1342_p0.read()) * sc_biguint<25>(ap_const_lv25_94);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_216_fu_2287_p0() {
    mul_ln1118_216_fu_2287_p0 =  (sc_lv<16>) (sext_ln1118_149_fu_2621577_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_216_fu_2287_p2() {
    mul_ln1118_216_fu_2287_p2 = (!mul_ln1118_216_fu_2287_p0.read().is_01() || !ap_const_lv22_3FFFE7.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_216_fu_2287_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_217_fu_2220_p0() {
    mul_ln1118_217_fu_2220_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_217_fu_2220_p2() {
    mul_ln1118_217_fu_2220_p2 = (!mul_ln1118_217_fu_2220_p0.read().is_01() || !ap_const_lv26_1C3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_217_fu_2220_p0.read()) * sc_biguint<26>(ap_const_lv26_1C3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_218_fu_2042_p0() {
    mul_ln1118_218_fu_2042_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_218_fu_2042_p2() {
    mul_ln1118_218_fu_2042_p2 = (!mul_ln1118_218_fu_2042_p0.read().is_01() || !ap_const_lv26_3FFFEB6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_218_fu_2042_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_219_fu_1767_p0() {
    mul_ln1118_219_fu_1767_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_219_fu_1767_p2() {
    mul_ln1118_219_fu_1767_p2 = (!mul_ln1118_219_fu_1767_p0.read().is_01() || !ap_const_lv25_A5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_219_fu_1767_p0.read()) * sc_biguint<25>(ap_const_lv25_A5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_21_fu_2150_p0() {
    mul_ln1118_21_fu_2150_p0 = sext_ln1118_19_fu_2616456_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_21_fu_2150_p2() {
    mul_ln1118_21_fu_2150_p2 = (!mul_ln1118_21_fu_2150_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_21_fu_2150_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_220_fu_2227_p0() {
    mul_ln1118_220_fu_2227_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_220_fu_2227_p2() {
    mul_ln1118_220_fu_2227_p2 = (!mul_ln1118_220_fu_2227_p0.read().is_01() || !ap_const_lv24_58.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_220_fu_2227_p0.read()) * sc_biguint<24>(ap_const_lv24_58);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_221_fu_1522_p0() {
    mul_ln1118_221_fu_1522_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_221_fu_1522_p2() {
    mul_ln1118_221_fu_1522_p2 = (!mul_ln1118_221_fu_1522_p0.read().is_01() || !ap_const_lv24_FFFFBB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_221_fu_1522_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_222_fu_1774_p0() {
    mul_ln1118_222_fu_1774_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_222_fu_1774_p2() {
    mul_ln1118_222_fu_1774_p2 = (!mul_ln1118_222_fu_1774_p0.read().is_01() || !ap_const_lv25_E6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_222_fu_1774_p0.read()) * sc_biguint<25>(ap_const_lv25_E6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_223_fu_2345_p0() {
    mul_ln1118_223_fu_2345_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_223_fu_2345_p2() {
    mul_ln1118_223_fu_2345_p2 = (!mul_ln1118_223_fu_2345_p0.read().is_01() || !ap_const_lv24_5F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_223_fu_2345_p0.read()) * sc_biguint<24>(ap_const_lv24_5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_224_fu_1432_p0() {
    mul_ln1118_224_fu_1432_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_224_fu_1432_p2() {
    mul_ln1118_224_fu_1432_p2 = (!mul_ln1118_224_fu_1432_p0.read().is_01() || !ap_const_lv26_13C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_224_fu_1432_p0.read()) * sc_biguint<26>(ap_const_lv26_13C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_225_fu_1573_p0() {
    mul_ln1118_225_fu_1573_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_225_fu_1573_p2() {
    mul_ln1118_225_fu_1573_p2 = (!mul_ln1118_225_fu_1573_p0.read().is_01() || !ap_const_lv24_77.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_225_fu_1573_p0.read()) * sc_biguint<24>(ap_const_lv24_77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_226_fu_1825_p0() {
    mul_ln1118_226_fu_1825_p0 =  (sc_lv<16>) (sext_ln1118_147_fu_2621556_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_226_fu_1825_p2() {
    mul_ln1118_226_fu_1825_p2 = (!mul_ln1118_226_fu_1825_p0.read().is_01() || !ap_const_lv26_3FFFED0.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_226_fu_1825_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_227_fu_1995_p0() {
    mul_ln1118_227_fu_1995_p0 =  (sc_lv<16>) (sext_ln1118_149_fu_2621577_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_227_fu_1995_p2() {
    mul_ln1118_227_fu_1995_p2 = (!mul_ln1118_227_fu_1995_p0.read().is_01() || !ap_const_lv22_1D.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_227_fu_1995_p0.read()) * sc_biguint<22>(ap_const_lv22_1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_228_fu_2343_p0() {
    mul_ln1118_228_fu_2343_p0 =  (sc_lv<16>) (sext_ln1118_149_fu_2621577_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_228_fu_2343_p2() {
    mul_ln1118_228_fu_2343_p2 = (!mul_ln1118_228_fu_2343_p0.read().is_01() || !ap_const_lv22_1B.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_228_fu_2343_p0.read()) * sc_biguint<22>(ap_const_lv22_1B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_229_fu_1475_p0() {
    mul_ln1118_229_fu_1475_p0 =  (sc_lv<16>) (sext_ln1118_146_fu_2621546_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_229_fu_1475_p2() {
    mul_ln1118_229_fu_1475_p2 = (!mul_ln1118_229_fu_1475_p0.read().is_01() || !ap_const_lv24_4A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_229_fu_1475_p0.read()) * sc_biguint<24>(ap_const_lv24_4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_22_fu_1445_p0() {
    mul_ln1118_22_fu_1445_p0 =  (sc_lv<16>) (sext_ln1118_21_fu_2616467_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_22_fu_1445_p2() {
    mul_ln1118_22_fu_1445_p2 = (!mul_ln1118_22_fu_1445_p0.read().is_01() || !ap_const_lv23_7FFFC5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_22_fu_1445_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_230_fu_2189_p0() {
    mul_ln1118_230_fu_2189_p0 =  (sc_lv<16>) (sext_ln1118_148_fu_2621567_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_230_fu_2189_p2() {
    mul_ln1118_230_fu_2189_p2 = (!mul_ln1118_230_fu_2189_p0.read().is_01() || !ap_const_lv25_1FFFF63.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_230_fu_2189_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF63);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_231_fu_2346_p0() {
    mul_ln1118_231_fu_2346_p0 = sext_ln1118_163_fu_2622137_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_231_fu_2346_p2() {
    mul_ln1118_231_fu_2346_p2 = (!mul_ln1118_231_fu_2346_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_231_fu_2346_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_232_fu_1946_p0() {
    mul_ln1118_232_fu_1946_p0 =  (sc_lv<16>) (sext_ln1118_167_fu_2622156_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_232_fu_1946_p2() {
    mul_ln1118_232_fu_1946_p2 = (!mul_ln1118_232_fu_1946_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_232_fu_1946_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_233_fu_2348_p0() {
    mul_ln1118_233_fu_2348_p0 =  (sc_lv<16>) (sext_ln1118_162_fu_2622128_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_233_fu_2348_p2() {
    mul_ln1118_233_fu_2348_p2 = (!mul_ln1118_233_fu_2348_p0.read().is_01() || !ap_const_lv26_118.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_233_fu_2348_p0.read()) * sc_biguint<26>(ap_const_lv26_118);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_234_fu_2349_p0() {
    mul_ln1118_234_fu_2349_p0 =  (sc_lv<16>) (sext_ln1118_167_fu_2622156_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_234_fu_2349_p2() {
    mul_ln1118_234_fu_2349_p2 = (!mul_ln1118_234_fu_2349_p0.read().is_01() || !ap_const_lv22_16.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_234_fu_2349_p0.read()) * sc_biguint<22>(ap_const_lv22_16);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_235_fu_2350_p0() {
    mul_ln1118_235_fu_2350_p0 =  (sc_lv<16>) (sext_ln1118_166_fu_2622150_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_235_fu_2350_p2() {
    mul_ln1118_235_fu_2350_p2 = (!mul_ln1118_235_fu_2350_p0.read().is_01() || !ap_const_lv24_FFFFAC.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_235_fu_2350_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_236_fu_2351_p0() {
    mul_ln1118_236_fu_2351_p0 =  (sc_lv<16>) (sext_ln1118_162_fu_2622128_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_236_fu_2351_p2() {
    mul_ln1118_236_fu_2351_p2 = (!mul_ln1118_236_fu_2351_p0.read().is_01() || !ap_const_lv26_3FFFDDA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_236_fu_2351_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDDA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_237_fu_2352_p0() {
    mul_ln1118_237_fu_2352_p0 =  (sc_lv<16>) (sext_ln1118_166_fu_2622150_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_237_fu_2352_p2() {
    mul_ln1118_237_fu_2352_p2 = (!mul_ln1118_237_fu_2352_p0.read().is_01() || !ap_const_lv24_FFFFA5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_237_fu_2352_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_238_fu_2353_p0() {
    mul_ln1118_238_fu_2353_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_238_fu_2353_p2() {
    mul_ln1118_238_fu_2353_p2 = (!mul_ln1118_238_fu_2353_p0.read().is_01() || !ap_const_lv25_AA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_238_fu_2353_p0.read()) * sc_biguint<25>(ap_const_lv25_AA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_239_fu_1797_p0() {
    mul_ln1118_239_fu_1797_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_239_fu_1797_p2() {
    mul_ln1118_239_fu_1797_p2 = (!mul_ln1118_239_fu_1797_p0.read().is_01() || !ap_const_lv25_9F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_239_fu_1797_p0.read()) * sc_biguint<25>(ap_const_lv25_9F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_23_fu_2335_p0() {
    mul_ln1118_23_fu_2335_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_23_fu_2335_p2() {
    mul_ln1118_23_fu_2335_p2 = (!mul_ln1118_23_fu_2335_p0.read().is_01() || !ap_const_lv26_13E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_23_fu_2335_p0.read()) * sc_biguint<26>(ap_const_lv26_13E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_240_fu_2209_p0() {
    mul_ln1118_240_fu_2209_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_240_fu_2209_p2() {
    mul_ln1118_240_fu_2209_p2 = (!mul_ln1118_240_fu_2209_p0.read().is_01() || !ap_const_lv25_1FFFF27.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_240_fu_2209_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_241_fu_1615_p0() {
    mul_ln1118_241_fu_1615_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_241_fu_1615_p2() {
    mul_ln1118_241_fu_1615_p2 = (!mul_ln1118_241_fu_1615_p0.read().is_01() || !ap_const_lv25_A1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_241_fu_1615_p0.read()) * sc_biguint<25>(ap_const_lv25_A1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_243_fu_1867_p0() {
    mul_ln1118_243_fu_1867_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_243_fu_1867_p2() {
    mul_ln1118_243_fu_1867_p2 = (!mul_ln1118_243_fu_1867_p0.read().is_01() || !ap_const_lv25_D4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_243_fu_1867_p0.read()) * sc_biguint<25>(ap_const_lv25_D4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_244_fu_2119_p0() {
    mul_ln1118_244_fu_2119_p0 =  (sc_lv<16>) (sext_ln1118_162_fu_2622128_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_244_fu_2119_p2() {
    mul_ln1118_244_fu_2119_p2 = (!mul_ln1118_244_fu_2119_p0.read().is_01() || !ap_const_lv26_116.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_244_fu_2119_p0.read()) * sc_biguint<26>(ap_const_lv26_116);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_245_fu_1941_p0() {
    mul_ln1118_245_fu_1941_p0 = sext_ln1118_168_fu_2622162_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_245_fu_1941_p2() {
    mul_ln1118_245_fu_1941_p2 = (!mul_ln1118_245_fu_1941_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_245_fu_1941_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_246_fu_1555_p0() {
    mul_ln1118_246_fu_1555_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_246_fu_1555_p2() {
    mul_ln1118_246_fu_1555_p2 = (!mul_ln1118_246_fu_1555_p0.read().is_01() || !ap_const_lv25_98.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_246_fu_1555_p0.read()) * sc_biguint<25>(ap_const_lv25_98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_247_fu_1918_p0() {
    mul_ln1118_247_fu_1918_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_247_fu_1918_p2() {
    mul_ln1118_247_fu_1918_p2 = (!mul_ln1118_247_fu_1918_p0.read().is_01() || !ap_const_lv25_CE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_247_fu_1918_p0.read()) * sc_biguint<25>(ap_const_lv25_CE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_248_fu_1421_p0() {
    mul_ln1118_248_fu_1421_p0 =  (sc_lv<16>) (sext_ln1118_161_fu_2622116_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_248_fu_1421_p2() {
    mul_ln1118_248_fu_1421_p2 = (!mul_ln1118_248_fu_1421_p0.read().is_01() || !ap_const_lv25_E7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_248_fu_1421_p0.read()) * sc_biguint<25>(ap_const_lv25_E7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_249_fu_1992_p0() {
    mul_ln1118_249_fu_1992_p0 =  (sc_lv<16>) (sext_ln1118_162_fu_2622128_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_249_fu_1992_p2() {
    mul_ln1118_249_fu_1992_p2 = (!mul_ln1118_249_fu_1992_p0.read().is_01() || !ap_const_lv26_12D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_249_fu_1992_p0.read()) * sc_biguint<26>(ap_const_lv26_12D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_24_fu_1630_p0() {
    mul_ln1118_24_fu_1630_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_24_fu_1630_p2() {
    mul_ln1118_24_fu_1630_p2 = (!mul_ln1118_24_fu_1630_p0.read().is_01() || !ap_const_lv25_BB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_24_fu_1630_p0.read()) * sc_biguint<25>(ap_const_lv25_BB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_250_fu_1606_p0() {
    mul_ln1118_250_fu_1606_p0 =  (sc_lv<16>) (sext_ln1118_162_fu_2622128_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_250_fu_1606_p2() {
    mul_ln1118_250_fu_1606_p2 = (!mul_ln1118_250_fu_1606_p0.read().is_01() || !ap_const_lv26_151.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_250_fu_1606_p0.read()) * sc_biguint<26>(ap_const_lv26_151);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_251_fu_1969_p0() {
    mul_ln1118_251_fu_1969_p0 =  (sc_lv<16>) (sext_ln1118_180_fu_2622718_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_251_fu_1969_p2() {
    mul_ln1118_251_fu_1969_p2 = (!mul_ln1118_251_fu_1969_p0.read().is_01() || !ap_const_lv23_2D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_251_fu_1969_p0.read()) * sc_biguint<23>(ap_const_lv23_2D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_252_fu_2110_p0() {
    mul_ln1118_252_fu_2110_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_252_fu_2110_p2() {
    mul_ln1118_252_fu_2110_p2 = (!mul_ln1118_252_fu_2110_p0.read().is_01() || !ap_const_lv25_1FFFF31.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_252_fu_2110_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF31);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_253_fu_1405_p0() {
    mul_ln1118_253_fu_1405_p0 =  (sc_lv<16>) (sext_ln1118_178_fu_2622697_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_253_fu_1405_p2() {
    mul_ln1118_253_fu_1405_p2 = (!mul_ln1118_253_fu_1405_p0.read().is_01() || !ap_const_lv26_103.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_253_fu_1405_p0.read()) * sc_biguint<26>(ap_const_lv26_103);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_254_fu_1338_p0() {
    mul_ln1118_254_fu_1338_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_254_fu_1338_p2() {
    mul_ln1118_254_fu_1338_p2 = (!mul_ln1118_254_fu_1338_p0.read().is_01() || !ap_const_lv25_1FFFF2B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_254_fu_1338_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_255_fu_1590_p0() {
    mul_ln1118_255_fu_1590_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_255_fu_1590_p2() {
    mul_ln1118_255_fu_1590_p2 = (!mul_ln1118_255_fu_1590_p0.read().is_01() || !ap_const_lv25_1FFFF0C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_255_fu_1590_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_256_fu_2090_p0() {
    mul_ln1118_256_fu_2090_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_256_fu_2090_p2() {
    mul_ln1118_256_fu_2090_p2 = (!mul_ln1118_256_fu_2090_p0.read().is_01() || !ap_const_lv25_CF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_256_fu_2090_p0.read()) * sc_biguint<25>(ap_const_lv25_CF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_257_fu_2256_p0() {
    mul_ln1118_257_fu_2256_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_257_fu_2256_p2() {
    mul_ln1118_257_fu_2256_p2 = (!mul_ln1118_257_fu_2256_p0.read().is_01() || !ap_const_lv25_1FFFF6F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_257_fu_2256_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_258_fu_1388_p0() {
    mul_ln1118_258_fu_1388_p0 =  (sc_lv<16>) (sext_ln1118_177_fu_2622689_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_258_fu_1388_p2() {
    mul_ln1118_258_fu_1388_p2 = (!mul_ln1118_258_fu_1388_p0.read().is_01() || !ap_const_lv24_77.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_258_fu_1388_p0.read()) * sc_biguint<24>(ap_const_lv24_77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_259_fu_1389_p0() {
    mul_ln1118_259_fu_1389_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_259_fu_1389_p2() {
    mul_ln1118_259_fu_1389_p2 = (!mul_ln1118_259_fu_1389_p0.read().is_01() || !ap_const_lv25_8D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_259_fu_1389_p0.read()) * sc_biguint<25>(ap_const_lv25_8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_260_fu_2259_p0() {
    mul_ln1118_260_fu_2259_p0 =  (sc_lv<16>) (sext_ln1118_177_fu_2622689_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_260_fu_2259_p2() {
    mul_ln1118_260_fu_2259_p2 = (!mul_ln1118_260_fu_2259_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_260_fu_2259_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_261_fu_1391_p0() {
    mul_ln1118_261_fu_1391_p0 =  (sc_lv<16>) (sext_ln1118_177_fu_2622689_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_261_fu_1391_p2() {
    mul_ln1118_261_fu_1391_p2 = (!mul_ln1118_261_fu_1391_p0.read().is_01() || !ap_const_lv24_5B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_261_fu_1391_p0.read()) * sc_biguint<24>(ap_const_lv24_5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_262_fu_1704_p0() {
    mul_ln1118_262_fu_1704_p0 = sext_ln1118_182_fu_2622728_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_262_fu_1704_p2() {
    mul_ln1118_262_fu_1704_p2 = (!mul_ln1118_262_fu_1704_p0.read().is_01() || !ap_const_lv22_1A.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_262_fu_1704_p0.read()) * sc_biguint<22>(ap_const_lv22_1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_263_fu_1393_p0() {
    mul_ln1118_263_fu_1393_p0 =  (sc_lv<16>) (sext_ln1118_178_fu_2622697_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_263_fu_1393_p2() {
    mul_ln1118_263_fu_1393_p2 = (!mul_ln1118_263_fu_1393_p0.read().is_01() || !ap_const_lv26_3FFFD72.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_263_fu_1393_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_264_fu_1394_p0() {
    mul_ln1118_264_fu_1394_p0 =  (sc_lv<16>) (sext_ln1118_180_fu_2622718_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_264_fu_1394_p2() {
    mul_ln1118_264_fu_1394_p2 = (!mul_ln1118_264_fu_1394_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_264_fu_1394_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_265_fu_1395_p0() {
    mul_ln1118_265_fu_1395_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_265_fu_1395_p2() {
    mul_ln1118_265_fu_1395_p2 = (!mul_ln1118_265_fu_1395_p0.read().is_01() || !ap_const_lv25_BC.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_265_fu_1395_p0.read()) * sc_biguint<25>(ap_const_lv25_BC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_266_fu_1552_p0() {
    mul_ln1118_266_fu_1552_p0 =  (sc_lv<16>) (sext_ln1118_178_fu_2622697_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_266_fu_1552_p2() {
    mul_ln1118_266_fu_1552_p2 = (!mul_ln1118_266_fu_1552_p0.read().is_01() || !ap_const_lv26_3FFFECD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_266_fu_1552_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_267_fu_2266_p0() {
    mul_ln1118_267_fu_2266_p0 =  (sc_lv<16>) (sext_ln1118_177_fu_2622689_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_267_fu_2266_p2() {
    mul_ln1118_267_fu_2266_p2 = (!mul_ln1118_267_fu_2266_p0.read().is_01() || !ap_const_lv24_FFFF86.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_267_fu_2266_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_268_fu_1398_p0() {
    mul_ln1118_268_fu_1398_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_268_fu_1398_p2() {
    mul_ln1118_268_fu_1398_p2 = (!mul_ln1118_268_fu_1398_p0.read().is_01() || !ap_const_lv25_1FFFF4C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_268_fu_1398_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_269_fu_1974_p0() {
    mul_ln1118_269_fu_1974_p0 =  (sc_lv<16>) (sext_ln1118_179_fu_2622705_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_269_fu_1974_p2() {
    mul_ln1118_269_fu_1974_p2 = (!mul_ln1118_269_fu_1974_p0.read().is_01() || !ap_const_lv25_1FFFF71.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_269_fu_1974_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF71);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_26_fu_2201_p0() {
    mul_ln1118_26_fu_2201_p0 =  (sc_lv<16>) (sext_ln1118_20_fu_2616461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_26_fu_2201_p2() {
    mul_ln1118_26_fu_2201_p2 = (!mul_ln1118_26_fu_2201_p0.read().is_01() || !ap_const_lv24_66.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_26_fu_2201_p0.read()) * sc_biguint<24>(ap_const_lv24_66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_270_fu_1588_p0() {
    mul_ln1118_270_fu_1588_p0 =  (sc_lv<16>) (sext_ln1118_178_fu_2622697_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_270_fu_1588_p2() {
    mul_ln1118_270_fu_1588_p2 = (!mul_ln1118_270_fu_1588_p0.read().is_01() || !ap_const_lv26_3FFFE78.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_270_fu_1588_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE78);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_271_fu_1840_p0() {
    mul_ln1118_271_fu_1840_p0 =  (sc_lv<16>) (sext_ln1118_195_fu_2623314_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_271_fu_1840_p2() {
    mul_ln1118_271_fu_1840_p2 = (!mul_ln1118_271_fu_1840_p0.read().is_01() || !ap_const_lv23_3B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_271_fu_1840_p0.read()) * sc_biguint<23>(ap_const_lv23_3B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_272_fu_1453_p0() {
    mul_ln1118_272_fu_1453_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_272_fu_1453_p2() {
    mul_ln1118_272_fu_1453_p2 = (!mul_ln1118_272_fu_1453_p0.read().is_01() || !ap_const_lv25_1FFFF77.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_272_fu_1453_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF77);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_273_fu_2025_p0() {
    mul_ln1118_273_fu_2025_p0 =  (sc_lv<16>) (sext_ln1118_194_fu_2623305_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_273_fu_2025_p2() {
    mul_ln1118_273_fu_2025_p2 = (!mul_ln1118_273_fu_2025_p0.read().is_01() || !ap_const_lv24_76.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_273_fu_2025_p0.read()) * sc_biguint<24>(ap_const_lv24_76);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_274_fu_1639_p0() {
    mul_ln1118_274_fu_1639_p0 =  (sc_lv<16>) (sext_ln1118_195_fu_2623314_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_274_fu_1639_p2() {
    mul_ln1118_274_fu_1639_p2 = (!mul_ln1118_274_fu_1639_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_274_fu_1639_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_275_fu_1891_p0() {
    mul_ln1118_275_fu_1891_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_275_fu_1891_p2() {
    mul_ln1118_275_fu_1891_p2 = (!mul_ln1118_275_fu_1891_p0.read().is_01() || !ap_const_lv25_EF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_275_fu_1891_p0.read()) * sc_biguint<25>(ap_const_lv25_EF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_276_fu_1505_p0() {
    mul_ln1118_276_fu_1505_p0 =  (sc_lv<16>) (sext_ln1118_194_fu_2623305_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_276_fu_1505_p2() {
    mul_ln1118_276_fu_1505_p2 = (!mul_ln1118_276_fu_1505_p0.read().is_01() || !ap_const_lv24_FFFFB2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_276_fu_1505_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_277_fu_2076_p0() {
    mul_ln1118_277_fu_2076_p0 =  (sc_lv<16>) (sext_ln1118_194_fu_2623305_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_277_fu_2076_p2() {
    mul_ln1118_277_fu_2076_p2 = (!mul_ln1118_277_fu_2076_p0.read().is_01() || !ap_const_lv24_4C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_277_fu_2076_p0.read()) * sc_biguint<24>(ap_const_lv24_4C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_278_fu_2328_p0() {
    mul_ln1118_278_fu_2328_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_278_fu_2328_p2() {
    mul_ln1118_278_fu_2328_p2 = (!mul_ln1118_278_fu_2328_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_278_fu_2328_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_279_fu_1942_p0() {
    mul_ln1118_279_fu_1942_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_279_fu_1942_p2() {
    mul_ln1118_279_fu_1942_p2 = (!mul_ln1118_279_fu_1942_p0.read().is_01() || !ap_const_lv25_1FFFF7A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_279_fu_1942_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_27_fu_1815_p0() {
    mul_ln1118_27_fu_1815_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_27_fu_1815_p2() {
    mul_ln1118_27_fu_1815_p2 = (!mul_ln1118_27_fu_1815_p0.read().is_01() || !ap_const_lv26_11B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_27_fu_1815_p0.read()) * sc_biguint<26>(ap_const_lv26_11B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_280_fu_2194_p0() {
    mul_ln1118_280_fu_2194_p0 =  (sc_lv<16>) (sext_ln1118_192_fu_2623283_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_280_fu_2194_p2() {
    mul_ln1118_280_fu_2194_p2 = (!mul_ln1118_280_fu_2194_p0.read().is_01() || !ap_const_lv26_121.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_280_fu_2194_p0.read()) * sc_biguint<26>(ap_const_lv26_121);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_281_fu_1808_p0() {
    mul_ln1118_281_fu_1808_p0 =  (sc_lv<16>) (sext_ln1118_194_fu_2623305_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_281_fu_1808_p2() {
    mul_ln1118_281_fu_1808_p2 = (!mul_ln1118_281_fu_1808_p0.read().is_01() || !ap_const_lv24_69.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_281_fu_1808_p0.read()) * sc_biguint<24>(ap_const_lv24_69);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_282_fu_2036_p0() {
    mul_ln1118_282_fu_2036_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_282_fu_2036_p2() {
    mul_ln1118_282_fu_2036_p2 = (!mul_ln1118_282_fu_2036_p0.read().is_01() || !ap_const_lv25_1FFFF62.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_282_fu_2036_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF62);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_283_fu_1885_p0() {
    mul_ln1118_283_fu_1885_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_283_fu_1885_p2() {
    mul_ln1118_283_fu_1885_p2 = (!mul_ln1118_283_fu_1885_p0.read().is_01() || !ap_const_lv25_1FFFF1E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_283_fu_1885_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_284_fu_1523_p0() {
    mul_ln1118_284_fu_1523_p0 =  (sc_lv<16>) (sext_ln1118_192_fu_2623283_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_284_fu_1523_p2() {
    mul_ln1118_284_fu_1523_p2 = (!mul_ln1118_284_fu_1523_p0.read().is_01() || !ap_const_lv26_3FFFED5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_284_fu_1523_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_285_fu_1524_p0() {
    mul_ln1118_285_fu_1524_p0 =  (sc_lv<16>) (sext_ln1118_194_fu_2623305_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_285_fu_1524_p2() {
    mul_ln1118_285_fu_1524_p2 = (!mul_ln1118_285_fu_1524_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_285_fu_1524_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_286_fu_1613_p0() {
    mul_ln1118_286_fu_1613_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_286_fu_1613_p2() {
    mul_ln1118_286_fu_1613_p2 = (!mul_ln1118_286_fu_1613_p0.read().is_01() || !ap_const_lv25_83.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_286_fu_1613_p0.read()) * sc_biguint<25>(ap_const_lv25_83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_287_fu_2171_p0() {
    mul_ln1118_287_fu_2171_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_287_fu_2171_p2() {
    mul_ln1118_287_fu_2171_p2 = (!mul_ln1118_287_fu_2171_p0.read().is_01() || !ap_const_lv25_CD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_287_fu_2171_p0.read()) * sc_biguint<25>(ap_const_lv25_CD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_288_fu_1527_p0() {
    mul_ln1118_288_fu_1527_p0 =  (sc_lv<16>) (sext_ln1118_192_fu_2623283_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_288_fu_1527_p2() {
    mul_ln1118_288_fu_1527_p2 = (!mul_ln1118_288_fu_1527_p0.read().is_01() || !ap_const_lv26_154.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_288_fu_1527_p0.read()) * sc_biguint<26>(ap_const_lv26_154);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_289_fu_2173_p0() {
    mul_ln1118_289_fu_2173_p0 =  (sc_lv<16>) (sext_ln1118_192_fu_2623283_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_289_fu_2173_p2() {
    mul_ln1118_289_fu_2173_p2 = (!mul_ln1118_289_fu_2173_p0.read().is_01() || !ap_const_lv26_150.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_289_fu_2173_p0.read()) * sc_biguint<26>(ap_const_lv26_150);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_28_fu_1748_p0() {
    mul_ln1118_28_fu_1748_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_28_fu_1748_p2() {
    mul_ln1118_28_fu_1748_p2 = (!mul_ln1118_28_fu_1748_p0.read().is_01() || !ap_const_lv26_10C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_28_fu_1748_p0.read()) * sc_biguint<26>(ap_const_lv26_10C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_290_fu_2018_p0() {
    mul_ln1118_290_fu_2018_p0 =  (sc_lv<16>) (sext_ln1118_192_fu_2623283_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_290_fu_2018_p2() {
    mul_ln1118_290_fu_2018_p2 = (!mul_ln1118_290_fu_2018_p0.read().is_01() || !ap_const_lv26_126.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_290_fu_2018_p0.read()) * sc_biguint<26>(ap_const_lv26_126);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_291_fu_2175_p0() {
    mul_ln1118_291_fu_2175_p0 =  (sc_lv<16>) (sext_ln1118_193_fu_2623292_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_291_fu_2175_p2() {
    mul_ln1118_291_fu_2175_p2 = (!mul_ln1118_291_fu_2175_p0.read().is_01() || !ap_const_lv25_A5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_291_fu_2175_p0.read()) * sc_biguint<25>(ap_const_lv25_A5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_292_fu_2243_p0() {
    mul_ln1118_292_fu_2243_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_292_fu_2243_p2() {
    mul_ln1118_292_fu_2243_p2 = (!mul_ln1118_292_fu_2243_p0.read().is_01() || !ap_const_lv25_95.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_292_fu_2243_p0.read()) * sc_biguint<25>(ap_const_lv25_95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_293_fu_1620_p0() {
    mul_ln1118_293_fu_1620_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_293_fu_1620_p2() {
    mul_ln1118_293_fu_1620_p2 = (!mul_ln1118_293_fu_1620_p0.read().is_01() || !ap_const_lv26_3FFFDFB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_293_fu_1620_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDFB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_294_fu_2178_p0() {
    mul_ln1118_294_fu_2178_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_294_fu_2178_p2() {
    mul_ln1118_294_fu_2178_p2 = (!mul_ln1118_294_fu_2178_p0.read().is_01() || !ap_const_lv26_3FFFC70.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_294_fu_2178_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFC70);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_295_fu_2179_p0() {
    mul_ln1118_295_fu_2179_p0 =  (sc_lv<16>) (sext_ln1118_207_fu_2623804_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_295_fu_2179_p2() {
    mul_ln1118_295_fu_2179_p2 = (!mul_ln1118_295_fu_2179_p0.read().is_01() || !ap_const_lv24_FFFF8E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_295_fu_2179_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_296_fu_2333_p0() {
    mul_ln1118_296_fu_2333_p0 = sext_ln1118_206_fu_2623799_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_296_fu_2333_p2() {
    mul_ln1118_296_fu_2333_p2 = (!mul_ln1118_296_fu_2333_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_296_fu_2333_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_297_fu_1628_p0() {
    mul_ln1118_297_fu_1628_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_297_fu_1628_p2() {
    mul_ln1118_297_fu_1628_p2 = (!mul_ln1118_297_fu_1628_p0.read().is_01() || !ap_const_lv26_3FFFD68.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_297_fu_1628_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD68);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_298_fu_1880_p0() {
    mul_ln1118_298_fu_1880_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_298_fu_1880_p2() {
    mul_ln1118_298_fu_1880_p2 = (!mul_ln1118_298_fu_1880_p0.read().is_01() || !ap_const_lv25_9E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_298_fu_1880_p0.read()) * sc_biguint<25>(ap_const_lv25_9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_299_fu_1813_p0() {
    mul_ln1118_299_fu_1813_p0 =  (sc_lv<16>) (sext_ln1118_207_fu_2623804_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_299_fu_1813_p2() {
    mul_ln1118_299_fu_1813_p2 = (!mul_ln1118_299_fu_1813_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_299_fu_1813_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_29_fu_2000_p0() {
    mul_ln1118_29_fu_2000_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_29_fu_2000_p2() {
    mul_ln1118_29_fu_2000_p2 = (!mul_ln1118_29_fu_2000_p0.read().is_01() || !ap_const_lv26_3FFFDB9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_29_fu_2000_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDB9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_300_fu_1746_p0() {
    mul_ln1118_300_fu_1746_p0 =  (sc_lv<16>) (sext_ln1118_207_fu_2623804_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_300_fu_1746_p2() {
    mul_ln1118_300_fu_1746_p2 = (!mul_ln1118_300_fu_1746_p0.read().is_01() || !ap_const_lv24_45.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_300_fu_1746_p0.read()) * sc_biguint<24>(ap_const_lv24_45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_301_fu_1360_p0() {
    mul_ln1118_301_fu_1360_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_301_fu_1360_p2() {
    mul_ln1118_301_fu_1360_p2 = (!mul_ln1118_301_fu_1360_p0.read().is_01() || !ap_const_lv26_3FFFECB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_301_fu_1360_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_302_fu_1612_p0() {
    mul_ln1118_302_fu_1612_p0 = sext_ln1118_205_fu_2623794_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_302_fu_1612_p2() {
    mul_ln1118_302_fu_1612_p2 = (!mul_ln1118_302_fu_1612_p0.read().is_01() || !ap_const_lv23_2B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_302_fu_1612_p0.read()) * sc_biguint<23>(ap_const_lv23_2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_303_fu_1545_p0() {
    mul_ln1118_303_fu_1545_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_303_fu_1545_p2() {
    mul_ln1118_303_fu_1545_p2 = (!mul_ln1118_303_fu_1545_p0.read().is_01() || !ap_const_lv25_F4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_303_fu_1545_p0.read()) * sc_biguint<25>(ap_const_lv25_F4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_304_fu_2116_p0() {
    mul_ln1118_304_fu_2116_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_304_fu_2116_p2() {
    mul_ln1118_304_fu_2116_p2 = (!mul_ln1118_304_fu_2116_p0.read().is_01() || !ap_const_lv25_1FFFF1F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_304_fu_2116_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_305_fu_2049_p0() {
    mul_ln1118_305_fu_2049_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_305_fu_2049_p2() {
    mul_ln1118_305_fu_2049_p2 = (!mul_ln1118_305_fu_2049_p0.read().is_01() || !ap_const_lv25_D6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_305_fu_2049_p0.read()) * sc_biguint<25>(ap_const_lv25_D6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_306_fu_1344_p0() {
    mul_ln1118_306_fu_1344_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_306_fu_1344_p2() {
    mul_ln1118_306_fu_1344_p2 = (!mul_ln1118_306_fu_1344_p0.read().is_01() || !ap_const_lv26_3FFFEC6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_306_fu_1344_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_307_fu_2234_p0() {
    mul_ln1118_307_fu_2234_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_307_fu_2234_p2() {
    mul_ln1118_307_fu_2234_p2 = (!mul_ln1118_307_fu_2234_p0.read().is_01() || !ap_const_lv25_B9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_307_fu_2234_p0.read()) * sc_biguint<25>(ap_const_lv25_B9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_308_fu_1640_p0() {
    mul_ln1118_308_fu_1640_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_308_fu_1640_p2() {
    mul_ln1118_308_fu_1640_p2 = (!mul_ln1118_308_fu_1640_p0.read().is_01() || !ap_const_lv26_156.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_308_fu_1640_p0.read()) * sc_biguint<26>(ap_const_lv26_156);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_309_fu_2100_p0() {
    mul_ln1118_309_fu_2100_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_309_fu_2100_p2() {
    mul_ln1118_309_fu_2100_p2 = (!mul_ln1118_309_fu_2100_p0.read().is_01() || !ap_const_lv26_3FFFCF7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_309_fu_2100_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCF7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_30_fu_1933_p0() {
    mul_ln1118_30_fu_1933_p0 =  (sc_lv<16>) (sext_ln1118_21_fu_2616467_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_30_fu_1933_p2() {
    mul_ln1118_30_fu_1933_p2 = (!mul_ln1118_30_fu_1933_p0.read().is_01() || !ap_const_lv23_7FFFD2.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_30_fu_1933_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_310_fu_2033_p0() {
    mul_ln1118_310_fu_2033_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_310_fu_2033_p2() {
    mul_ln1118_310_fu_2033_p2 = (!mul_ln1118_310_fu_2033_p0.read().is_01() || !ap_const_lv26_3FFFE68.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_310_fu_2033_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE68);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_311_fu_1681_p0() {
    mul_ln1118_311_fu_1681_p0 =  (sc_lv<16>) (sext_ln1118_209_fu_2623828_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_311_fu_1681_p2() {
    mul_ln1118_311_fu_1681_p2 = (!mul_ln1118_311_fu_1681_p0.read().is_01() || !ap_const_lv25_1FFFF05.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_311_fu_1681_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF05);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_312_fu_1682_p0() {
    mul_ln1118_312_fu_1682_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_312_fu_1682_p2() {
    mul_ln1118_312_fu_1682_p2 = (!mul_ln1118_312_fu_1682_p0.read().is_01() || !ap_const_lv26_3FFFED4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_312_fu_1682_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_313_fu_2082_p0() {
    mul_ln1118_313_fu_2082_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_313_fu_2082_p2() {
    mul_ln1118_313_fu_2082_p2 = (!mul_ln1118_313_fu_2082_p0.read().is_01() || !ap_const_lv26_3FFFEEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_313_fu_2082_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_314_fu_1370_p0() {
    mul_ln1118_314_fu_1370_p0 =  (sc_lv<16>) (sext_ln1118_207_fu_2623804_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_314_fu_1370_p2() {
    mul_ln1118_314_fu_1370_p2 = (!mul_ln1118_314_fu_1370_p0.read().is_01() || !ap_const_lv24_55.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_314_fu_1370_p0.read()) * sc_biguint<24>(ap_const_lv24_55);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_315_fu_2084_p0() {
    mul_ln1118_315_fu_2084_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_315_fu_2084_p2() {
    mul_ln1118_315_fu_2084_p2 = (!mul_ln1118_315_fu_2084_p0.read().is_01() || !ap_const_lv26_3FFFED2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_315_fu_2084_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_317_fu_1929_p0() {
    mul_ln1118_317_fu_1929_p0 =  (sc_lv<16>) (sext_ln1118_208_fu_2623812_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_317_fu_1929_p2() {
    mul_ln1118_317_fu_1929_p2 = (!mul_ln1118_317_fu_1929_p0.read().is_01() || !ap_const_lv26_184.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_317_fu_1929_p0.read()) * sc_biguint<26>(ap_const_lv26_184);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_318_fu_1930_p0() {
    mul_ln1118_318_fu_1930_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_318_fu_1930_p2() {
    mul_ln1118_318_fu_1930_p2 = (!mul_ln1118_318_fu_1930_p0.read().is_01() || !ap_const_lv26_17E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_318_fu_1930_p0.read()) * sc_biguint<26>(ap_const_lv26_17E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_319_fu_2087_p0() {
    mul_ln1118_319_fu_2087_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_319_fu_2087_p2() {
    mul_ln1118_319_fu_2087_p2 = (!mul_ln1118_319_fu_2087_p0.read().is_01() || !ap_const_lv26_1A0.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_319_fu_2087_p0.read()) * sc_biguint<26>(ap_const_lv26_1A0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_31_fu_1977_p0() {
    mul_ln1118_31_fu_1977_p0 =  (sc_lv<16>) (sext_ln1118_21_fu_2616467_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_31_fu_1977_p2() {
    mul_ln1118_31_fu_1977_p2 = (!mul_ln1118_31_fu_1977_p0.read().is_01() || !ap_const_lv23_36.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_31_fu_1977_p0.read()) * sc_biguint<23>(ap_const_lv23_36);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_320_fu_1932_p0() {
    mul_ln1118_320_fu_1932_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_320_fu_1932_p2() {
    mul_ln1118_320_fu_1932_p2 = (!mul_ln1118_320_fu_1932_p0.read().is_01() || !ap_const_lv24_57.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_320_fu_1932_p0.read()) * sc_biguint<24>(ap_const_lv24_57);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_321_fu_2089_p0() {
    mul_ln1118_321_fu_2089_p0 =  (sc_lv<16>) (sext_ln1118_218_fu_2624322_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_321_fu_2089_p2() {
    mul_ln1118_321_fu_2089_p2 = (!mul_ln1118_321_fu_2089_p0.read().is_01() || !ap_const_lv22_3FFFE6.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_321_fu_2089_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_322_fu_2246_p0() {
    mul_ln1118_322_fu_2246_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_322_fu_2246_p2() {
    mul_ln1118_322_fu_2246_p2 = (!mul_ln1118_322_fu_2246_p0.read().is_01() || !ap_const_lv26_15E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_322_fu_2246_p0.read()) * sc_biguint<26>(ap_const_lv26_15E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_323_fu_2091_p0() {
    mul_ln1118_323_fu_2091_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_323_fu_2091_p2() {
    mul_ln1118_323_fu_2091_p2 = (!mul_ln1118_323_fu_2091_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_323_fu_2091_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_324_fu_2092_p0() {
    mul_ln1118_324_fu_2092_p0 =  (sc_lv<16>) (sext_ln1118_217_fu_2624315_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_324_fu_2092_p2() {
    mul_ln1118_324_fu_2092_p2 = (!mul_ln1118_324_fu_2092_p0.read().is_01() || !ap_const_lv23_7FFFCE.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_324_fu_2092_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_325_fu_1781_p0() {
    mul_ln1118_325_fu_1781_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_325_fu_1781_p2() {
    mul_ln1118_325_fu_1781_p2 = (!mul_ln1118_325_fu_1781_p0.read().is_01() || !ap_const_lv26_3FFFE1D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_325_fu_1781_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_326_fu_1920_p0() {
    mul_ln1118_326_fu_1920_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_326_fu_1920_p2() {
    mul_ln1118_326_fu_1920_p2 = (!mul_ln1118_326_fu_1920_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_326_fu_1920_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_327_fu_2172_p0() {
    mul_ln1118_327_fu_2172_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_327_fu_2172_p2() {
    mul_ln1118_327_fu_2172_p2 = (!mul_ln1118_327_fu_2172_p0.read().is_01() || !ap_const_lv26_129.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_327_fu_2172_p0.read()) * sc_biguint<26>(ap_const_lv26_129);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_328_fu_2105_p0() {
    mul_ln1118_328_fu_2105_p0 =  (sc_lv<16>) (sext_ln1118_217_fu_2624315_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_328_fu_2105_p2() {
    mul_ln1118_328_fu_2105_p2 = (!mul_ln1118_328_fu_2105_p0.read().is_01() || !ap_const_lv23_7FFFC5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_328_fu_2105_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_329_fu_1400_p0() {
    mul_ln1118_329_fu_1400_p0 =  (sc_lv<16>) (sext_ln1118_218_fu_2624322_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_329_fu_1400_p2() {
    mul_ln1118_329_fu_1400_p2 = (!mul_ln1118_329_fu_1400_p0.read().is_01() || !ap_const_lv22_3FFFE5.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_329_fu_1400_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_32_fu_2165_p0() {
    mul_ln1118_32_fu_2165_p0 =  (sc_lv<16>) (sext_ln1118_22_fu_2616474_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_32_fu_2165_p2() {
    mul_ln1118_32_fu_2165_p2 = (!mul_ln1118_32_fu_2165_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_32_fu_2165_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_330_fu_2290_p0() {
    mul_ln1118_330_fu_2290_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_330_fu_2290_p2() {
    mul_ln1118_330_fu_2290_p2 = (!mul_ln1118_330_fu_2290_p0.read().is_01() || !ap_const_lv24_FFFFBB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_330_fu_2290_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_331_fu_1904_p0() {
    mul_ln1118_331_fu_1904_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_331_fu_1904_p2() {
    mul_ln1118_331_fu_1904_p2 = (!mul_ln1118_331_fu_1904_p0.read().is_01() || !ap_const_lv24_FFFFA5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_331_fu_1904_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_332_fu_1518_p0() {
    mul_ln1118_332_fu_1518_p0 =  (sc_lv<16>) (sext_ln1118_216_fu_2624307_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_332_fu_1518_p2() {
    mul_ln1118_332_fu_1518_p2 = (!mul_ln1118_332_fu_1518_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_332_fu_1518_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_333_fu_1770_p0() {
    mul_ln1118_333_fu_1770_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_333_fu_1770_p2() {
    mul_ln1118_333_fu_1770_p2 = (!mul_ln1118_333_fu_1770_p0.read().is_01() || !ap_const_lv26_115.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_333_fu_1770_p0.read()) * sc_biguint<26>(ap_const_lv26_115);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_334_fu_1703_p0() {
    mul_ln1118_334_fu_1703_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_334_fu_1703_p2() {
    mul_ln1118_334_fu_1703_p2 = (!mul_ln1118_334_fu_1703_p0.read().is_01() || !ap_const_lv26_126.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_334_fu_1703_p0.read()) * sc_biguint<26>(ap_const_lv26_126);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_335_fu_1955_p0() {
    mul_ln1118_335_fu_1955_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_335_fu_1955_p2() {
    mul_ln1118_335_fu_1955_p2 = (!mul_ln1118_335_fu_1955_p0.read().is_01() || !ap_const_lv26_132.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_335_fu_1955_p0.read()) * sc_biguint<26>(ap_const_lv26_132);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_336_fu_1569_p0() {
    mul_ln1118_336_fu_1569_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_336_fu_1569_p2() {
    mul_ln1118_336_fu_1569_p2 = (!mul_ln1118_336_fu_1569_p0.read().is_01() || !ap_const_lv24_FFFF9B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_336_fu_1569_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_337_fu_1502_p0() {
    mul_ln1118_337_fu_1502_p0 =  (sc_lv<16>) (sext_ln1118_217_fu_2624315_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_337_fu_1502_p2() {
    mul_ln1118_337_fu_1502_p2 = (!mul_ln1118_337_fu_1502_p0.read().is_01() || !ap_const_lv23_2F.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_337_fu_1502_p0.read()) * sc_biguint<23>(ap_const_lv23_2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_338_fu_1754_p0() {
    mul_ln1118_338_fu_1754_p0 =  (sc_lv<16>) (sext_ln1118_216_fu_2624307_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_338_fu_1754_p2() {
    mul_ln1118_338_fu_1754_p2 = (!mul_ln1118_338_fu_1754_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_338_fu_1754_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_339_fu_1368_p0() {
    mul_ln1118_339_fu_1368_p0 =  (sc_lv<16>) (sext_ln1118_216_fu_2624307_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_339_fu_1368_p2() {
    mul_ln1118_339_fu_1368_p2 = (!mul_ln1118_339_fu_1368_p0.read().is_01() || !ap_const_lv25_1FFFF6B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_339_fu_1368_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_33_fu_1504_p0() {
    mul_ln1118_33_fu_1504_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_33_fu_1504_p2() {
    mul_ln1118_33_fu_1504_p2 = (!mul_ln1118_33_fu_1504_p0.read().is_01() || !ap_const_lv25_D7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_33_fu_1504_p0.read()) * sc_biguint<25>(ap_const_lv25_D7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_340_fu_1477_p0() {
    mul_ln1118_340_fu_1477_p0 =  (sc_lv<16>) (sext_ln1118_219_fu_2624328_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_340_fu_1477_p2() {
    mul_ln1118_340_fu_1477_p2 = (!mul_ln1118_340_fu_1477_p0.read().is_01() || !ap_const_lv24_FFFF83.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_340_fu_1477_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF83);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_341_fu_1841_p0() {
    mul_ln1118_341_fu_1841_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_341_fu_1841_p2() {
    mul_ln1118_341_fu_1841_p2 = (!mul_ln1118_341_fu_1841_p0.read().is_01() || !ap_const_lv26_170.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_341_fu_1841_p0.read()) * sc_biguint<26>(ap_const_lv26_170);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_342_fu_1772_p0() {
    mul_ln1118_342_fu_1772_p0 =  (sc_lv<16>) (sext_ln1118_220_fu_2624339_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_342_fu_1772_p2() {
    mul_ln1118_342_fu_1772_p2 = (!mul_ln1118_342_fu_1772_p0.read().is_01() || !ap_const_lv26_3FFFEE5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_342_fu_1772_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_343_fu_1684_p0() {
    mul_ln1118_343_fu_1684_p0 =  (sc_lv<16>) (sext_ln1118_216_fu_2624307_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_343_fu_1684_p2() {
    mul_ln1118_343_fu_1684_p2 = (!mul_ln1118_343_fu_1684_p0.read().is_01() || !ap_const_lv25_D2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_343_fu_1684_p0.read()) * sc_biguint<25>(ap_const_lv25_D2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_344_fu_1997_p0() {
    mul_ln1118_344_fu_1997_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_344_fu_1997_p2() {
    mul_ln1118_344_fu_1997_p2 = (!mul_ln1118_344_fu_1997_p0.read().is_01() || !ap_const_lv25_95.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_344_fu_1997_p0.read()) * sc_biguint<25>(ap_const_lv25_95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_345_fu_1998_p0() {
    mul_ln1118_345_fu_1998_p0 =  (sc_lv<16>) (sext_ln1118_225_fu_2624797_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_345_fu_1998_p2() {
    mul_ln1118_345_fu_1998_p2 = (!mul_ln1118_345_fu_1998_p0.read().is_01() || !ap_const_lv26_136.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_345_fu_1998_p0.read()) * sc_biguint<26>(ap_const_lv26_136);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_346_fu_1687_p0() {
    mul_ln1118_346_fu_1687_p0 =  (sc_lv<16>) (sext_ln1118_227_fu_2624811_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_346_fu_1687_p2() {
    mul_ln1118_346_fu_1687_p2 = (!mul_ln1118_346_fu_1687_p0.read().is_01() || !ap_const_lv24_FFFFAC.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_346_fu_1687_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_347_fu_1688_p0() {
    mul_ln1118_347_fu_1688_p0 =  (sc_lv<16>) (sext_ln1118_227_fu_2624811_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_347_fu_1688_p2() {
    mul_ln1118_347_fu_1688_p2 = (!mul_ln1118_347_fu_1688_p0.read().is_01() || !ap_const_lv24_45.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_347_fu_1688_p0.read()) * sc_biguint<24>(ap_const_lv24_45);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_348_fu_2157_p0() {
    mul_ln1118_348_fu_2157_p0 =  (sc_lv<16>) (sext_ln1118_225_fu_2624797_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_348_fu_2157_p2() {
    mul_ln1118_348_fu_2157_p2 = (!mul_ln1118_348_fu_2157_p0.read().is_01() || !ap_const_lv26_188.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_348_fu_2157_p0.read()) * sc_biguint<26>(ap_const_lv26_188);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_349_fu_1846_p0() {
    mul_ln1118_349_fu_1846_p0 = sext_ln1118_226_fu_2624806_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_349_fu_1846_p2() {
    mul_ln1118_349_fu_1846_p2 = (!mul_ln1118_349_fu_1846_p0.read().is_01() || !ap_const_lv23_37.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_349_fu_1846_p0.read()) * sc_biguint<23>(ap_const_lv23_37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_34_fu_2086_p0() {
    mul_ln1118_34_fu_2086_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_34_fu_2086_p2() {
    mul_ln1118_34_fu_2086_p2 = (!mul_ln1118_34_fu_2086_p0.read().is_01() || !ap_const_lv25_98.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_34_fu_2086_p0.read()) * sc_biguint<25>(ap_const_lv25_98);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_350_fu_1691_p0() {
    mul_ln1118_350_fu_1691_p0 =  (sc_lv<16>) (sext_ln1118_225_fu_2624797_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_350_fu_1691_p2() {
    mul_ln1118_350_fu_1691_p2 = (!mul_ln1118_350_fu_1691_p0.read().is_01() || !ap_const_lv26_3FFFE74.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_350_fu_1691_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE74);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_351_fu_1616_p0() {
    mul_ln1118_351_fu_1616_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_351_fu_1616_p2() {
    mul_ln1118_351_fu_1616_p2 = (!mul_ln1118_351_fu_1616_p0.read().is_01() || !ap_const_lv25_D9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_351_fu_1616_p0.read()) * sc_biguint<25>(ap_const_lv25_D9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_352_fu_2005_p0() {
    mul_ln1118_352_fu_2005_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_352_fu_2005_p2() {
    mul_ln1118_352_fu_2005_p2 = (!mul_ln1118_352_fu_2005_p0.read().is_01() || !ap_const_lv25_1FFFF73.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_352_fu_2005_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF73);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_353_fu_1855_p0() {
    mul_ln1118_353_fu_1855_p0 =  (sc_lv<16>) (sext_ln1118_225_fu_2624797_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_353_fu_1855_p2() {
    mul_ln1118_353_fu_1855_p2 = (!mul_ln1118_353_fu_1855_p0.read().is_01() || !ap_const_lv26_1AE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_353_fu_1855_p0.read()) * sc_biguint<26>(ap_const_lv26_1AE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_354_fu_2004_p0() {
    mul_ln1118_354_fu_2004_p0 =  (sc_lv<16>) (sext_ln1118_227_fu_2624811_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_354_fu_2004_p2() {
    mul_ln1118_354_fu_2004_p2 = (!mul_ln1118_354_fu_2004_p0.read().is_01() || !ap_const_lv24_FFFFAB.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_354_fu_2004_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_355_fu_2145_p0() {
    mul_ln1118_355_fu_2145_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_355_fu_2145_p2() {
    mul_ln1118_355_fu_2145_p2 = (!mul_ln1118_355_fu_2145_p0.read().is_01() || !ap_const_lv25_1FFFF12.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_355_fu_2145_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF12);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_356_fu_1440_p0() {
    mul_ln1118_356_fu_1440_p0 =  (sc_lv<16>) (sext_ln1118_227_fu_2624811_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_356_fu_1440_p2() {
    mul_ln1118_356_fu_1440_p2 = (!mul_ln1118_356_fu_1440_p0.read().is_01() || !ap_const_lv24_FFFFA7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_356_fu_1440_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_357_fu_1692_p0() {
    mul_ln1118_357_fu_1692_p0 =  (sc_lv<16>) (sext_ln1118_227_fu_2624811_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_357_fu_1692_p2() {
    mul_ln1118_357_fu_1692_p2 = (!mul_ln1118_357_fu_1692_p0.read().is_01() || !ap_const_lv24_FFFFAA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_357_fu_1692_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_358_fu_1847_p0() {
    mul_ln1118_358_fu_1847_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_358_fu_1847_p2() {
    mul_ln1118_358_fu_1847_p2 = (!mul_ln1118_358_fu_1847_p0.read().is_01() || !ap_const_lv25_1FFFF6E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_358_fu_1847_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_359_fu_1877_p0() {
    mul_ln1118_359_fu_1877_p0 =  (sc_lv<16>) (sext_ln1118_225_fu_2624797_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_359_fu_1877_p2() {
    mul_ln1118_359_fu_1877_p2 = (!mul_ln1118_359_fu_1877_p0.read().is_01() || !ap_const_lv26_3FFFE95.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_359_fu_1877_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE95);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_35_fu_1775_p0() {
    mul_ln1118_35_fu_1775_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_35_fu_1775_p2() {
    mul_ln1118_35_fu_1775_p2 = (!mul_ln1118_35_fu_1775_p0.read().is_01() || !ap_const_lv25_8C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_35_fu_1775_p0.read()) * sc_biguint<25>(ap_const_lv25_8C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_360_fu_1491_p0() {
    mul_ln1118_360_fu_1491_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_360_fu_1491_p2() {
    mul_ln1118_360_fu_1491_p2 = (!mul_ln1118_360_fu_1491_p0.read().is_01() || !ap_const_lv25_E7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_360_fu_1491_p0.read()) * sc_biguint<25>(ap_const_lv25_E7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_361_fu_1424_p0() {
    mul_ln1118_361_fu_1424_p0 =  (sc_lv<16>) (sext_ln1118_228_fu_2624820_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_361_fu_1424_p2() {
    mul_ln1118_361_fu_1424_p2 = (!mul_ln1118_361_fu_1424_p0.read().is_01() || !ap_const_lv25_97.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_361_fu_1424_p0.read()) * sc_biguint<25>(ap_const_lv25_97);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_362_fu_1357_p0() {
    mul_ln1118_362_fu_1357_p0 =  (sc_lv<16>) (sext_ln1118_245_fu_2625425_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_362_fu_1357_p2() {
    mul_ln1118_362_fu_1357_p2 = (!mul_ln1118_362_fu_1357_p0.read().is_01() || !ap_const_lv24_FFFFB7.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_362_fu_1357_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB7);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_363_fu_1720_p0() {
    mul_ln1118_363_fu_1720_p0 =  (sc_lv<16>) (sext_ln1118_246_fu_2625432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_363_fu_1720_p2() {
    mul_ln1118_363_fu_1720_p2 = (!mul_ln1118_363_fu_1720_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_363_fu_1720_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_364_fu_1542_p0() {
    mul_ln1118_364_fu_1542_p0 =  (sc_lv<16>) (sext_ln1118_245_fu_2625425_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_364_fu_1542_p2() {
    mul_ln1118_364_fu_1542_p2 = (!mul_ln1118_364_fu_1542_p0.read().is_01() || !ap_const_lv24_FFFFAC.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_364_fu_1542_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAC);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_365_fu_2113_p0() {
    mul_ln1118_365_fu_2113_p0 =  (sc_lv<16>) (sext_ln1118_244_fu_2625417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_365_fu_2113_p2() {
    mul_ln1118_365_fu_2113_p2 = (!mul_ln1118_365_fu_2113_p0.read().is_01() || !ap_const_lv25_1FFFF5B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_365_fu_2113_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_366_fu_2046_p0() {
    mul_ln1118_366_fu_2046_p0 =  (sc_lv<16>) (sext_ln1118_246_fu_2625432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_366_fu_2046_p2() {
    mul_ln1118_366_fu_2046_p2 = (!mul_ln1118_366_fu_2046_p0.read().is_01() || !ap_const_lv23_39.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_366_fu_2046_p0.read()) * sc_biguint<23>(ap_const_lv23_39);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_367_fu_2297_p0() {
    mul_ln1118_367_fu_2297_p0 =  (sc_lv<16>) (sext_ln1118_244_fu_2625417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_367_fu_2297_p2() {
    mul_ln1118_367_fu_2297_p2 = (!mul_ln1118_367_fu_2297_p0.read().is_01() || !ap_const_lv25_C6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_367_fu_2297_p0.read()) * sc_biguint<25>(ap_const_lv25_C6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_368_fu_1636_p0() {
    mul_ln1118_368_fu_1636_p0 = sext_ln1118_247_fu_2625439_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_368_fu_1636_p2() {
    mul_ln1118_368_fu_1636_p2 = (!mul_ln1118_368_fu_1636_p0.read().is_01() || !ap_const_lv22_17.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_368_fu_1636_p0.read()) * sc_biguint<22>(ap_const_lv22_17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_369_fu_1595_p0() {
    mul_ln1118_369_fu_1595_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_369_fu_1595_p2() {
    mul_ln1118_369_fu_1595_p2 = (!mul_ln1118_369_fu_1595_p0.read().is_01() || !ap_const_lv26_12D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_369_fu_1595_p0.read()) * sc_biguint<26>(ap_const_lv26_12D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_36_fu_1776_p0() {
    mul_ln1118_36_fu_1776_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_36_fu_1776_p2() {
    mul_ln1118_36_fu_1776_p2 = (!mul_ln1118_36_fu_1776_p0.read().is_01() || !ap_const_lv25_9D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_36_fu_1776_p0.read()) * sc_biguint<25>(ap_const_lv25_9D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_370_fu_1594_p0() {
    mul_ln1118_370_fu_1594_p0 =  (sc_lv<16>) (sext_ln1118_245_fu_2625425_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_370_fu_1594_p2() {
    mul_ln1118_370_fu_1594_p2 = (!mul_ln1118_370_fu_1594_p0.read().is_01() || !ap_const_lv24_5D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_370_fu_1594_p0.read()) * sc_biguint<24>(ap_const_lv24_5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_371_fu_1441_p0() {
    mul_ln1118_371_fu_1441_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_371_fu_1441_p2() {
    mul_ln1118_371_fu_1441_p2 = (!mul_ln1118_371_fu_1441_p0.read().is_01() || !ap_const_lv26_150.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_371_fu_1441_p0.read()) * sc_biguint<26>(ap_const_lv26_150);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_372_fu_2311_p0() {
    mul_ln1118_372_fu_2311_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_372_fu_2311_p2() {
    mul_ln1118_372_fu_2311_p2 = (!mul_ln1118_372_fu_2311_p0.read().is_01() || !ap_const_lv26_115.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_372_fu_2311_p0.read()) * sc_biguint<26>(ap_const_lv26_115);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_373_fu_1443_p0() {
    mul_ln1118_373_fu_1443_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_373_fu_1443_p2() {
    mul_ln1118_373_fu_1443_p2 = (!mul_ln1118_373_fu_1443_p0.read().is_01() || !ap_const_lv26_3FFFE64.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_373_fu_1443_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE64);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_374_fu_1600_p0() {
    mul_ln1118_374_fu_1600_p0 =  (sc_lv<16>) (sext_ln1118_244_fu_2625417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_374_fu_1600_p2() {
    mul_ln1118_374_fu_1600_p2 = (!mul_ln1118_374_fu_1600_p0.read().is_01() || !ap_const_lv25_1FFFF1A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_374_fu_1600_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_375_fu_1601_p0() {
    mul_ln1118_375_fu_1601_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_375_fu_1601_p2() {
    mul_ln1118_375_fu_1601_p2 = (!mul_ln1118_375_fu_1601_p0.read().is_01() || !ap_const_lv26_116.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_375_fu_1601_p0.read()) * sc_biguint<26>(ap_const_lv26_116);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_376_fu_1446_p0() {
    mul_ln1118_376_fu_1446_p0 =  (sc_lv<16>) (sext_ln1118_244_fu_2625417_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_376_fu_1446_p2() {
    mul_ln1118_376_fu_1446_p2 = (!mul_ln1118_376_fu_1446_p0.read().is_01() || !ap_const_lv25_1FFFF35.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_376_fu_1446_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_377_fu_1759_p0() {
    mul_ln1118_377_fu_1759_p0 =  (sc_lv<16>) (sext_ln1118_246_fu_2625432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_377_fu_1759_p2() {
    mul_ln1118_377_fu_1759_p2 = (!mul_ln1118_377_fu_1759_p0.read().is_01() || !ap_const_lv23_32.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_377_fu_1759_p0.read()) * sc_biguint<23>(ap_const_lv23_32);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_378_fu_1760_p0() {
    mul_ln1118_378_fu_1760_p0 =  (sc_lv<16>) (sext_ln1118_243_fu_2625407_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_378_fu_1760_p2() {
    mul_ln1118_378_fu_1760_p2 = (!mul_ln1118_378_fu_1760_p0.read().is_01() || !ap_const_lv26_158.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_378_fu_1760_p0.read()) * sc_biguint<26>(ap_const_lv26_158);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_379_fu_1917_p0() {
    mul_ln1118_379_fu_1917_p0 =  (sc_lv<16>) (sext_ln1118_257_fu_2625881_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_379_fu_1917_p2() {
    mul_ln1118_379_fu_1917_p2 = (!mul_ln1118_379_fu_1917_p0.read().is_01() || !ap_const_lv25_86.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_379_fu_1917_p0.read()) * sc_biguint<25>(ap_const_lv25_86);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_37_fu_2245_p0() {
    mul_ln1118_37_fu_2245_p0 =  (sc_lv<16>) (sext_ln1118_20_fu_2616461_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_37_fu_2245_p2() {
    mul_ln1118_37_fu_2245_p2 = (!mul_ln1118_37_fu_2245_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_37_fu_2245_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_380_fu_2319_p0() {
    mul_ln1118_380_fu_2319_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_380_fu_2319_p2() {
    mul_ln1118_380_fu_2319_p2 = (!mul_ln1118_380_fu_2319_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_380_fu_2319_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_381_fu_1614_p0() {
    mul_ln1118_381_fu_1614_p0 =  (sc_lv<16>) (sext_ln1118_258_fu_2625889_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_381_fu_1614_p2() {
    mul_ln1118_381_fu_1614_p2 = (!mul_ln1118_381_fu_1614_p0.read().is_01() || !ap_const_lv23_7FFFC5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_381_fu_1614_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_382_fu_1547_p0() {
    mul_ln1118_382_fu_1547_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_382_fu_1547_p2() {
    mul_ln1118_382_fu_1547_p2 = (!mul_ln1118_382_fu_1547_p0.read().is_01() || !ap_const_lv24_FFFF9E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_382_fu_1547_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_383_fu_1799_p0() {
    mul_ln1118_383_fu_1799_p0 =  (sc_lv<16>) (sext_ln1118_257_fu_2625881_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_383_fu_1799_p2() {
    mul_ln1118_383_fu_1799_p2 = (!mul_ln1118_383_fu_1799_p0.read().is_01() || !ap_const_lv25_DD.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_383_fu_1799_p0.read()) * sc_biguint<25>(ap_const_lv25_DD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_384_fu_1413_p0() {
    mul_ln1118_384_fu_1413_p0 =  (sc_lv<16>) (sext_ln1118_257_fu_2625881_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_384_fu_1413_p2() {
    mul_ln1118_384_fu_1413_p2 = (!mul_ln1118_384_fu_1413_p0.read().is_01() || !ap_const_lv25_CF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_384_fu_1413_p0.read()) * sc_biguint<25>(ap_const_lv25_CF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_385_fu_2303_p0() {
    mul_ln1118_385_fu_2303_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_385_fu_2303_p2() {
    mul_ln1118_385_fu_2303_p2 = (!mul_ln1118_385_fu_2303_p0.read().is_01() || !ap_const_lv24_FFFFB3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_385_fu_2303_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_386_fu_2347_p0() {
    mul_ln1118_386_fu_2347_p0 =  (sc_lv<16>) (sext_ln1118_257_fu_2625881_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_386_fu_2347_p2() {
    mul_ln1118_386_fu_2347_p2 = (!mul_ln1118_386_fu_2347_p0.read().is_01() || !ap_const_lv25_D5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_386_fu_2347_p0.read()) * sc_biguint<25>(ap_const_lv25_D5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_387_fu_1850_p0() {
    mul_ln1118_387_fu_1850_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_387_fu_1850_p2() {
    mul_ln1118_387_fu_1850_p2 = (!mul_ln1118_387_fu_1850_p0.read().is_01() || !ap_const_lv24_47.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_387_fu_1850_p0.read()) * sc_biguint<24>(ap_const_lv24_47);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_388_fu_1575_p0() {
    mul_ln1118_388_fu_1575_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_388_fu_1575_p2() {
    mul_ln1118_388_fu_1575_p2 = (!mul_ln1118_388_fu_1575_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_388_fu_1575_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_389_fu_1397_p0() {
    mul_ln1118_389_fu_1397_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_389_fu_1397_p2() {
    mul_ln1118_389_fu_1397_p2 = (!mul_ln1118_389_fu_1397_p0.read().is_01() || !ap_const_lv24_6F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_389_fu_1397_p0.read()) * sc_biguint<24>(ap_const_lv24_6F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_38_fu_1778_p0() {
    mul_ln1118_38_fu_1778_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_38_fu_1778_p2() {
    mul_ln1118_38_fu_1778_p2 = (!mul_ln1118_38_fu_1778_p0.read().is_01() || !ap_const_lv26_3FFFEC1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_38_fu_1778_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_390_fu_1968_p0() {
    mul_ln1118_390_fu_1968_p0 = sext_ln1118_256_fu_2625876_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_390_fu_1968_p2() {
    mul_ln1118_390_fu_1968_p2 = (!mul_ln1118_390_fu_1968_p0.read().is_01() || !ap_const_lv26_117.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_390_fu_1968_p0.read()) * sc_biguint<26>(ap_const_lv26_117);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_391_fu_1901_p0() {
    mul_ln1118_391_fu_1901_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_391_fu_1901_p2() {
    mul_ln1118_391_fu_1901_p2 = (!mul_ln1118_391_fu_1901_p0.read().is_01() || !ap_const_lv24_54.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_391_fu_1901_p0.read()) * sc_biguint<24>(ap_const_lv24_54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_392_fu_1834_p0() {
    mul_ln1118_392_fu_1834_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_392_fu_1834_p2() {
    mul_ln1118_392_fu_1834_p2 = (!mul_ln1118_392_fu_1834_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_392_fu_1834_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_393_fu_1670_p0() {
    mul_ln1118_393_fu_1670_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_393_fu_1670_p2() {
    mul_ln1118_393_fu_1670_p2 = (!mul_ln1118_393_fu_1670_p0.read().is_01() || !ap_const_lv24_FFFFB4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_393_fu_1670_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_394_fu_1492_p0() {
    mul_ln1118_394_fu_1492_p0 =  (sc_lv<16>) (sext_ln1118_259_fu_2625894_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_394_fu_1492_p2() {
    mul_ln1118_394_fu_1492_p2 = (!mul_ln1118_394_fu_1492_p0.read().is_01() || !ap_const_lv24_FFFF8A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_394_fu_1492_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_395_fu_2093_p0() {
    mul_ln1118_395_fu_2093_p0 = sext_ln1118_260_fu_2625908_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_395_fu_2093_p2() {
    mul_ln1118_395_fu_2093_p2 = (!mul_ln1118_395_fu_2093_p0.read().is_01() || !ap_const_lv22_3FFFED.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_395_fu_2093_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFED);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_396_fu_2094_p0() {
    mul_ln1118_396_fu_2094_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_396_fu_2094_p2() {
    mul_ln1118_396_fu_2094_p2 = (!mul_ln1118_396_fu_2094_p0.read().is_01() || !ap_const_lv25_B6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_396_fu_2094_p0.read()) * sc_biguint<25>(ap_const_lv25_B6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_397_fu_1508_p0() {
    mul_ln1118_397_fu_1508_p0 =  (sc_lv<16>) (sext_ln1118_276_fu_2626512_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_397_fu_1508_p2() {
    mul_ln1118_397_fu_1508_p2 = (!mul_ln1118_397_fu_1508_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_397_fu_1508_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_398_fu_1509_p0() {
    mul_ln1118_398_fu_1509_p0 =  (sc_lv<16>) (sext_ln1118_274_fu_2626492_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_398_fu_1509_p2() {
    mul_ln1118_398_fu_1509_p2 = (!mul_ln1118_398_fu_1509_p0.read().is_01() || !ap_const_lv26_3FFFEF9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_398_fu_1509_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_399_fu_1510_p0() {
    mul_ln1118_399_fu_1510_p0 =  (sc_lv<16>) (sext_ln1118_274_fu_2626492_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_399_fu_1510_p2() {
    mul_ln1118_399_fu_1510_p2 = (!mul_ln1118_399_fu_1510_p0.read().is_01() || !ap_const_lv26_3FFFEAB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_399_fu_1510_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_39_fu_1623_p0() {
    mul_ln1118_39_fu_1623_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_39_fu_1623_p2() {
    mul_ln1118_39_fu_1623_p2 = (!mul_ln1118_39_fu_1623_p0.read().is_01() || !ap_const_lv25_1FFFF5D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_39_fu_1623_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_400_fu_1511_p0() {
    mul_ln1118_400_fu_1511_p0 =  (sc_lv<16>) (sext_ln1118_276_fu_2626512_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_400_fu_1511_p2() {
    mul_ln1118_400_fu_1511_p2 = (!mul_ln1118_400_fu_1511_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_400_fu_1511_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_401_fu_1668_p0() {
    mul_ln1118_401_fu_1668_p0 = sext_ln1118_273_fu_2626487_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_401_fu_1668_p2() {
    mul_ln1118_401_fu_1668_p2 = (!mul_ln1118_401_fu_1668_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_401_fu_1668_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_402_fu_1513_p0() {
    mul_ln1118_402_fu_1513_p0 =  (sc_lv<16>) (sext_ln1118_278_fu_2626524_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_402_fu_1513_p2() {
    mul_ln1118_402_fu_1513_p2 = (!mul_ln1118_402_fu_1513_p0.read().is_01() || !ap_const_lv24_FFFF9B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_402_fu_1513_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_403_fu_1514_p0() {
    mul_ln1118_403_fu_1514_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_403_fu_1514_p2() {
    mul_ln1118_403_fu_1514_p2 = (!mul_ln1118_403_fu_1514_p0.read().is_01() || !ap_const_lv25_1FFFF34.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_403_fu_1514_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF34);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_404_fu_1515_p0() {
    mul_ln1118_404_fu_1515_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_404_fu_1515_p2() {
    mul_ln1118_404_fu_1515_p2 = (!mul_ln1118_404_fu_1515_p0.read().is_01() || !ap_const_lv25_F5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_404_fu_1515_p0.read()) * sc_biguint<25>(ap_const_lv25_F5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_405_fu_1516_p0() {
    mul_ln1118_405_fu_1516_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_405_fu_1516_p2() {
    mul_ln1118_405_fu_1516_p2 = (!mul_ln1118_405_fu_1516_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_405_fu_1516_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_406_fu_1517_p0() {
    mul_ln1118_406_fu_1517_p0 =  (sc_lv<16>) (sext_ln1118_274_fu_2626492_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_406_fu_1517_p2() {
    mul_ln1118_406_fu_1517_p2 = (!mul_ln1118_406_fu_1517_p0.read().is_01() || !ap_const_lv26_3FFFE89.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_406_fu_1517_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE89);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_407_fu_1830_p0() {
    mul_ln1118_407_fu_1830_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_407_fu_1830_p2() {
    mul_ln1118_407_fu_1830_p2 = (!mul_ln1118_407_fu_1830_p0.read().is_01() || !ap_const_lv25_1FFFF59.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_407_fu_1830_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_408_fu_1519_p0() {
    mul_ln1118_408_fu_1519_p0 =  (sc_lv<16>) (sext_ln1118_278_fu_2626524_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_408_fu_1519_p2() {
    mul_ln1118_408_fu_1519_p2 = (!mul_ln1118_408_fu_1519_p0.read().is_01() || !ap_const_lv24_FFFF87.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_408_fu_1519_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_409_fu_1698_p0() {
    mul_ln1118_409_fu_1698_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_409_fu_1698_p2() {
    mul_ln1118_409_fu_1698_p2 = (!mul_ln1118_409_fu_1698_p0.read().is_01() || !ap_const_lv25_1FFFF1D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_409_fu_1698_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_40_fu_1936_p0() {
    mul_ln1118_40_fu_1936_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_40_fu_1936_p2() {
    mul_ln1118_40_fu_1936_p2 = (!mul_ln1118_40_fu_1936_p0.read().is_01() || !ap_const_lv26_3FFFEDE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_40_fu_1936_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_410_fu_2269_p0() {
    mul_ln1118_410_fu_2269_p0 =  (sc_lv<16>) (sext_ln1118_274_fu_2626492_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_410_fu_2269_p2() {
    mul_ln1118_410_fu_2269_p2 = (!mul_ln1118_410_fu_2269_p0.read().is_01() || !ap_const_lv26_130.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_410_fu_2269_p0.read()) * sc_biguint<26>(ap_const_lv26_130);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_411_fu_2202_p0() {
    mul_ln1118_411_fu_2202_p0 =  (sc_lv<16>) (sext_ln1118_278_fu_2626524_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_411_fu_2202_p2() {
    mul_ln1118_411_fu_2202_p2 = (!mul_ln1118_411_fu_2202_p0.read().is_01() || !ap_const_lv24_FFFFA8.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_411_fu_2202_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_412_fu_1927_p0() {
    mul_ln1118_412_fu_1927_p0 =  (sc_lv<16>) (sext_ln1118_276_fu_2626512_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_412_fu_1927_p2() {
    mul_ln1118_412_fu_1927_p2 = (!mul_ln1118_412_fu_1927_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_412_fu_1927_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_413_fu_2068_p0() {
    mul_ln1118_413_fu_2068_p0 =  (sc_lv<16>) (sext_ln1118_275_fu_2626501_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_413_fu_2068_p2() {
    mul_ln1118_413_fu_2068_p2 = (!mul_ln1118_413_fu_2068_p0.read().is_01() || !ap_const_lv25_1FFFF53.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_413_fu_2068_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF53);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_414_fu_1363_p0() {
    mul_ln1118_414_fu_1363_p0 =  (sc_lv<16>) (sext_ln1118_276_fu_2626512_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_414_fu_1363_p2() {
    mul_ln1118_414_fu_1363_p2 = (!mul_ln1118_414_fu_1363_p0.read().is_01() || !ap_const_lv23_7FFFCA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_414_fu_1363_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_415_fu_1726_p0() {
    mul_ln1118_415_fu_1726_p0 =  (sc_lv<16>) (sext_ln1118_274_fu_2626492_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_415_fu_1726_p2() {
    mul_ln1118_415_fu_1726_p2 = (!mul_ln1118_415_fu_1726_p0.read().is_01() || !ap_const_lv26_3FFFEA1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_415_fu_1726_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_416_fu_2186_p0() {
    mul_ln1118_416_fu_2186_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_416_fu_2186_p2() {
    mul_ln1118_416_fu_2186_p2 = (!mul_ln1118_416_fu_2186_p0.read().is_01() || !ap_const_lv26_10A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_416_fu_2186_p0.read()) * sc_biguint<26>(ap_const_lv26_10A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_417_fu_1481_p0() {
    mul_ln1118_417_fu_1481_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_417_fu_1481_p2() {
    mul_ln1118_417_fu_1481_p2 = (!mul_ln1118_417_fu_1481_p0.read().is_01() || !ap_const_lv24_65.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_417_fu_1481_p0.read()) * sc_biguint<24>(ap_const_lv24_65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_418_fu_2052_p0() {
    mul_ln1118_418_fu_2052_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_418_fu_2052_p2() {
    mul_ln1118_418_fu_2052_p2 = (!mul_ln1118_418_fu_2052_p0.read().is_01() || !ap_const_lv26_186.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_418_fu_2052_p0.read()) * sc_biguint<26>(ap_const_lv26_186);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_419_fu_1952_p0() {
    mul_ln1118_419_fu_1952_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_419_fu_1952_p2() {
    mul_ln1118_419_fu_1952_p2 = (!mul_ln1118_419_fu_1952_p0.read().is_01() || !ap_const_lv26_15C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_419_fu_1952_p0.read()) * sc_biguint<26>(ap_const_lv26_15C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_41_fu_1937_p0() {
    mul_ln1118_41_fu_1937_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_41_fu_1937_p2() {
    mul_ln1118_41_fu_1937_p2 = (!mul_ln1118_41_fu_1937_p0.read().is_01() || !ap_const_lv26_3FFFE51.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_41_fu_1937_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_420_fu_2237_p0() {
    mul_ln1118_420_fu_2237_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_420_fu_2237_p2() {
    mul_ln1118_420_fu_2237_p2 = (!mul_ln1118_420_fu_2237_p0.read().is_01() || !ap_const_lv25_DA.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_420_fu_2237_p0.read()) * sc_biguint<25>(ap_const_lv25_DA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_421_fu_2170_p0() {
    mul_ln1118_421_fu_2170_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_421_fu_2170_p2() {
    mul_ln1118_421_fu_2170_p2 = (!mul_ln1118_421_fu_2170_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_421_fu_2170_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_423_fu_2123_p0() {
    mul_ln1118_423_fu_2123_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_423_fu_2123_p2() {
    mul_ln1118_423_fu_2123_p2 = (!mul_ln1118_423_fu_2123_p0.read().is_01() || !ap_const_lv25_1FFFF7A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_423_fu_2123_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_424_fu_1526_p0() {
    mul_ln1118_424_fu_1526_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_424_fu_1526_p2() {
    mul_ln1118_424_fu_1526_p2 = (!mul_ln1118_424_fu_1526_p0.read().is_01() || !ap_const_lv26_146.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_424_fu_1526_p0.read()) * sc_biguint<26>(ap_const_lv26_146);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_425_fu_1826_p0() {
    mul_ln1118_425_fu_1826_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_425_fu_1826_p2() {
    mul_ln1118_425_fu_1826_p2 = (!mul_ln1118_425_fu_1826_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_425_fu_1826_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_426_fu_1733_p0() {
    mul_ln1118_426_fu_1733_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_426_fu_1733_p2() {
    mul_ln1118_426_fu_1733_p2 = (!mul_ln1118_426_fu_1733_p0.read().is_01() || !ap_const_lv26_1B0.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_426_fu_1733_p0.read()) * sc_biguint<26>(ap_const_lv26_1B0);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_427_fu_1422_p0() {
    mul_ln1118_427_fu_1422_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_427_fu_1422_p2() {
    mul_ln1118_427_fu_1422_p2 = (!mul_ln1118_427_fu_1422_p0.read().is_01() || !ap_const_lv24_4A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_427_fu_1422_p0.read()) * sc_biguint<24>(ap_const_lv24_4A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_428_fu_1579_p0() {
    mul_ln1118_428_fu_1579_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_428_fu_1579_p2() {
    mul_ln1118_428_fu_1579_p2 = (!mul_ln1118_428_fu_1579_p0.read().is_01() || !ap_const_lv25_1FFFF54.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_428_fu_1579_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF54);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_429_fu_1580_p0() {
    mul_ln1118_429_fu_1580_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_429_fu_1580_p2() {
    mul_ln1118_429_fu_1580_p2 = (!mul_ln1118_429_fu_1580_p0.read().is_01() || !ap_const_lv25_1FFFF28.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_429_fu_1580_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF28);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_42_fu_1782_p0() {
    mul_ln1118_42_fu_1782_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_42_fu_1782_p2() {
    mul_ln1118_42_fu_1782_p2 = (!mul_ln1118_42_fu_1782_p0.read().is_01() || !ap_const_lv25_1FFFF56.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_42_fu_1782_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF56);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_430_fu_1581_p0() {
    mul_ln1118_430_fu_1581_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_430_fu_1581_p2() {
    mul_ln1118_430_fu_1581_p2 = (!mul_ln1118_430_fu_1581_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_430_fu_1581_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_431_fu_1738_p0() {
    mul_ln1118_431_fu_1738_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_431_fu_1738_p2() {
    mul_ln1118_431_fu_1738_p2 = (!mul_ln1118_431_fu_1738_p0.read().is_01() || !ap_const_lv24_FFFFBA.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_431_fu_1738_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFBA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_432_fu_1583_p0() {
    mul_ln1118_432_fu_1583_p0 =  (sc_lv<16>) (sext_ln1118_290_fu_2627002_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_432_fu_1583_p2() {
    mul_ln1118_432_fu_1583_p2 = (!mul_ln1118_432_fu_1583_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_432_fu_1583_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_433_fu_1584_p0() {
    mul_ln1118_433_fu_1584_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_433_fu_1584_p2() {
    mul_ln1118_433_fu_1584_p2 = (!mul_ln1118_433_fu_1584_p0.read().is_01() || !ap_const_lv26_3FFFEAB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_433_fu_1584_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_434_fu_1585_p0() {
    mul_ln1118_434_fu_1585_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_434_fu_1585_p2() {
    mul_ln1118_434_fu_1585_p2 = (!mul_ln1118_434_fu_1585_p0.read().is_01() || !ap_const_lv26_3FFFEA4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_434_fu_1585_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_435_fu_1586_p0() {
    mul_ln1118_435_fu_1586_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_435_fu_1586_p2() {
    mul_ln1118_435_fu_1586_p2 = (!mul_ln1118_435_fu_1586_p0.read().is_01() || !ap_const_lv25_1FFFF0E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_435_fu_1586_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_436_fu_1587_p0() {
    mul_ln1118_436_fu_1587_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_436_fu_1587_p2() {
    mul_ln1118_436_fu_1587_p2 = (!mul_ln1118_436_fu_1587_p0.read().is_01() || !ap_const_lv25_1FFFF21.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_436_fu_1587_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF21);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_437_fu_1752_p0() {
    mul_ln1118_437_fu_1752_p0 = sext_ln1118_286_fu_2626969_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_437_fu_1752_p2() {
    mul_ln1118_437_fu_1752_p2 = (!mul_ln1118_437_fu_1752_p0.read().is_01() || !ap_const_lv23_7FFFC5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_437_fu_1752_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_438_fu_2101_p0() {
    mul_ln1118_438_fu_2101_p0 =  (sc_lv<16>) (sext_ln1118_289_fu_2626990_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_438_fu_2101_p2() {
    mul_ln1118_438_fu_2101_p2 = (!mul_ln1118_438_fu_2101_p0.read().is_01() || !ap_const_lv25_1FFFF2F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_438_fu_2101_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_439_fu_2034_p0() {
    mul_ln1118_439_fu_2034_p0 =  (sc_lv<16>) (sext_ln1118_288_fu_2626978_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_439_fu_2034_p2() {
    mul_ln1118_439_fu_2034_p2 = (!mul_ln1118_439_fu_2034_p0.read().is_01() || !ap_const_lv26_3FFFEBF.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_439_fu_2034_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_43_fu_1939_p0() {
    mul_ln1118_43_fu_1939_p0 =  (sc_lv<16>) (sext_ln1118_17_fu_2616432_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_43_fu_1939_p2() {
    mul_ln1118_43_fu_1939_p2 = (!mul_ln1118_43_fu_1939_p0.read().is_01() || !ap_const_lv25_1FFFF51.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_43_fu_1939_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF51);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_440_fu_2078_p0() {
    mul_ln1118_440_fu_2078_p0 =  (sc_lv<16>) (sext_ln1118_297_fu_2627448_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_440_fu_2078_p2() {
    mul_ln1118_440_fu_2078_p2 = (!mul_ln1118_440_fu_2078_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_440_fu_2078_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_441_fu_2219_p0() {
    mul_ln1118_441_fu_2219_p0 =  (sc_lv<16>) (sext_ln1118_296_fu_2627441_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_441_fu_2219_p2() {
    mul_ln1118_441_fu_2219_p2 = (!mul_ln1118_441_fu_2219_p0.read().is_01() || !ap_const_lv25_1FFFF5C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_441_fu_2219_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_442_fu_1625_p0() {
    mul_ln1118_442_fu_1625_p0 =  (sc_lv<16>) (sext_ln1118_297_fu_2627448_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_442_fu_1625_p2() {
    mul_ln1118_442_fu_1625_p2 = (!mul_ln1118_442_fu_1625_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_442_fu_1625_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_443_fu_1558_p0() {
    mul_ln1118_443_fu_1558_p0 =  (sc_lv<16>) (sext_ln1118_296_fu_2627441_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_443_fu_1558_p2() {
    mul_ln1118_443_fu_1558_p2 = (!mul_ln1118_443_fu_1558_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_443_fu_1558_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_444_fu_1380_p0() {
    mul_ln1118_444_fu_1380_p0 = sext_ln1118_295_fu_2627436_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_444_fu_1380_p2() {
    mul_ln1118_444_fu_1380_p2 = (!mul_ln1118_444_fu_1380_p0.read().is_01() || !ap_const_lv26_117.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_444_fu_1380_p0.read()) * sc_biguint<26>(ap_const_lv26_117);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_445_fu_1632_p0() {
    mul_ln1118_445_fu_1632_p0 =  (sc_lv<16>) (sext_ln1118_296_fu_2627441_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_445_fu_1632_p2() {
    mul_ln1118_445_fu_1632_p2 = (!mul_ln1118_445_fu_1632_p0.read().is_01() || !ap_const_lv25_1FFFF24.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_445_fu_1632_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF24);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_446_fu_1564_p0() {
    mul_ln1118_446_fu_1564_p0 = sext_ln1118_298_fu_2627454_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_446_fu_1564_p2() {
    mul_ln1118_446_fu_1564_p2 = (!mul_ln1118_446_fu_1564_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_446_fu_1564_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_447_fu_2247_p0() {
    mul_ln1118_447_fu_2247_p0 =  (sc_lv<16>) (sext_ln1118_313_fu_2627792_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_447_fu_2247_p2() {
    mul_ln1118_447_fu_2247_p2 = (!mul_ln1118_447_fu_2247_p0.read().is_01() || !ap_const_lv23_7FFFCB.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_447_fu_2247_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_448_fu_1431_p0() {
    mul_ln1118_448_fu_1431_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_448_fu_1431_p2() {
    mul_ln1118_448_fu_1431_p2 = (!mul_ln1118_448_fu_1431_p0.read().is_01() || !ap_const_lv26_164.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_448_fu_1431_p0.read()) * sc_biguint<26>(ap_const_lv26_164);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_449_fu_2002_p0() {
    mul_ln1118_449_fu_2002_p0 =  (sc_lv<16>) (sext_ln1118_312_fu_2627786_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_449_fu_2002_p2() {
    mul_ln1118_449_fu_2002_p2 = (!mul_ln1118_449_fu_2002_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_449_fu_2002_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_44_fu_1940_p0() {
    mul_ln1118_44_fu_1940_p0 =  (sc_lv<16>) (sext_ln1118_18_fu_2616444_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_44_fu_1940_p2() {
    mul_ln1118_44_fu_1940_p2 = (!mul_ln1118_44_fu_1940_p0.read().is_01() || !ap_const_lv26_3FFFE37.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_44_fu_1940_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_450_fu_2254_p0() {
    mul_ln1118_450_fu_2254_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_450_fu_2254_p2() {
    mul_ln1118_450_fu_2254_p2 = (!mul_ln1118_450_fu_2254_p0.read().is_01() || !ap_const_lv26_131.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_450_fu_2254_p0.read()) * sc_biguint<26>(ap_const_lv26_131);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_451_fu_1556_p0() {
    mul_ln1118_451_fu_1556_p0 =  (sc_lv<16>) (sext_ln1118_309_fu_2627765_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_451_fu_1556_p2() {
    mul_ln1118_451_fu_1556_p2 = (!mul_ln1118_451_fu_1556_p0.read().is_01() || !ap_const_lv22_3FFFE9.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_451_fu_1556_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_452_fu_1557_p0() {
    mul_ln1118_452_fu_1557_p0 =  (sc_lv<16>) (sext_ln1118_308_fu_2627758_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_452_fu_1557_p2() {
    mul_ln1118_452_fu_1557_p2 = (!mul_ln1118_452_fu_1557_p0.read().is_01() || !ap_const_lv24_6B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_452_fu_1557_p0.read()) * sc_biguint<24>(ap_const_lv24_6B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_453_fu_1801_p0() {
    mul_ln1118_453_fu_1801_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_453_fu_1801_p2() {
    mul_ln1118_453_fu_1801_p2 = (!mul_ln1118_453_fu_1801_p0.read().is_01() || !ap_const_lv26_146.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_453_fu_1801_p0.read()) * sc_biguint<26>(ap_const_lv26_146);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_454_fu_1646_p0() {
    mul_ln1118_454_fu_1646_p0 =  (sc_lv<16>) (sext_ln1118_307_fu_2627751_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_454_fu_1646_p2() {
    mul_ln1118_454_fu_1646_p2 = (!mul_ln1118_454_fu_1646_p0.read().is_01() || !ap_const_lv25_C2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_454_fu_1646_p0.read()) * sc_biguint<25>(ap_const_lv25_C2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_455_fu_1647_p0() {
    mul_ln1118_455_fu_1647_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_455_fu_1647_p2() {
    mul_ln1118_455_fu_1647_p2 = (!mul_ln1118_455_fu_1647_p0.read().is_01() || !ap_const_lv26_206.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_455_fu_1647_p0.read()) * sc_biguint<26>(ap_const_lv26_206);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_456_fu_1960_p0() {
    mul_ln1118_456_fu_1960_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_456_fu_1960_p2() {
    mul_ln1118_456_fu_1960_p2 = (!mul_ln1118_456_fu_1960_p0.read().is_01() || !ap_const_lv26_1A2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_456_fu_1960_p0.read()) * sc_biguint<26>(ap_const_lv26_1A2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_457_fu_1649_p0() {
    mul_ln1118_457_fu_1649_p0 =  (sc_lv<16>) (sext_ln1118_312_fu_2627786_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_457_fu_1649_p2() {
    mul_ln1118_457_fu_1649_p2 = (!mul_ln1118_457_fu_1649_p0.read().is_01() || !ap_const_lv21_D.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_457_fu_1649_p0.read()) * sc_biguint<21>(ap_const_lv21_D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_458_fu_1650_p0() {
    mul_ln1118_458_fu_1650_p0 =  (sc_lv<16>) (sext_ln1118_307_fu_2627751_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_458_fu_1650_p2() {
    mul_ln1118_458_fu_1650_p2 = (!mul_ln1118_458_fu_1650_p0.read().is_01() || !ap_const_lv25_1FFFF5C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_458_fu_1650_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_459_fu_1651_p0() {
    mul_ln1118_459_fu_1651_p0 =  (sc_lv<16>) (sext_ln1118_308_fu_2627758_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_459_fu_1651_p2() {
    mul_ln1118_459_fu_1651_p2 = (!mul_ln1118_459_fu_1651_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_459_fu_1651_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_45_fu_1629_p0() {
    mul_ln1118_45_fu_1629_p0 =  (sc_lv<16>) (sext_ln708_1_fu_2616984_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_45_fu_1629_p2() {
    mul_ln1118_45_fu_1629_p2 = (!mul_ln1118_45_fu_1629_p0.read().is_01() || !ap_const_lv26_3FFFEF9.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_45_fu_1629_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_460_fu_1964_p0() {
    mul_ln1118_460_fu_1964_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_460_fu_1964_p2() {
    mul_ln1118_460_fu_1964_p2 = (!mul_ln1118_460_fu_1964_p0.read().is_01() || !ap_const_lv26_12D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_460_fu_1964_p0.read()) * sc_biguint<26>(ap_const_lv26_12D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_461_fu_1809_p0() {
    mul_ln1118_461_fu_1809_p0 =  (sc_lv<16>) (sext_ln1118_310_fu_2627771_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_461_fu_1809_p2() {
    mul_ln1118_461_fu_1809_p2 = (!mul_ln1118_461_fu_1809_p0.read().is_01() || !ap_const_lv26_1B3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_461_fu_1809_p0.read()) * sc_biguint<26>(ap_const_lv26_1B3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_462_fu_1654_p0() {
    mul_ln1118_462_fu_1654_p0 =  (sc_lv<16>) (sext_ln1118_313_fu_2627792_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_462_fu_1654_p2() {
    mul_ln1118_462_fu_1654_p2 = (!mul_ln1118_462_fu_1654_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_462_fu_1654_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_463_fu_1811_p0() {
    mul_ln1118_463_fu_1811_p0 =  (sc_lv<16>) (sext_ln1118_307_fu_2627751_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_463_fu_1811_p2() {
    mul_ln1118_463_fu_1811_p2 = (!mul_ln1118_463_fu_1811_p0.read().is_01() || !ap_const_lv25_F5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_463_fu_1811_p0.read()) * sc_biguint<25>(ap_const_lv25_F5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_464_fu_1656_p0() {
    mul_ln1118_464_fu_1656_p0 =  (sc_lv<16>) (sext_ln1118_309_fu_2627765_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_464_fu_1656_p2() {
    mul_ln1118_464_fu_1656_p2 = (!mul_ln1118_464_fu_1656_p0.read().is_01() || !ap_const_lv22_3FFFE5.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_464_fu_1656_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_465_fu_2252_p0() {
    mul_ln1118_465_fu_2252_p0 =  (sc_lv<16>) (sext_ln1118_308_fu_2627758_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_465_fu_2252_p2() {
    mul_ln1118_465_fu_2252_p2 = (!mul_ln1118_465_fu_2252_p0.read().is_01() || !ap_const_lv24_66.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_465_fu_2252_p0.read()) * sc_biguint<24>(ap_const_lv24_66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_466_fu_1866_p0() {
    mul_ln1118_466_fu_1866_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_466_fu_1866_p2() {
    mul_ln1118_466_fu_1866_p2 = (!mul_ln1118_466_fu_1866_p0.read().is_01() || !ap_const_lv25_D6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_466_fu_1866_p0.read()) * sc_biguint<25>(ap_const_lv25_D6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_467_fu_2118_p0() {
    mul_ln1118_467_fu_2118_p0 =  (sc_lv<16>) (sext_ln1118_328_fu_2628323_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_467_fu_2118_p2() {
    mul_ln1118_467_fu_2118_p2 = (!mul_ln1118_467_fu_2118_p0.read().is_01() || !ap_const_lv24_5F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_467_fu_2118_p0.read()) * sc_biguint<24>(ap_const_lv24_5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_468_fu_1732_p0() {
    mul_ln1118_468_fu_1732_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_468_fu_1732_p2() {
    mul_ln1118_468_fu_1732_p2 = (!mul_ln1118_468_fu_1732_p0.read().is_01() || !ap_const_lv26_3FFFEC5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_468_fu_1732_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEC5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_469_fu_1346_p0() {
    mul_ln1118_469_fu_1346_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_469_fu_1346_p2() {
    mul_ln1118_469_fu_1346_p2 = (!mul_ln1118_469_fu_1346_p0.read().is_01() || !ap_const_lv26_15A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_469_fu_1346_p0.read()) * sc_biguint<26>(ap_const_lv26_15A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_46_fu_1864_p0() {
    mul_ln1118_46_fu_1864_p0 =  (sc_lv<16>) (sext_ln708_1_fu_2616984_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_46_fu_1864_p2() {
    mul_ln1118_46_fu_1864_p2 = (!mul_ln1118_46_fu_1864_p0.read().is_01() || !ap_const_lv26_3FFFE28.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_46_fu_1864_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE28);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_470_fu_1598_p0() {
    mul_ln1118_470_fu_1598_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_470_fu_1598_p2() {
    mul_ln1118_470_fu_1598_p2 = (!mul_ln1118_470_fu_1598_p0.read().is_01() || !ap_const_lv26_10C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_470_fu_1598_p0.read()) * sc_biguint<26>(ap_const_lv26_10C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_471_fu_2169_p0() {
    mul_ln1118_471_fu_2169_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_471_fu_2169_p2() {
    mul_ln1118_471_fu_2169_p2 = (!mul_ln1118_471_fu_2169_p0.read().is_01() || !ap_const_lv25_F9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_471_fu_2169_p0.read()) * sc_biguint<25>(ap_const_lv25_F9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_472_fu_2102_p0() {
    mul_ln1118_472_fu_2102_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_472_fu_2102_p2() {
    mul_ln1118_472_fu_2102_p2 = (!mul_ln1118_472_fu_2102_p0.read().is_01() || !ap_const_lv25_1FFFF3C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_472_fu_2102_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_473_fu_2035_p0() {
    mul_ln1118_473_fu_2035_p0 =  (sc_lv<16>) (sext_ln1118_325_fu_2628309_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_473_fu_2035_p2() {
    mul_ln1118_473_fu_2035_p2 = (!mul_ln1118_473_fu_2035_p0.read().is_01() || !ap_const_lv22_3FFFEB.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_473_fu_2035_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFEB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_474_fu_1330_p0() {
    mul_ln1118_474_fu_1330_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_474_fu_1330_p2() {
    mul_ln1118_474_fu_1330_p2 = (!mul_ln1118_474_fu_1330_p0.read().is_01() || !ap_const_lv26_169.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_474_fu_1330_p0.read()) * sc_biguint<26>(ap_const_lv26_169);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_475_fu_1582_p0() {
    mul_ln1118_475_fu_1582_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_475_fu_1582_p2() {
    mul_ln1118_475_fu_1582_p2 = (!mul_ln1118_475_fu_1582_p0.read().is_01() || !ap_const_lv26_10E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_475_fu_1582_p0.read()) * sc_biguint<26>(ap_const_lv26_10E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_476_fu_2153_p0() {
    mul_ln1118_476_fu_2153_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_476_fu_2153_p2() {
    mul_ln1118_476_fu_2153_p2 = (!mul_ln1118_476_fu_2153_p0.read().is_01() || !ap_const_lv25_E8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_476_fu_2153_p0.read()) * sc_biguint<25>(ap_const_lv25_E8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_477_fu_1448_p0() {
    mul_ln1118_477_fu_1448_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_477_fu_1448_p2() {
    mul_ln1118_477_fu_1448_p2 = (!mul_ln1118_477_fu_1448_p0.read().is_01() || !ap_const_lv26_3FFFEE6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_477_fu_1448_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEE6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_478_fu_2312_p0() {
    mul_ln1118_478_fu_2312_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_478_fu_2312_p2() {
    mul_ln1118_478_fu_2312_p2 = (!mul_ln1118_478_fu_2312_p0.read().is_01() || !ap_const_lv25_1FFFF25.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_478_fu_2312_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF25);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_479_fu_1352_p0() {
    mul_ln1118_479_fu_1352_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_479_fu_1352_p2() {
    mul_ln1118_479_fu_1352_p2 = (!mul_ln1118_479_fu_1352_p0.read().is_01() || !ap_const_lv25_1FFFF4D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_479_fu_1352_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_47_fu_1686_p0() {
    mul_ln1118_47_fu_1686_p0 =  (sc_lv<16>) (sext_ln708_3_fu_2617006_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_47_fu_1686_p2() {
    mul_ln1118_47_fu_1686_p2 = (!mul_ln1118_47_fu_1686_p0.read().is_01() || !ap_const_lv24_59.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_47_fu_1686_p0.read()) * sc_biguint<24>(ap_const_lv24_59);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_480_fu_1716_p0() {
    mul_ln1118_480_fu_1716_p0 = sext_ln1118_327_fu_2628318_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_480_fu_1716_p2() {
    mul_ln1118_480_fu_1716_p2 = (!mul_ln1118_480_fu_1716_p0.read().is_01() || !ap_const_lv23_7FFFCA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_480_fu_1716_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_481_fu_1714_p0() {
    mul_ln1118_481_fu_1714_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_481_fu_1714_p2() {
    mul_ln1118_481_fu_1714_p2 = (!mul_ln1118_481_fu_1714_p0.read().is_01() || !ap_const_lv25_1FFFF27.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_481_fu_1714_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF27);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_482_fu_1715_p0() {
    mul_ln1118_482_fu_1715_p0 =  (sc_lv<16>) (sext_ln1118_324_fu_2628297_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_482_fu_1715_p2() {
    mul_ln1118_482_fu_1715_p2 = (!mul_ln1118_482_fu_1715_p0.read().is_01() || !ap_const_lv25_B1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_482_fu_1715_p0.read()) * sc_biguint<25>(ap_const_lv25_B1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_483_fu_1872_p0() {
    mul_ln1118_483_fu_1872_p0 =  (sc_lv<16>) (sext_ln1118_323_fu_2628286_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_483_fu_1872_p2() {
    mul_ln1118_483_fu_1872_p2 = (!mul_ln1118_483_fu_1872_p0.read().is_01() || !ap_const_lv26_125.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_483_fu_1872_p0.read()) * sc_biguint<26>(ap_const_lv26_125);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_484_fu_1717_p0() {
    mul_ln1118_484_fu_1717_p0 =  (sc_lv<16>) (sext_ln1118_328_fu_2628323_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_484_fu_1717_p2() {
    mul_ln1118_484_fu_1717_p2 = (!mul_ln1118_484_fu_1717_p0.read().is_01() || !ap_const_lv24_47.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_484_fu_1717_p0.read()) * sc_biguint<24>(ap_const_lv24_47);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_485_fu_1718_p0() {
    mul_ln1118_485_fu_1718_p0 =  (sc_lv<16>) (sext_ln1118_343_fu_2628908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_485_fu_1718_p2() {
    mul_ln1118_485_fu_1718_p2 = (!mul_ln1118_485_fu_1718_p0.read().is_01() || !ap_const_lv26_3FFFEDE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_485_fu_1718_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_486_fu_1719_p0() {
    mul_ln1118_486_fu_1719_p0 =  (sc_lv<16>) (sext_ln1118_342_fu_2628901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_486_fu_1719_p2() {
    mul_ln1118_486_fu_1719_p2 = (!mul_ln1118_486_fu_1719_p0.read().is_01() || !ap_const_lv24_6B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_486_fu_1719_p0.read()) * sc_biguint<24>(ap_const_lv24_6B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_487_fu_1876_p0() {
    mul_ln1118_487_fu_1876_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_487_fu_1876_p2() {
    mul_ln1118_487_fu_1876_p2 = (!mul_ln1118_487_fu_1876_p0.read().is_01() || !ap_const_lv25_1FFFF0B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_487_fu_1876_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_488_fu_1721_p0() {
    mul_ln1118_488_fu_1721_p0 =  (sc_lv<16>) (sext_ln1118_343_fu_2628908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_488_fu_1721_p2() {
    mul_ln1118_488_fu_1721_p2 = (!mul_ln1118_488_fu_1721_p0.read().is_01() || !ap_const_lv26_123.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_488_fu_1721_p0.read()) * sc_biguint<26>(ap_const_lv26_123);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_489_fu_1566_p0() {
    mul_ln1118_489_fu_1566_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_489_fu_1566_p2() {
    mul_ln1118_489_fu_1566_p2 = (!mul_ln1118_489_fu_1566_p0.read().is_01() || !ap_const_lv25_1FFFF1A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_489_fu_1566_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_490_fu_1723_p0() {
    mul_ln1118_490_fu_1723_p0 =  (sc_lv<16>) (sext_ln1118_344_fu_2628916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_490_fu_1723_p2() {
    mul_ln1118_490_fu_1723_p2 = (!mul_ln1118_490_fu_1723_p0.read().is_01() || !ap_const_lv23_37.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_490_fu_1723_p0.read()) * sc_biguint<23>(ap_const_lv23_37);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_491_fu_2192_p0() {
    mul_ln1118_491_fu_2192_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_491_fu_2192_p2() {
    mul_ln1118_491_fu_2192_p2 = (!mul_ln1118_491_fu_2192_p0.read().is_01() || !ap_const_lv25_1FFFF5F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_491_fu_2192_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_492_fu_1881_p0() {
    mul_ln1118_492_fu_1881_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_492_fu_1881_p2() {
    mul_ln1118_492_fu_1881_p2 = (!mul_ln1118_492_fu_1881_p0.read().is_01() || !ap_const_lv25_1FFFF0C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_492_fu_1881_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_493_fu_2017_p0() {
    mul_ln1118_493_fu_2017_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_493_fu_2017_p2() {
    mul_ln1118_493_fu_2017_p2 = (!mul_ln1118_493_fu_2017_p0.read().is_01() || !ap_const_lv25_9C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_493_fu_2017_p0.read()) * sc_biguint<25>(ap_const_lv25_9C);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_494_fu_1950_p0() {
    mul_ln1118_494_fu_1950_p0 = sext_ln1118_345_fu_2628923_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_494_fu_1950_p2() {
    mul_ln1118_494_fu_1950_p2 = (!mul_ln1118_494_fu_1950_p0.read().is_01() || !ap_const_lv22_17.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_494_fu_1950_p0.read()) * sc_biguint<22>(ap_const_lv22_17);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_495_fu_1675_p0() {
    mul_ln1118_495_fu_1675_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_495_fu_1675_p2() {
    mul_ln1118_495_fu_1675_p2 = (!mul_ln1118_495_fu_1675_p0.read().is_01() || !ap_const_lv25_CF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_495_fu_1675_p0.read()) * sc_biguint<25>(ap_const_lv25_CF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_496_fu_1497_p0() {
    mul_ln1118_496_fu_1497_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_496_fu_1497_p2() {
    mul_ln1118_496_fu_1497_p2 = (!mul_ln1118_496_fu_1497_p0.read().is_01() || !ap_const_lv25_E8.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_496_fu_1497_p0.read()) * sc_biguint<25>(ap_const_lv25_E8);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_497_fu_1749_p0() {
    mul_ln1118_497_fu_1749_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_497_fu_1749_p2() {
    mul_ln1118_497_fu_1749_p2 = (!mul_ln1118_497_fu_1749_p0.read().is_01() || !ap_const_lv25_1FFFF76.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_497_fu_1749_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF76);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_498_fu_2001_p0() {
    mul_ln1118_498_fu_2001_p0 =  (sc_lv<16>) (sext_ln1118_342_fu_2628901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_498_fu_2001_p2() {
    mul_ln1118_498_fu_2001_p2 = (!mul_ln1118_498_fu_2001_p0.read().is_01() || !ap_const_lv24_43.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_498_fu_2001_p0.read()) * sc_biguint<24>(ap_const_lv24_43);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_499_fu_1934_p0() {
    mul_ln1118_499_fu_1934_p0 =  (sc_lv<16>) (sext_ln1118_344_fu_2628916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_499_fu_1934_p2() {
    mul_ln1118_499_fu_1934_p2 = (!mul_ln1118_499_fu_1934_p0.read().is_01() || !ap_const_lv23_35.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_499_fu_1934_p0.read()) * sc_biguint<23>(ap_const_lv23_35);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_49_fu_1938_p0() {
    mul_ln1118_49_fu_1938_p0 =  (sc_lv<16>) (sext_ln708_1_fu_2616984_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_49_fu_1938_p2() {
    mul_ln1118_49_fu_1938_p2 = (!mul_ln1118_49_fu_1938_p0.read().is_01() || !ap_const_lv26_3FFFECA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_49_fu_1938_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECA);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_500_fu_1978_p0() {
    mul_ln1118_500_fu_1978_p0 =  (sc_lv<16>) (sext_ln1118_343_fu_2628908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_500_fu_1978_p2() {
    mul_ln1118_500_fu_1978_p2 = (!mul_ln1118_500_fu_1978_p0.read().is_01() || !ap_const_lv26_161.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_500_fu_1978_p0.read()) * sc_biguint<26>(ap_const_lv26_161);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_501_fu_2341_p0() {
    mul_ln1118_501_fu_2341_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_501_fu_2341_p2() {
    mul_ln1118_501_fu_2341_p2 = (!mul_ln1118_501_fu_2341_p0.read().is_01() || !ap_const_lv25_EB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_501_fu_2341_p0.read()) * sc_biguint<25>(ap_const_lv25_EB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_502_fu_1414_p0() {
    mul_ln1118_502_fu_1414_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_502_fu_1414_p2() {
    mul_ln1118_502_fu_1414_p2 = (!mul_ln1118_502_fu_1414_p0.read().is_01() || !ap_const_lv25_DF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_502_fu_1414_p0.read()) * sc_biguint<25>(ap_const_lv25_DF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_503_fu_2304_p0() {
    mul_ln1118_503_fu_2304_p0 =  (sc_lv<16>) (sext_ln1118_344_fu_2628916_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_503_fu_2304_p2() {
    mul_ln1118_503_fu_2304_p2 = (!mul_ln1118_503_fu_2304_p0.read().is_01() || !ap_const_lv23_23.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_503_fu_2304_p0.read()) * sc_biguint<23>(ap_const_lv23_23);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_504_fu_1599_p0() {
    mul_ln1118_504_fu_1599_p0 =  (sc_lv<16>) (sext_ln1118_343_fu_2628908_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_504_fu_1599_p2() {
    mul_ln1118_504_fu_1599_p2 = (!mul_ln1118_504_fu_1599_p0.read().is_01() || !ap_const_lv26_12A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_504_fu_1599_p0.read()) * sc_biguint<26>(ap_const_lv26_12A);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_505_fu_1851_p0() {
    mul_ln1118_505_fu_1851_p0 =  (sc_lv<16>) (sext_ln1118_342_fu_2628901_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_505_fu_1851_p2() {
    mul_ln1118_505_fu_1851_p2 = (!mul_ln1118_505_fu_1851_p0.read().is_01() || !ap_const_lv24_49.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_505_fu_1851_p0.read()) * sc_biguint<24>(ap_const_lv24_49);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_506_fu_1465_p0() {
    mul_ln1118_506_fu_1465_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_506_fu_1465_p2() {
    mul_ln1118_506_fu_1465_p2 = (!mul_ln1118_506_fu_1465_p0.read().is_01() || !ap_const_lv25_1FFFF46.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_506_fu_1465_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF46);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_507_fu_2109_p0() {
    mul_ln1118_507_fu_2109_p0 =  (sc_lv<16>) (sext_ln1118_341_fu_2628885_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_507_fu_2109_p2() {
    mul_ln1118_507_fu_2109_p2 = (!mul_ln1118_507_fu_2109_p0.read().is_01() || !ap_const_lv25_96.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_507_fu_2109_p0.read()) * sc_biguint<25>(ap_const_lv25_96);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_508_fu_1747_p0() {
    mul_ln1118_508_fu_1747_p0 =  (sc_lv<16>) (sext_ln1118_357_fu_2629451_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_508_fu_1747_p2() {
    mul_ln1118_508_fu_1747_p2 = (!mul_ln1118_508_fu_1747_p0.read().is_01() || !ap_const_lv23_31.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_508_fu_1747_p0.read()) * sc_biguint<23>(ap_const_lv23_31);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_509_fu_2251_p0() {
    mul_ln1118_509_fu_2251_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_509_fu_2251_p2() {
    mul_ln1118_509_fu_2251_p2 = (!mul_ln1118_509_fu_2251_p0.read().is_01() || !ap_const_lv24_66.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_509_fu_2251_p0.read()) * sc_biguint<24>(ap_const_lv24_66);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_50_fu_2190_p0() {
    mul_ln1118_50_fu_2190_p0 =  (sc_lv<16>) (sext_ln708_1_fu_2616984_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_50_fu_2190_p2() {
    mul_ln1118_50_fu_2190_p2 = (!mul_ln1118_50_fu_2190_p0.read().is_01() || !ap_const_lv26_158.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_50_fu_2190_p0.read()) * sc_biguint<26>(ap_const_lv26_158);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_510_fu_1784_p0() {
    mul_ln1118_510_fu_1784_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_510_fu_1784_p2() {
    mul_ln1118_510_fu_1784_p2 = (!mul_ln1118_510_fu_1784_p0.read().is_01() || !ap_const_lv24_FFFFA2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_510_fu_1784_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_511_fu_1785_p0() {
    mul_ln1118_511_fu_1785_p0 =  (sc_lv<16>) (sext_ln1118_356_fu_2629445_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_511_fu_1785_p2() {
    mul_ln1118_511_fu_1785_p2 = (!mul_ln1118_511_fu_1785_p0.read().is_01() || !ap_const_lv26_148.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_511_fu_1785_p0.read()) * sc_biguint<26>(ap_const_lv26_148);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_512_fu_1786_p0() {
    mul_ln1118_512_fu_1786_p0 = sext_ln1118_360_fu_2629471_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_512_fu_1786_p2() {
    mul_ln1118_512_fu_1786_p2 = (!mul_ln1118_512_fu_1786_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_512_fu_1786_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_513_fu_1787_p0() {
    mul_ln1118_513_fu_1787_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_513_fu_1787_p2() {
    mul_ln1118_513_fu_1787_p2 = (!mul_ln1118_513_fu_1787_p0.read().is_01() || !ap_const_lv25_1FFFF65.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_513_fu_1787_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF65);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_514_fu_1788_p0() {
    mul_ln1118_514_fu_1788_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_514_fu_1788_p2() {
    mul_ln1118_514_fu_1788_p2 = (!mul_ln1118_514_fu_1788_p0.read().is_01() || !ap_const_lv25_F6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_514_fu_1788_p0.read()) * sc_biguint<25>(ap_const_lv25_F6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_516_fu_1789_p0() {
    mul_ln1118_516_fu_1789_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_516_fu_1789_p2() {
    mul_ln1118_516_fu_1789_p2 = (!mul_ln1118_516_fu_1789_p0.read().is_01() || !ap_const_lv25_D6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_516_fu_1789_p0.read()) * sc_biguint<25>(ap_const_lv25_D6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_517_fu_1790_p0() {
    mul_ln1118_517_fu_1790_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_517_fu_1790_p2() {
    mul_ln1118_517_fu_1790_p2 = (!mul_ln1118_517_fu_1790_p0.read().is_01() || !ap_const_lv24_FFFF8D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_517_fu_1790_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_518_fu_1791_p0() {
    mul_ln1118_518_fu_1791_p0 =  (sc_lv<16>) (sext_ln1118_356_fu_2629445_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_518_fu_1791_p2() {
    mul_ln1118_518_fu_1791_p2 = (!mul_ln1118_518_fu_1791_p0.read().is_01() || !ap_const_lv26_3FFFED6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_518_fu_1791_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED6);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_519_fu_1792_p0() {
    mul_ln1118_519_fu_1792_p0 = sext_ln1118_354_fu_2629430_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_519_fu_1792_p2() {
    mul_ln1118_519_fu_1792_p2 = (!mul_ln1118_519_fu_1792_p0.read().is_01() || !ap_const_lv22_1B.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_519_fu_1792_p0.read()) * sc_biguint<22>(ap_const_lv22_1B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_51_fu_1485_p0() {
    mul_ln1118_51_fu_1485_p0 = sext_ln708_2_fu_2617001_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_51_fu_1485_p2() {
    mul_ln1118_51_fu_1485_p2 = (!mul_ln1118_51_fu_1485_p0.read().is_01() || !ap_const_lv23_2B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_51_fu_1485_p0.read()) * sc_biguint<23>(ap_const_lv23_2B);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_520_fu_1793_p0() {
    mul_ln1118_520_fu_1793_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_520_fu_1793_p2() {
    mul_ln1118_520_fu_1793_p2 = (!mul_ln1118_520_fu_1793_p0.read().is_01() || !ap_const_lv25_D1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_520_fu_1793_p0.read()) * sc_biguint<25>(ap_const_lv25_D1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_521_fu_1849_p0() {
    mul_ln1118_521_fu_1849_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_521_fu_1849_p2() {
    mul_ln1118_521_fu_1849_p2 = (!mul_ln1118_521_fu_1849_p0.read().is_01() || !ap_const_lv25_9E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_521_fu_1849_p0.read()) * sc_biguint<25>(ap_const_lv25_9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_522_fu_1463_p0() {
    mul_ln1118_522_fu_1463_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_522_fu_1463_p2() {
    mul_ln1118_522_fu_1463_p2 = (!mul_ln1118_522_fu_1463_p0.read().is_01() || !ap_const_lv24_FFFFB1.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_522_fu_1463_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB1);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_523_fu_1507_p0() {
    mul_ln1118_523_fu_1507_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_523_fu_1507_p2() {
    mul_ln1118_523_fu_1507_p2 = (!mul_ln1118_523_fu_1507_p0.read().is_01() || !ap_const_lv24_FFFFAD.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_523_fu_1507_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAD);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_524_fu_1967_p0() {
    mul_ln1118_524_fu_1967_p0 =  (sc_lv<16>) (sext_ln1118_355_fu_2629435_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_524_fu_1967_p2() {
    mul_ln1118_524_fu_1967_p2 = (!mul_ln1118_524_fu_1967_p0.read().is_01() || !ap_const_lv25_1FFFF29.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_524_fu_1967_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF29);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_525_fu_2011_p0() {
    mul_ln1118_525_fu_2011_p0 =  (sc_lv<16>) (sext_ln1118_358_fu_2629457_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_525_fu_2011_p2() {
    mul_ln1118_525_fu_2011_p2 = (!mul_ln1118_525_fu_2011_p0.read().is_01() || !ap_const_lv24_FFFFAE.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_525_fu_2011_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAE);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_527_fu_1833_p0() {
    mul_ln1118_527_fu_1833_p0 =  (sc_lv<16>) (sext_ln1118_357_fu_2629451_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_527_fu_1833_p2() {
    mul_ln1118_527_fu_1833_p2 = (!mul_ln1118_527_fu_1833_p0.read().is_01() || !ap_const_lv23_2E.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_527_fu_1833_p0.read()) * sc_biguint<23>(ap_const_lv23_2E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_528_fu_1766_p0() {
    mul_ln1118_528_fu_1766_p0 = sext_ln1118_375_fu_2630073_p0.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_528_fu_1766_p2() {
    mul_ln1118_528_fu_1766_p2 = (!mul_ln1118_528_fu_1766_p0.read().is_01() || !ap_const_lv23_23.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_528_fu_1766_p0.read()) * sc_biguint<23>(ap_const_lv23_23);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_529_fu_2337_p0() {
    mul_ln1118_529_fu_2337_p0 =  (sc_lv<16>) (sext_ln1118_376_fu_2630078_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_529_fu_2337_p2() {
    mul_ln1118_529_fu_2337_p2 = (!mul_ln1118_529_fu_2337_p0.read().is_01() || !ap_const_lv24_FFFF9E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_529_fu_2337_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_52_fu_2056_p0() {
    mul_ln1118_52_fu_2056_p0 =  (sc_lv<16>) (sext_ln708_1_fu_2616984_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_52_fu_2056_p2() {
    mul_ln1118_52_fu_2056_p2 = (!mul_ln1118_52_fu_2056_p0.read().is_01() || !ap_const_lv26_3FFFE72.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_52_fu_2056_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE72);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_530_fu_2270_p0() {
    mul_ln1118_530_fu_2270_p0 =  (sc_lv<16>) (sext_ln1118_374_fu_2630067_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_530_fu_2270_p2() {
    mul_ln1118_530_fu_2270_p2 = (!mul_ln1118_530_fu_2270_p0.read().is_01() || !ap_const_lv22_16.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_530_fu_2270_p0.read()) * sc_biguint<22>(ap_const_lv22_16);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_531_fu_1565_p0() {
    mul_ln1118_531_fu_1565_p0 =  (sc_lv<16>) (sext_ln1118_373_fu_2630059_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_531_fu_1565_p2() {
    mul_ln1118_531_fu_1565_p2 = (!mul_ln1118_531_fu_1565_p0.read().is_01() || !ap_const_lv25_C9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_531_fu_1565_p0.read()) * sc_biguint<25>(ap_const_lv25_C9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_532_fu_2136_p0() {
    mul_ln1118_532_fu_2136_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_532_fu_2136_p2() {
    mul_ln1118_532_fu_2136_p2 = (!mul_ln1118_532_fu_2136_p0.read().is_01() || !ap_const_lv26_176.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_532_fu_2136_p0.read()) * sc_biguint<26>(ap_const_lv26_176);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_533_fu_1750_p0() {
    mul_ln1118_533_fu_1750_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_533_fu_1750_p2() {
    mul_ln1118_533_fu_1750_p2 = (!mul_ln1118_533_fu_1750_p0.read().is_01() || !ap_const_lv26_172.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_533_fu_1750_p0.read()) * sc_biguint<26>(ap_const_lv26_172);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_534_fu_1364_p0() {
    mul_ln1118_534_fu_1364_p0 =  (sc_lv<16>) (sext_ln1118_373_fu_2630059_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_534_fu_1364_p2() {
    mul_ln1118_534_fu_1364_p2 = (!mul_ln1118_534_fu_1364_p0.read().is_01() || !ap_const_lv25_87.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_534_fu_1364_p0.read()) * sc_biguint<25>(ap_const_lv25_87);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_535_fu_1727_p0() {
    mul_ln1118_535_fu_1727_p0 =  (sc_lv<16>) (sext_ln1118_376_fu_2630078_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_535_fu_1727_p2() {
    mul_ln1118_535_fu_1727_p2 = (!mul_ln1118_535_fu_1727_p0.read().is_01() || !ap_const_lv24_5E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_535_fu_1727_p0.read()) * sc_biguint<24>(ap_const_lv24_5E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_536_fu_1708_p0() {
    mul_ln1118_536_fu_1708_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_536_fu_1708_p2() {
    mul_ln1118_536_fu_1708_p2 = (!mul_ln1118_536_fu_1708_p0.read().is_01() || !ap_const_lv26_146.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_536_fu_1708_p0.read()) * sc_biguint<26>(ap_const_lv26_146);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_537_fu_2268_p0() {
    mul_ln1118_537_fu_2268_p0 =  (sc_lv<16>) (sext_ln1118_373_fu_2630059_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_537_fu_2268_p2() {
    mul_ln1118_537_fu_2268_p2 = (!mul_ln1118_537_fu_2268_p0.read().is_01() || !ap_const_lv25_1FFFF0E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_537_fu_2268_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF0E);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_538_fu_1695_p0() {
    mul_ln1118_538_fu_1695_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_538_fu_1695_p2() {
    mul_ln1118_538_fu_1695_p2 = (!mul_ln1118_538_fu_1695_p0.read().is_01() || !ap_const_lv26_199.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_538_fu_1695_p0.read()) * sc_biguint<26>(ap_const_lv26_199);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_539_fu_2008_p0() {
    mul_ln1118_539_fu_2008_p0 =  (sc_lv<16>) (sext_ln1118_376_fu_2630078_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_539_fu_2008_p2() {
    mul_ln1118_539_fu_2008_p2 = (!mul_ln1118_539_fu_2008_p0.read().is_01() || !ap_const_lv24_5F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_539_fu_2008_p0.read()) * sc_biguint<24>(ap_const_lv24_5F);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_53_fu_1351_p0() {
    mul_ln1118_53_fu_1351_p0 =  (sc_lv<16>) (sext_ln708_fu_2616977_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_53_fu_1351_p2() {
    mul_ln1118_53_fu_1351_p2 = (!mul_ln1118_53_fu_1351_p0.read().is_01() || !ap_const_lv25_CF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_53_fu_1351_p0.read()) * sc_biguint<25>(ap_const_lv25_CF);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_540_fu_1697_p0() {
    mul_ln1118_540_fu_1697_p0 =  (sc_lv<16>) (sext_ln1118_374_fu_2630067_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_540_fu_1697_p2() {
    mul_ln1118_540_fu_1697_p2 = (!mul_ln1118_540_fu_1697_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_540_fu_1697_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_541_fu_1854_p0() {
    mul_ln1118_541_fu_1854_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_541_fu_1854_p2() {
    mul_ln1118_541_fu_1854_p2 = (!mul_ln1118_541_fu_1854_p0.read().is_01() || !ap_const_lv26_1DB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_541_fu_1854_p0.read()) * sc_biguint<26>(ap_const_lv26_1DB);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_542_fu_1387_p0() {
    mul_ln1118_542_fu_1387_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_542_fu_1387_p2() {
    mul_ln1118_542_fu_1387_p2 = (!mul_ln1118_542_fu_1387_p0.read().is_01() || !ap_const_lv26_14D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_542_fu_1387_p0.read()) * sc_biguint<26>(ap_const_lv26_14D);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_543_fu_1544_p0() {
    mul_ln1118_543_fu_1544_p0 =  (sc_lv<16>) (sext_ln1118_373_fu_2630059_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_543_fu_1544_p2() {
    mul_ln1118_543_fu_1544_p2 = (!mul_ln1118_543_fu_1544_p0.read().is_01() || !ap_const_lv25_1FFFF56.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_543_fu_1544_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF56);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_544_fu_2325_p0() {
    mul_ln1118_544_fu_2325_p0 =  (sc_lv<16>) (sext_ln1118_372_fu_2630048_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_544_fu_2325_p2() {
    mul_ln1118_544_fu_2325_p2 = (!mul_ln1118_544_fu_2325_p0.read().is_01() || !ap_const_lv26_212.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_544_fu_2325_p0.read()) * sc_biguint<26>(ap_const_lv26_212);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_545_fu_1390_p0() {
    mul_ln1118_545_fu_1390_p0 =  (sc_lv<16>) (sext_ln1118_392_fu_2630630_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_545_fu_1390_p2() {
    mul_ln1118_545_fu_1390_p2 = (!mul_ln1118_545_fu_1390_p0.read().is_01() || !ap_const_lv25_E9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_545_fu_1390_p0.read()) * sc_biguint<25>(ap_const_lv25_E9);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_546_fu_2015_p0() {
    mul_ln1118_546_fu_2015_p0 =  (sc_lv<16>) (sext_ln1118_391_fu_2630618_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_546_fu_2015_p2() {
    mul_ln1118_546_fu_2015_p2 = (!mul_ln1118_546_fu_2015_p0.read().is_01() || !ap_const_lv24_67.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_546_fu_2015_p0.read()) * sc_biguint<24>(ap_const_lv24_67);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_547_fu_1548_p0() {
    mul_ln1118_547_fu_1548_p0 =  (sc_lv<16>) (sext_ln1118_391_fu_2630618_p1.read());
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_s::thread_mul_ln1118_547_fu_1548_p2() {
    mul_ln1118_547_fu_1548_p2 = (!mul_ln1118_547_fu_1548_p0.read().is_01() || !ap_const_lv24_FFFF89.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_547_fu_1548_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF89);
}

}

